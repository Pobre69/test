<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Banco De Dados</title>
    <link rel="stylesheet" href="bdDesign.css">
    <?php
        require_once 'BDconection.php';
        function getComidas(){
            global $conn;
            $stmt = $conn->query('SELECT * FROM Comida_Show;');
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
        $bdFoodTable = getComidas();
        $bdFoodInfo;
        if(isset($_POST['Comida'])){
            $bdFoodInfo = getComida($_POST['Comida']);
            unset($_POST['Comida']);
        }
        if(isset($_POST['nameComida'])){
            if(!empty($_POST['nameComida'])){
                $bdFoodInfo = getComida($_POST['nameComida']);
                unset($_POST['nameComida']);
            }
        }
    ?>
</head>
<body>
    <div id="BlackScreen" onclick="FecharInfoComida()"></div>
    <div id="Menu"><img src="MenuIcon.png" id="MenuIcon2" onclick="MenuIconClosing()" alt="">
        <div id="Links">
            <div class="MarginTop15"><a href="index.html" onclick="Reset()">Menu</a></div>
            <div class="MarginTop15"><a href="infoSecurity.php" onclick="Reset()">Informações</a></div>
            <div class="MarginTop15"><a href="cronogramaSecurity.php" onclick="Reset()">Cronogramas</a></div>
        </div>
    </div>
    <div id="ShowFoodInfo">
        <div id="EditFoodInfo">
            <?php if (!empty($bdFoodInfo)): ?>
                <div style="grid-column-start: 1;grid-column-end:3;height:100px;text-align:center;font-size:2em;">Nome: <?= $bdFoodInfo['nomeComidaEncontrada'] ?></div>
                <div>Calorias: <?= $bdFoodInfo['cal'] ?> kcal</div>
                <div>Carboidrato: <?= $bdFoodInfo['carboidrato'] ?> g</div>
                <div>Proteína: <?= $bdFoodInfo['proteina'] ?> g</div>
                <div>Gordura Boa: <?= $bdFoodInfo['gordura_boa'] ?> g</div>
                <div>Fibra: <?= $bdFoodInfo['fibra'] ?> g</div>

                <div>Cálcio: <?= $bdFoodInfo['calcio'] ?> mg</div>
                <div>Fósforo: <?= $bdFoodInfo['fosforo'] ?> mg</div>
                <div>Magnésio: <?= $bdFoodInfo['magnesio'] ?> mg</div>
                <div>Ferro: <?= $bdFoodInfo['ferro'] ?> mg</div>
                <div>Potássio: <?= $bdFoodInfo['potassio'] ?> mg</div>
                <div>Sódio: <?= $bdFoodInfo['sodio'] ?> mg</div>
                <div>Zinco: <?= $bdFoodInfo['zinco'] ?> mg</div>
                <div>Selênio: <?= $bdFoodInfo['selenio'] ?> µg</div>
                <div>Cobre: <?= $bdFoodInfo['cobre'] ?> mg</div>

                <div>Vitamina A: <?= $bdFoodInfo['vA'] ?> µg</div>
                <div>Vitamina C: <?= $bdFoodInfo['vC'] ?> mg</div>
                <div>Vitamina D: <?= $bdFoodInfo['vD'] ?> µg</div>
                <div>Vitamina E: <?= $bdFoodInfo['vE'] ?> mg</div>
                <div>Vitamina K: <?= $bdFoodInfo['vK'] ?> µg</div>
                <div>Vitamina B1: <?= $bdFoodInfo['vB1'] ?> mg</div>
                <div>Vitamina B2: <?= $bdFoodInfo['vB2'] ?> mg</div>
                <div>Vitamina B3: <?= $bdFoodInfo['vB3'] ?> mg</div>
                <div>Vitamina B5: <?= $bdFoodInfo['vB5'] ?> mg</div>
                <div>Vitamina B6: <?= $bdFoodInfo['vB6'] ?> mg</div>
                <div>Vitamina B7: <?= $bdFoodInfo['vB7'] ?> µg</div>
                <div>Vitamina B9: <?= $bdFoodInfo['vB9'] ?> µg</div>
                <div>Vitamina B12: <?= $bdFoodInfo['vB12'] ?> µg</div>
            <?php else: ?>
                <div style="grid-column-start:1;grid-column-end:3;text-align:center;font-size:2em;">Nenhuma informação encontrada.</div>
            <?php endif; ?>
        </div>
    </div>
    <header id="header">
        <img src="MenuIcon.png" id="MenuIcon" onclick="MenuIconOpening()" alt="">
        <div id="MenuLinkDivision">
            
        </div>
    </header>
    <main id="Main">
        <div>
            <form id="BuscarComida" action="bdSecurity.php" method="post">
                <label for="text" style="font-size: 2em;font-weight: bold;margin-left: 10vw;text-align: center;">Pesquise alguma comida!</label>
                <div style="display: flex;justify-content: center;align-items: center;">
                    <input type="text" name="nameComida" placeholder="Digite aqui" id="PesquisarComidaDesign">
                    <button onclick="AbrirInfoComida('BuscarComida')" id="BuscarComidaDesign">Buscar</button>
                </div>
            </form>
        </div>
        <div id="bdInfo">
            <div id="bdTitle">BANCO DE DADOS DE COMIDA</div>
            <?php $index = 0; ?>
            <?php foreach($bdFoodTable as $comida):
                $comida_id = $comida['id'];
                $comida_name = $comida['food_name']; ?>
                <div class="<?= $index % 2 === 0 ? 'GrayInfo' : 'GrayInfo2'; ?>"
                onclick="AbrirInfoComida('form-<?= $comida_id; ?>')" 
                style="cursor: pointer;">
                    <form id="form-<?= $comida_id; ?>" action="bdSecurity.php" method="post">
                        <input type="hidden" name="Comida" value="<?= $comida_name; ?>"> 
                    </form>
                    <?= $comida_name; ?>
                </div>
            <?php $index++; endforeach ?>
        </div>
    </main>
    <script src="bdScript.js"></script>
</body>
</html>