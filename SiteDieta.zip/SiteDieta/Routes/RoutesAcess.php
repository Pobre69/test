<?php

namespace GetRoutes\Routes;

class GetRoutes
{
    protected static function getModels()
    {
        
    }
    protected static function getControllers()
    {
        
    }
    protected static function getRepositorys()
    {
        
    }
    protected static function getDataBase()
    {
        
    }
    public function getAll()
    {
        
    }
}