<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Informações</title>
    <link rel="stylesheet" href="infoDesign.css">
    <?php
        require_once 'BDconection.php';
        include_once 'LoginSecurity.php';

        $getFoodTableInfo = getQTDE_Nutriente();
        $getUserInfo;
        $getFoodTableInfoEditable;
        $TableSelected;
        $getFTIB;

        function getTableSelected(){
            global $conn;
            global $ID_Usuario;
            $stmt = $conn->query("SELECT QTDE_TableSelected FROM UsuarioInfo WHERE id_Usuario = {$ID_Usuario}");
            return $stmt->fetch(PDO::FETCH_ASSOC);
        }

        function getTableEditableSelected(){
            global $conn;
            global $ID_Usuario;
            global $getFoodTableInfoEditable;
            $stmt = $conn->query("SELECT TableEditableSelected FROM UsuarioInfo WHERE id_Usuario = {$ID_Usuario}");
            return $stmt->fetch(PDO::FETCH_ASSOC);
        }

        function getUserInfo(){
            global $conn;
            global $ID_Usuario;
            $stmt = $conn->query("SELECT COUNT(id_Usuario) FROM UsuarioInfo WHERE id_Usuario = '{$ID_Usuario}'");
            return $stmt->fetch(PDO::FETCH_ASSOC);
        }
        
        function getAllFTIB(){
            global $conn;
            global $ID_Usuario;
            $stmt = $conn->query("SELECT * FROM V_qtde_NutrientesEditable WHERE id_Usuario = {$ID_Usuario}");
            return $stmt->fetch(PDO::FETCH_ASSOC);
        }

        $getUserInfo = getUserInfo();
        $getFoodTableInfoEditable = getQTDE_NutrienteEditable(getTableEditableSelected());
        $TableSelected = getTableSelected();
        $getFTIB = getAllFTIB();

        if(isset($_POST['U_Nome'])) {
            $U_Nome = $_POST['U_Nome'];
            $U_Idade = $_POST['U_Idade'];
            $U_Email = $_POST['U_Email'];
            $U_Senha = $_POST['U_Senha'];

            $stmt = $conn->query("CALL CriarUsuario('{$U_Nome}','{$U_Idade}','{$U_Email}','{$U_Senha}',@param_UsuarioID)");
            $stmt->closeCursor();

            $result = $conn->query('SELECT ROUND(@param_UsuarioID,0) AS ID_Usuario');
            $row = $result->fetch(PDO::FETCH_ASSOC);
            $_SESSION['id'] = $row['ID_Usuario'];
            unset($_POST['U_Nome']);
            unset($_POST['U_Idade']);
            unset($_POST['U_Email']);
            unset($_POST['U_Senha']);
            header("Location: infoSecurity.php");
            exit;
        }
        if(isset($_POST['L_Email'])) {
            $L_email = $_POST['L_Email'];
            $L_Senha = $_POST['L_Senha'];

            $stmt = $conn->query("CALL BuscarUsuario('{$L_email}','{$L_Senha}',@param_UsuarioID_Show)");
            $stmt->closeCursor();

            $result = $conn->query('SELECT ROUND(@param_UsuarioID_Show,0) AS ID_Usuario_Show');
            $row = $result->fetch(PDO::FETCH_ASSOC);
            if($row['ID_Usuario_Show'] > 0){
                $_SESSION['id'] = $row['ID_Usuario_Show'];
            }
            unset($_POST['L_Email']);
            unset($_POST['L_Senha']);
            header("Location: infoSecurity.php");
            exit;
        }
        if(isset($_POST['Deslogar'])) {
            session_destroy();
            header("Location: infoSecurity.php");
            exit;
        }
        if(isset($_POST['PesoInfo']) && !empty($_POST['PesoInfo']) && $_SESSION > 0 && isset($_POST['SexoInfo']) && !empty($_POST['SexoInfo']) && isset($_POST['DeficienciaList']) && !empty($_POST['DeficienciaList'])){
            if($_POST['UserInfoVerify'] == 1){
                global $conn;
                global $ID_Usuario;

                $QTDE_TableSelected = getTableSelected();
                $TableEditableSelected = getTableEditableSelected();
                $Peso = $_POST['PesoInfo'];
                $Sexo = $_POST['SexoInfo'];

                $Alterar = $conn->query("CALL AlterarInfoUsuario({$ID_Usuario},{$Peso},'{$Sexo}',{$QTDE_TableSelected},{$TableEditableSelected})");
                $Alterar->closeCursor();

                $getTables = $conn->query("SELECT v_ID FROM V_Deficiencias WHERE v_UsuarioID = {$ID_Usuario}");
                $results = $getTables->fetchAll(PDO::FETCH_ASSOC);

                foreach($results as $delete){
                    $stmt = $conn->query("CALL DeletarInfoDeficiencia({$delete},{$ID_Usuario})");
                }
                foreach($_POST['DeficienciaList'] as $Deficiencia){
                    $Adicionar = $conn->query("CALL CriarInfoDeficiencia({$ID_Usuario},{$Deficiencia})");
                }
            }else{
                global $conn;
                global $ID_Usuario;

                $Peso = $_POST['PesoInfo'];
                $Sexo = $_POST['SexoInfo'];

                $Adicionar = $conn->query("CALL CriarInfoUsuario({$ID_Usuario},{$Peso},'{$Sexo}')");
                $Adicionar->closeCursor();
            }
        }
        if(isset($_POST['TableInfoSelected']) && !empty($_POST['TableInfoSelected']) && $_SESSION > 0){
            $Verify = $_POST['TabelaInfoSelected'];
            if($Verify == 1){
                global $conn;
                global $ID_Usuario;

                $getUserInformations = $conn->query("SELECT Sexo,Peso FROM UsuarioInfo WHERE id_Usuario = {$ID_Usuario};");
                $QTDE_TableSelected = $_POST['TableInfoSelected'];
                $TableEditableSelected = $_POST['TableInfoSelected'];
                $Peso = $getUserInformations['Peso'];
                $Sexo = $getUserInformations['Sexo'];

                $stmt = $conn->query("CALL AlterarInfoUsuario({$ID_Usuario},{$Peso},'{$Sexo}',{$QTDE_TableSelected},{$TableEditableSelected})");
            }else{
                global $conn;
                global $ID_Usuario;

                $getUserInformations = $conn->query("SELECT Sexo,Peso FROM UsuarioInfo WHERE id_Usuario = {$ID_Usuario};");
                $QTDE_TableSelected = $_POST['TableInfoSelected'];
                $TableEditableSelected = 0;
                $Peso = $getUserInformations['Peso'];
                $Sexo = $getUserInformations['Sexo'];

                $stmt = $conn->query("CALL AlterarInfoUsuario({$ID_Usuario},{$Peso},'{$Sexo}',{$QTDE_TableSelected},{$TableEditableSelected})");
            }
        }

        function getAllDeficiencia(){
            global $conn;
            $stmt = $conn->query("SELECT v_Deficiencia FROM V_ShowUserExtraInfoSave");
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
        function getUserDeficiencia(){
            global $conn;
            global $ID_Usuario;
            $stmt = $conn->query("SELECT v_Deficiencia FROM V_Deficiencias WHERE v_UsuarioID = {$ID_Usuario}");
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        }

        $getDeficiencias = getAllDeficiencia();
        $c = getUserDeficiencia();
    ?>
</head>
<body>
    <div id="BlackScreen"></div>
    <div id="Menu"><img src="MenuIcon.png" id="MenuIcon2" onclick="MenuIconClosing()" alt="">
        <div id="Links">
            <div class="MarginTop15"><a href="index.html" onclick="Reset()">Menu</a></div>
            <div class="MarginTop15"><a href="cronogramaSecurity.php" onclick="Reset()">Cronogramas</a></div>
            <div class="MarginTop15"><a href="bdSecurity.php" onclick="Reset()">Banco de Dados</a></div>
        </div>
    </div>
    <div id="CaixaLogin" Class="Centralizar">
        <?php if (isset($_SESSION['id']) && $_SESSION['id'] > 0): 
            $UsuarioInfoShow = getUsuario($_SESSION['id']); ?>
            <div id="EditUsuarioShow">
                <div class="CenterAlign MarginBottom"><h1 class="Branco">BEM VINDO <span style="color:blue;"><?= $UsuarioInfoShow['Usuario_NAME']?></span></h1></div>
                <div style="font-weight:bold;">Email: <?=  $UsuarioInfoShow['Usuario_EMAIL']?></div>
                <div style="margin-top:15px;font-weight:bold;">Idade: <?=  $UsuarioInfoShow['Usuario_AGE']?></div>
                <div Class="Flex Fechar MarginHorizontal" onclick="CaixaLoginClosing()"><h2>Fechar</h2></div>
            </div>
        <?php else: ?>
            <div>
                <div class="CenterAlign MarginBottom"><h2 class="Branco">PREENCHA AS INFORMAÇÕES<br>ANTES DE PROSSEGUIR</h2></div>
                <form id="EditForm2" action="infoSecurity.php" method="post" style="width:100%;">
                    <div>
                        <p style="font-size:1.5em;">Email:</p><br>
                        <input id="L_Email" type="text" style="width: 100%;" name="L_Email">
                    </div>
                    <div style="margin-top: 20px;">
                        <p style="font-size:1.5em;">Senha:</p><br>
                        <input id="L_Senha" type="text" style="width: 100%;" name="L_Senha" maxlength="20">
                    </div>
                </form>
                <div class="Opcoes">
                    <div id="Logar" class="Verde MarginHorizontal" onclick="LogarUsuario()"><h2>Entrar</h2></div>
                    <div Class="Fechar MarginHorizontal" onclick="CaixaLoginClosing()"><h2>Fechar</h2></div>
                </div>
            </div>
        <?php endif; ?>
    </div>
    <div id="CaixaCadastrar" class="Centralizar">
        <div>
            <?php if(isset($_SESSION['id']) && $_SESSION['id'] > 0): ?>
                <div class="CenterAlign MarginBottom"><h2 class="Branco">DESEJA DESLOGAR?</h2></div>
                <form id="EditForm3" action="infoSecurity.php" method="post" style="width:100%;">
                    <input type="hidden" name="Deslogar" value="1">
                </form>
                <div class="Opcoes">
                    <div id="Cadastrar" class="Fechar MarginHorizontal" onclick="Deslogar()"><h2>Sair</h2></div>
                    <div class="Verde MarginHorizontal"  onclick="CaixaCadastrarClosing()"><h2>Fechar</h2></div>
                </div>
            <?php else: ?>
                <div class="CenterAlign MarginBottom"><h2 class="Branco">PREENCHA AS INFORMAÇÕES<br>ANTES DE PROSSEGUIR</h2></div>
                <form id="EditForm1" action="infoSecurity.php" method="post" style="width:100%;">
                    <div style="width: 100%;grid-column-start: 1;grid-column-end: 4;">
                        <p style="font-size:1.5em;">Nome:</p>
                        <input id="U_Nome" type="text" style="width:100%;" name="U_Nome">
                    </div>
                    <div style="margin-top: 20px;">
                        <p style="font-size:1.5em;">Idade:</p>
                        <input id="U_Idade" type="number" style="width:100%;" name="U_Idade">
                    </div>
                    <div style="width: 80%;grid-column-start: 2;grid-column-end: 4;margin-left: 20%;margin-top: 20px;">
                        <p style="font-size:1.5em;">Senha:</p>
                        <input id="U_Senha" type="text" style="width:100%;" name="U_Senha">
                    </div>
                    <div style="width: 100%;grid-column-start: 1;grid-column-end: 4;margin-top: 20px;">
                        <p style="font-size:1.5em;">Email</p>
                        <input id="U_Email" type="text" style="width:100%;" name="U_Email">
                    </div>
                </form>
                <div class="Opcoes">
                    <div id="Cadastrar" class="Verde MarginHorizontal" onclick="CadastrarUsuario()"><h2>Salvar</h2></div>
                    <div class="Fechar MarginHorizontal"  onclick="CaixaCadastrarClosing()"><h2>Fechar</h2></div>
                </div>
            <?php endif ?>
        </div>
    </div>
    <header id="header">
        <img src="MenuIcon.png" id="MenuIcon" onclick="MenuIconOpening()" alt="">
        <div id="MenuLinkDivision">
            <div class="LinkMargin" onclick="CaixaLoginOpening()">Login</div>
            <?php if(isset($_SESSION['id']) && $_SESSION['id'] > 0): ?>
                <div class="LinkMargin" onclick="CaixaCadastrarOpening()">Sair</div>
            <?php else: ?>
                <div class="LinkMargin" onclick="CaixaCadastrarOpening()">Cadastrar</div>
            <?php endif ?>
        </div>
    </header>
    <main style="margin-top:75px;" id="Main">
        <?php if(isset($_SESSION['id']) && $_SESSION['id'] > 0): ?>
            <div class="Flex" style="margin-top:100px;">
                <div>
                    <?php if(isset($getUserInfo) && !empty($getUserInfo)): ?>
                        <p style="font-size:2.5em;text-align:center;">Altere as Informações Iniciais</p>
                        <div id="Info_Button1" class="Flex" onclick="OpenStartInfoBox()">ALTERAR</div>
                    <?php else: ?>
                        <p style="font-size:2.5em;text-align:center;">Preencha as Informações Iniciais</p>
                        <div id="Info_Button1" class="Flex" onclick="OpenStartInfoBox()">PREENCHER</div>
                    <?php endif ?>
                </div>
            </div>
            <?php if(isset($_SESSION['id']) && $_SESSION['id'] > 0 && $getFoodTableInfo[] != null): ?>
                <div id="ShowFoodTableInfoBox">
                    <form action="infoSecurity.php" method="post" id="TableSetSelected">
                        <input type="hidden" id="TableInfoSelected" name="TableInfoSelected">
                    </form>
                    <?php if($TableSelected['QTDE_TableSelected'] > 0): ?>
                        <div class="FoodTableInfoDesign" style="border:black double 2px" onclick="SetTableInfoSelected(0)">
                    <?php else: ?>
                        <div class="FoodTableInfoDesign" style="border:green double 2px" onclick="SetTableInfoSelected(0)">
                    <?php endif ?>
                        <?php foreach($getFoodTableInfo as $FoodName => $FoodInfo): ?>
                            <div><?= ucfirst(htmlspecialchars($FoodName)) ?></div>
                            <div><?= $FoodInfo ?></div>
                        <?php endforeach ?>
                    </div>
                    <?php if($TableSelected['QTDE_TableSelected'] > 0): ?>
                        <div class="FoodTableInfoDesign" style="border:green double 2px" onclick="SetTableInfoSelected(1)">
                    <?php else: ?>
                        <div class="FoodTableInfoDesign" style="border:black double 2px" onclick="SetTableInfoSelected(1)">
                    <?php endif ?>
                    <?php if($getFoodTableInfoEditable[] != null): ?>
                        <?php foreach($getFoodTableInfoEditable as $FoodName => $FoodInfo): ?>
                            <div><?= ucfirst(htmlspecialchars($FoodName)) ?></div>
                            <div><?= $FoodInfo ?></div>
                        <?php endforeach ?>
                    <?php else: ?>
                        <?php foreach($getFoodTableInfo as $FoodName => $FoodInfo): ?>
                            <div><?= ucfirst(htmlspecialchars($FoodName)) ?></div>
                            <div>0</div>
                        <?php endforeach ?>
                    <?php endif ?>
                    <div class="FoodTableInfoDesign" style="cursor:pointer;" onclick="OpenDesignFoodTableInfo()">
                        <img id="MaisIcon" src="MaisIcon.png" alt="">
                    </div>
                </div>
            <?php else: ?>
                <div style="font-size:2em;font-weight:bold;">Preencha as informações para ver mais</div>
            <?php endif ?>
        <?php else: ?>
            <p style="width: 100%; text-align: center; font-size: 2em;"><strong>Faça o login antes</strong></p>
        <?php endif ?>
    </main>
    <div id="DesignFoodTableInfo">
        <div>
            <div id="TitleFTIB">Edite sua tabela</div>
            <div id="ShowFTIB">
                <?php if($getFoodTableInfoEditable[] != null): ?>
                    <?php foreach($getFoodTableInfoEditable as $FoodName => $FoodInfo): ?>
                        <div><?= ucfirst(htmlspecialchars($FoodName)) ?></div>
                        <div><?= $FoodInfo ?></div>
                    <?php endforeach ?>
                <?php else: ?>
                    <?php foreach($getFoodTableInfo as $FoodName => $FoodInfo): ?>
                        <div><?= ucfirst(htmlspecialchars($FoodName)) ?></div>
                        <div>0</div>
                    <?php endforeach ?>
                <?php endif ?>
            </div>
            <div id="FoodTableInfoButtonDisplay">
                <div class="FoodTableInfoButtonDesign" id="CriarFTIB">CRIAR</div>
                <div class="FoodTableInfoButtonDesign" id="SelecionarFTIB">SELECIONAR</div>
                <div class="FoodTableInfoButtonDesign" id="ExcluirFTIB">EXCLUIR</div>
                <div class="FoodTableInfoButtonDesign" id="CancelarFTIB" onclick="CloseDesignFoodTableInfo()">CANCELAR</div>
            </div>
        </div>
    </div>
    <div id="SetStartInfoBox">
        <form action="infoSecurity.php" method="post" id="SetStartInfoForm">
            <div id="StartInfoDisplay">
                <div>
                    <div id="SetPesoInfo">
                        <p style="font-size:2em;">Digite seu peso:</p>
                        <input type="text" name="PesoInfo" id="PesoInfo" placeholder="0kg" maxlength="10">
                    </div>
                </div>
                <div>
                    <div id="SetSexoInfo">
                        <p style="font-size:2em;">Qual seu sexo:</p>
                        <select name="SexoInfo" id="SexoInfo" required>
                            <option value="M">Mulher</option>
                            <option value="H">Homem</option>
                        </select>
                    </div>
                </div>
                <div style="grid-column:1/3;" class="Flex">
                    <div id="SetDeficienciaInfo">
                        <p style="font-size:2em;">Possui alguma deficiencia?</p>
                        <div class="CustomSelect" id="checkboxSelect">
                            <div class="SelectHeader">Selecione opções</div>
                            <div class="OptionsContainer">
                                <?php foreach($getDeficiencias as $Deficiencia): 
                                    $Verify = false;
                                        foreach($v_Deficiencia as $UserDeficiencia){
                                            if($Deficiencia == $UserDeficiencia){
                                                $Verify = true;
                                            }
                                        }
                                    ?>
                                    <?php if($Verify == true): ?>
                                        <label class="Option">
                                            <input type="checkbox" name="DeficienciaList[]" value="<?= $Deficiencia ?>" checked>
                                            <p style="font-size:1.2em;"><?= $Deficiencia ?>:</p>
                                        </label>
                                    <?php else: ?>
                                        <label class="Option">
                                            <input type="checkbox" name="DeficienciaList[]" value="<?= $Deficiencia ?>">
                                            <p style="font-size:1.2em;"><?= $Deficiencia ?>:</p>
                                        </label>
                                    <?php endif ?>
                                <?php $Verify = false;
                                    endforeach ?>
                                <?php if(isset($getUserInfo) && !empty($getUserInfo)): ?>
                                    <input type="hidden" name="UserInfoVerify" value="1">
                                <?php else: ?>
                                    <input type="hidden" name="UserInfoVerify" value="0">
                                <?php endif ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div style="grid-column:1/3;" class="Flex">
                    <div id="EnviarSSIB" class="Flex" onclick="SubmitStartInfoBox()">ENVIAR</div>
                    <div id="CloseSSIB" class="Flex" onclick="CloseStartInfoBox()">FECHAR</div>
                </div>
            </div>
        </form>
    </div>
    <script src="infoScript.js"></script>
</body>
</html>