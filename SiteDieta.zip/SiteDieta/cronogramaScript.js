function BlackScreenShow(){
    var BlackSceen = document.getElementById("BlackScreen")
    BlackSceen.style.opacity = 0.4;
    BlackSceen.style.visibility = 'visible';
}
function BlackScreenHide(){
    var BlackSceen = document.getElementById("BlackScreen")
    BlackSceen.style.opacity = 0;
    BlackSceen.style.visibility = 'hidden';
}
var ScreenSize = false;
var MenuOpen = false;
var DropBoxIsAction = false;
var EditIsAction = false;
var C_Selecionados = [];
var table_id_value;
var Main = document.getElementById("Main");
var EditarButton = document.getElementById("EditarButton");
var Menu = document.getElementById("Menu");
var Heade = document.getElementById("header");
var AddBox = document.getElementById("AddBox");
var EditBox = document.getElementById("EditBox");
var DropBox = document.getElementById("DropBox");
var CronogramaCreateForm = document.getElementById("CronogramaCreateForm");
var CronogramaEditForm = document.getElementById("CronogramaEditForm");
var ExcluirCronograma = document.getElementById("ExcluirCronograma");
var table_id = document.getElementById("table_id");
var ScreenScrollCheck = 0;
var BoxSelectedArray = [];
const TamanhoMin = 950;

function MenuOpening(){
    if(ScreenSize == true){
        Menu.style.left = '50%';
        MenuOpen = true;
    }
    else{
        Menu.style.left = '250px';
        MenuOpen = true;
    }
}
function MenuClosing(){
    if(ScreenSize == true){
        Menu.style.left = '-600px'
        MenuOpen = false;
    }
    else{
        Menu.style.left = '-50%';
        MenuOpen = false;
    }
}
function HeaderShow(){
    if(MenuOpen==true){
        return;
    }
    Heade.style.top = '0%';
}
function HeaderHide(){
    Heade.style.top = '-100px';
}
function MenuIconOpening(){
    MenuOpening();
    HeaderHide();
    BlackScreenShow();
    localStorage.setItem("MenuAberto", true)
}
function MenuIconClosing(){
    MenuClosing();
    BlackScreenHide();
    HeaderShow();
    localStorage.setItem("MenuAberto", false)
}
function OpenCC(){
    if(DropBoxIsAction == false && EditIsAction == false){
        Main.style.opacity = '0';
        AddBox.style.top = '50%';
        HeaderHide();
        BlackScreenShow();
        localStorage.setItem("CriaCaixa", true);
    }
}
function CloseCC(){
    Main.style.opacity = '1';
    AddBox.style.top = '-100%';
    BlackScreenHide();
    HeaderShow();
    localStorage.setItem("CriaCaixa", false);
}
function CreateDiv(){
    CloseCC();
    CronogramaCreateForm.submit();
}
function OpenEB(){
    Main.style.opacity = '0';
    EditBox.style.top = '50%';
    HeaderHide();
    BlackScreenShow();
    localStorage.setItem("EditarCaixa", true);
}
function CloseEB(){
    Main.style.opacity = '1';
    EditBox.style.top = '-100%';
    BlackScreenHide();
    HeaderShow();
    EditarButton.style.backgroundColor = 'gainsboro';
    EditarButton.addEventListener("mouseover", function() {
        object.style.backgroundColor = "white";
    });
    EditarButton.addEventListener("mouseout", function() {
        object.style.backgroundColor = "gainsboro";
    });
    EditIsAction = false;
    localStorage.setItem("EditarCaixa", false);
}
function StartEB(object){
    if(EditIsAction == false && DropBoxIsAction == false){
        object.style.backgroundColor = 'deepskyblue';
        object.addEventListener("mouseover", function() {
            object.style.backgroundColor = "white";
        });
        object.addEventListener("mouseout", function() {
            object.style.backgroundColor = "deepskyblue";
        });
        EditIsAction = true;
    } else{
        object.style.backgroundColor = 'gainsboro';
        object.addEventListener("mouseover", function() {
            object.style.backgroundColor = "white";
        });
        object.addEventListener("mouseout", function() {
            object.style.backgroundColor = "gainsboro";
        });
        EditIsAction = false;
    }
}
function EndEB(){
    EditarButton.style.backgroundColor = 'gainsboro';
    EditarButton.addEventListener("mouseover", function() {
        object.style.backgroundColor = "white";
    });
    EditarButton.addEventListener("mouseout", function() {
        object.style.backgroundColor = "gainsboro";
    });
    EditIsAction = false;
    CloseEB();
    if(table_id_value > 0){
        table_id.value = table_id_value;
    } else{
        alert("Selecione um cronograma");
    }
    CronogramaEditForm.submit();
}
function Select(obj_id){
    if(EditIsAction == true && DropBoxIsAction == false){
        table_id_value = obj_id;
        OpenEB();
    } else if(EditIsAction == false && DropBoxIsAction == true){
        var obj = document.getElementById(obj_id);
        obj.style.backgroundColor = 'red';
        obj.addEventListener("mouseover", function() {
            obj.style.backgroundColor = "darksalmon";
        });
        obj.addEventListener("mouseout", function() {
            obj.style.backgroundColor = "red";
        });
        C_Selecionados.push(obj_id);
    } else if(EditIsAction == false && DropBoxIsAction == false){
        var CronogramaAberto = document.getElementById("CronogramaAberto");
        var C_Aberto = document.getElementById("C_Aberto");
        localStorage.setItem("TabelasShow", true);
        C_Aberto.value = obj_id;
        CronogramaAberto.submit();
    }
}
function DropCC(){
    if(DropBoxIsAction == false && EditIsAction == false){
        DropBoxIsAction = true;
        DropBox.style.opacity = '1';
        DropBox.style.visibility = 'visible';
    }
}
function CancelDrop(){
    DropBox.style.opacity = '0';
    DropBox.style.visibility = 'hidden';
    DropBoxIsAction = false;
    C_Selecionados.forEach(id => {
        var obj_edit = document.getElementById(id);
        obj_edit.style.backgroundColor = 'rgb(0,200,150)';
        obj_edit.addEventListener("mouseover", function() {
            obj_edit.style.backgroundColor = "rgb(0,200,150)";
        });
        obj_edit.addEventListener("mouseout", function() {
            obj_edit.style.backgroundColor = "rgb(0,200,150)";
        });
    });
    C_Selecionados = [];
}
function ConfirmDrop(){
    DropBox.style.opacity = '0';
    DropBox.style.visibility = 'hidden';
    DropBoxIsAction = false;
    var InsertSelecionados = document.getElementById("InsertSelecionados");
    if(C_Selecionados.length === 0){return;}
    InsertSelecionados.value = JSON.stringify(C_Selecionados);
    ExcluirCronograma.submit();
}

var IsDropingTable = false;
var Table_ID;
var C_TableSelecionados  = [];
var EditButtonsFromTable = document.getElementById("EditButtonsFromTable");
var EditTabelas = document.getElementById("EditTabelas");
var ShowTabelaCronogramaInfo = document.getElementById("ShowTabelaCronogramaInfo");
var Tabelas_Show = document.getElementById("Tabelas_Show");
var DefinirHorario = document.getElementById("DefinirHorario");
var DefinirTabela_Comida = document.getElementById("DefinirTabela_Comida");
var CriarTabela_Cronograma = document.getElementById("CriarTabela_Cronograma");
var DropBox2 = document.getElementById("DropBox2");
var TabelaComidasAberto = document.getElementById("TabelaComidasAberto");
var TC_Aberto = document.getElementById("TC_Aberto");

function AbrirTabelas(){
    Tabelas_Show.style.visibility = 'visible';
    Tabelas_Show.style.opacity = 1;
    Main.style.visibility = 'hidden';
    Main.style.opacity = 0;
    HeaderHide();
    localStorage.setItem("TabelasShow", true);
}
function FecharTabelas(){
    Tabelas_Show.style.visibility = 'hidden';
    Tabelas_Show.style.opacity = 0;
    Main.style.visibility = 'visble';
    Main.style.opacity = 1;
    HeaderShow();
    localStorage.setItem("TabelasShow", false);
}
function AbrirShowTabelaCronogramaInfo(){
    if(IsDropingTable == false){
        ShowTabelaCronogramaInfo.style.top = '50%';
        localStorage.setItem("ShowTabelaInfo", true);
        BlackScreenShow();
    }
}
function FecharShowTabelaCronogramaInfo(){
    var Verificar = localStorage.getItem("ShowTabelaInfo");
    if(Verificar == 'true'){
        ShowTabelaCronogramaInfo.style.top = '-100%';
        localStorage.setItem("ShowTabelaInfo", false);
        BlackScreenHide();
    }
}
function VoltarParaCronogramas(){
    if(IsDropingTable == false){
        var CronogramaFechado = document.getElementById("CronogramaFechado");
        FecharTabelas();
        CronogramaFechado.submit();
    }
}
function AbrirTableEditHorario(TB_ID){
    if(IsDropingTable == false){
        DefinirHorario.style.top = '50%';
        BlackScreenShow();
        var table_ID = document.getElementById("table_ID");
        table_ID.value = TB_ID;
    }
}
function FecharTableEditHorario(){
    DefinirHorario.style.top = '-100%';
    BlackScreenHide();
}
function alterarHorario(){
    var TableHorario = document.getElementById("TableHorario");
    var table_ID = document.getElementById("table_ID");
    if(TableHorario.value != null && table_ID.value != null){
        var TableEditHorario = document.getElementById("TableEditHorario");
        FecharTableEditComidas();
        TableEditHorario.submit();
    } else{
        alert("Preencha antes de alterar o horario!");
    }
}
function AbrirTableEditComidas(param_table_ID){
    if(IsDropingTable == false){
        DefinirTabela_Comida.style.top = '50%';
        BlackScreenShow();
        Table_ID = param_table_ID;
        TC_Aberto.value = param_table_ID;
        localStorage.setItem("TableIsOpen", true);
        TabelaComidasAberto.submit();
    }
}
function FecharTableEditComidas(Verify){
    DefinirTabela_Comida.style.top = '-100%';
    BlackScreenHide();
    Table_ID = null;
    localStorage.setItem("TableIsOpen", false);
    if(Verify == true){
        var ExcluirComidaList = document.getElementById("ExcluirComidaList");
        ExcluirComidaList.submit();
    }
}
function AlterarTableEditComidas(Index){
    var RemoverItemComidaList = document.getElementById("RemoverItemComidaList");
    var ListIndex = document.getElementById("ListIndex");
    ListIndex.value = Index;
    RemoverItemComidaList.submit();
}
function AbrirCTC_Box(){
    if(IsDropingTable == false){
        CriarTabela_Cronograma.style.top = '50%';
        BlackScreenShow();
    }
}
function FecharCTC_Box(){
    CriarTabela_Cronograma.style.top = '-100%';
    BlackScreenHide();
}
function CriarCTC(){
    var CreateTabelaCronograma = document.getElementById("CreateTabelaCronograma");
    var table_NewHorario = document.getElementById("table_NewHorario");
    if(table_NewHorario != null){
        CreateTabelaCronograma.submit();
        FecharCTC_Box();
    } else{
        alert("Preencha todas as informações antes de adicionar!");
    }
}
function AbrirECTC(){
    if(IsDropingTable == false){
        DropBox2.style.opacity = 1;
        DropBox2.style.visibility = 'visible';
        IsDropingTable = true;
    }

}
function TableSelected(TB_ID){
    if(IsDropingTable == true){
        var obj = document.getElementById(TB_ID);
        obj.style.border = 'red 5px solid';
        obj.style.marginTop = '2.5px';
        obj.addEventListener("mouseover", function() {
            obj.style.border = "darksalmon 5px solid";
        });
        obj.addEventListener("mouseout", function() {
            obj.style.border = "red 5px solid";
        });
        C_TableSelecionados.push(TB_ID);
    }
}
function ExcluirCTC(){
    DropBox2.style.opacity = '0';
    DropBox2.style.visibility = 'hidden';
    IsDropingTable = false;
    var ExcluirTable = document.getElementById("ExcluirTable");
    var InsertTableSelecionados = document.getElementById("InsertTableSelecionados");
    if(C_TableSelecionados.length === 0){return;}
    InsertTableSelecionados.value = JSON.stringify(C_TableSelecionados);
    ExcluirTable.submit();
}
function CancelarECTC(){
    DropBox2.style.opacity = '0';
    DropBox2.style.visibility = 'hidden';
    IsDropingTable = false;
    C_TableSelecionados.forEach(id => {
        var obj_edit = document.getElementById(id);
        obj_edit.style.border = 'transparent';
        obj_edit.style.marginTop = '5px';
        obj_edit.addEventListener("mouseover", function() {
            obj_edit.style.border = "transparent";
        });
        obj_edit.addEventListener("mouseout", function() {
            obj_edit.style.border = "transparent";
        });
    });
    C_TableSelecionados = [];
}

var ComidasDelete = [];
var dados = [];
var ComidaSearch = document.getElementById("ComidaSearch");
var Verificar_FoodInfo = document.getElementById("Verificar_FoodInfo");
var Exclur_ComidaList = document.getElementById("Exclur_ComidaList");
var Comida_List_SetValues = document.getElementById("Comida_List_SetValues");
var Tabela_ComidaListShow = document.getElementById("Tabela_ComidaListShow");
var RemoverItemComidaList = document.getElementById("RemoverItemComidaList");
var AlterarTableEditComidasBD = document.getElementById("AlterarTableEditComidasBD");
var RemoveItemFromFoodList2 = document.getElementById("RemoveItemFromFoodList2");
var QtdeComida = document.getElementById("QtdeComida");
var ListIndex = document.getElementById("ListIndex");
var GetItensForDelete = document.getElementById("GetItensForDelete");
var IsDropingFoodList = false;

function AdicionarComidaTable(){
    if(QtdeComida.value > 0){
        ComidaSearch.submit();
    }else{
        alert("Digite um valor acima de 0");
    }
}
function AbrirShowFoodInfoStats(){

}
function FecharShowFoodInfoStats(){
    
}
function Selecionar_ComidaList(obj){
    if(IsDropingFoodList == false){
        IsDropingFoodList = true;
        obj.style.backgroundColor = "red";
        obj.textContent = "CANCELAR";
        obj.addEventListener("mouseover", function() {
            obj.style.backgroundColor = "darkred";
        });
        obj.addEventListener("mouseout", function() {
            obj.style.backgroundColor = "red";
        });
        Tabela_ComidaListShow.addEventListener("mouseover", function() {
            Tabela_ComidaListShow.style.cursor = "default";
        });
    }else{
        IsDropingFoodList = false;
        obj.style.backgroundColor = "greenyellow";
        obj.textContent = "SELECIONAR";
        obj.addEventListener("mouseover", function() {
            obj.style.backgroundColor = "green";
        });
        obj.addEventListener("mouseout", function() {
            obj.style.backgroundColor = "greenyellow";
        });
        Tabela_ComidaListShow.addEventListener("mouseover", function() {
            Tabela_ComidaListShow.style.cursor = "pointer";
        });
    }
}
function Excluir_ComidaList(){
    ComidasDelete.forEach(info => {
        dados.push(info);
    });
    Comida_List_SetValues.value = JSON.stringify(dados);
    IsDropingFoodList = false;
    dados = [];
    Exclur_ComidaList.submit();
}
function SelecionarComida_FoodInfo(qtde, name, id){
    if(IsDropingFoodList == true){
        var Alr_Exist = false;
        if(ComidasDelete){
            ComidasDelete.forEach(info => {
                var Array_id = info[2];
                if(Array_id == id){
                    Alr_Exist = true;
                }
            });
        }
        if(Alr_Exist == false){
            value = [qtde, name, id];
            ComidasDelete.push(value);
            let newDiv = document.createElement("li");
            newDiv.style.cursor = "pointer";
            newDiv.id = "GetFoodForRemove_" + id;
            newDiv.addEventListener('click', function(){
                Alterar_RemoveTableEditComidas(id);
            });
            newDiv.textContent = qtde + "g - " + name;
            GetItensForDelete.appendChild(newDiv);
        }
    }
}
function Alterar_RemoveTableEditComidas(id){
    var getIndex = ComidasDelete.indexOf(id);
    var GetObj = document.getElementById("GetFoodForRemove_" + id);
    ComidasDelete.splice(getIndex,1);
    GetObj.remove();
}
function AlterarTableEditComidas(FoodIndex){
    if(FoodIndex == null){
        AlterarTableEditComidasBD.submit();
    }else{
        ListIndex.value = FoodIndex;
        RemoverItemComidaList.submit();
    }
}
window.addEventListener('scroll', function() {
    var verificar = localStorage.getItem("TabelasShow");
    if(MenuOpen==true || verificar==true){
        return
    }
    const scrollY = window.scrollY;
    if(ScreenScrollCheck>scrollY){
        ScreenScrollCheck = scrollY;
        Heade.style.top = '0%';
    }
    if(ScreenScrollCheck<=scrollY-100){
        ScreenScrollCheck = scrollY
        Heade.style.top = '-100px';
    }
    localStorage.setItem("ScrollSet", scrollY)
});
window.addEventListener("resize", function(){
    var MenuSize = document.getElementById("Menu");
    if(window.innerWidth < TamanhoMin){
        MenuSize.style.width = '110vw';
        AddBox.style.width = '100vw';
        AddBox.style.height = '100vh';
        if(MenuOpen == true){
            MenuSize.style.left = '50%'
            ScreenSize = true
        }
        else{
            Menu.style.left = '-600px'
            ScreenSize = true
        }
    }
    else{
        MenuSize.style.width = '600px';
        AddBox.style.width = '25vw';
        AddBox.style.height = '25vh';
        if(MenuOpen == true){
            MenuSize.style.left = '250px'
            ScreenSize = false
        }
        else{
            Menu.style.left = '-50%';
            ScreenSize = false
        }
    }
});
window.addEventListener('load', function() {
    var Status = localStorage.getItem("MenuAberto");
    var ScrollCheck = localStorage.getItem("ScrollSet");
    var CaixaCriar = localStorage.getItem("CriaCaixa");
    var EditarCaixa = localStorage.getItem("EditarCaixa");
    var ShowTabela = localStorage.getItem("TabelasShow");
    var VerificarObj = document.getElementById("Verificar");
    var TableIsOpen = localStorage.getItem("TableIsOpen");
    var VerificarTable = document.getElementById("VerificarTable");
    
    if(ShowTabela == 'true' && VerificarObj == null){
        AbrirTabelas();
    } else if(VerificarObj != null){
        localStorage.setItem("TabelasShow", false);
    }
    if(Status == 'true'){
        MenuIconOpening()
    }
    if(CaixaCriar == 'true'){
        Main.style.opacity = '0';
        AddBox.style.top = '50%';
        HeaderHide();
        BlackScreenShow();
    }
    if(EditarCaixa == 'true'){
        Main.style.opacity = '0';
        EditBox.style.top = '50%';
        HeaderHide();
        BlackScreenShow();
    }
    if(TableIsOpen == 'true' && VerificarTable != null){
        DefinirTabela_Comida.style.top = '50%';
        BlackScreenShow();
    } else if(VerificarTable == null){
        localStorage.setItem("TableIsOpen", false);
    }
    if(window.innerWidth < TamanhoMin){
        var MenuSize = document.getElementById("Menu");
        MenuSize.style.width = '110vw';
        AddBox.style.width = '100vw';
        AddBox.style.height = '100vh';
        if(MenuOpen == true){
            MenuSize.style.left = '50%'
            ScreenSize = true
        }
        else{
            Menu.style.left = '-600px'
            ScreenSize = true
        }
    }
    window.screenY = ScrollCheck
});
function Reset(){
    localStorage.setItem("MenuAberto", false)
    localStorage.setItem("ScrollCheck", null)
    localStorage.setItem("CriaCaixa", false)
    localStorage.setItem("EditarCaixa", false)
    localStorage.setItem("TabelasShow", false)
    localStorage.setItem("ShowTabelaInfo", false)
    localStorage.setItem("TableIsOpen", false)
}