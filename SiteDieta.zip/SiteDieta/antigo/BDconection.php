<?php
    $host = "localhost";
    $usuario = "root";
    $senha = "arthurpro4";
    $banco = "DB";

    $dsn = "mysql:host=$host;dbname=$banco;charset=utf8mb4";

    try {
        $conn = new PDO($dsn, $usuario, $senha, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,             // lança exceções em erro
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,        // retorna arrays associativos por padrão
            PDO::ATTR_EMULATE_PREPARES => false                      // usa prepared statements reais
        ]);
    } catch (PDOException $e) {
        die("Erro na conexão: " . $e->getMessage());
    }

    require_once 'LoginSecurity.php';

    function getFoodTabelaList($ID){
        global $conn;
        $stmt = $conn->query("SELECT Comida_Qtde,food_name FROM V_ShowList_Tabela_Comida INNER JOIN Comida_Show ON Comida_ID = id WHERE Tabela_ID = '{$ID}'");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    function getQTDE_Nutriente(){
        global $conn;
        global $ID_Usuario;
        $stmt = $conn->query("SELECT 
            qtde_kcal AS kcal,
            qtde_carboidrato AS carboidrato,
            qtde_proteina AS proteina,
            qtde_gordura_boa AS gordura_boa,
            qtde_fibra AS fibra,
            qtde_calcio AS calcio,
            qtde_fosforo AS fosforo,
            qtde_magnesio AS magnesio,
            qtde_ferro AS ferro,
            qtde_potassio AS potassio,
            qtde_sodio AS sodio,
            qtde_zinco AS zinco,
            qtde_selenio AS selenio,
            qtde_cobre AS cobre,
            qtde_vA AS vA,
            qtde_vC AS vC,
            qtde_vD AS vD,
            qtde_vE AS vE,
            qtde_vK AS vK,
            qtde_vB1 AS vB1,
            qtde_vB2 AS vB2,
            qtde_vB3 AS vB3,
            qtde_vB5 AS vB5,
            qtde_vB6 AS vB6,
            qtde_vB7 AS vB7,
            qtde_vB9 AS vB9,
            qtde_vB12 AS vB12
        FROM v_qtde_nutrientes WHERE id_Usuario = '{$ID_Usuario}'");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    function getQTDE_NutrienteEditable($TableSelected){
        global $conn;
        global $ID_Usuario;
        $stmt = $conn->query("SELECT 
            qtde_kcal AS kcal,
            qtde_carboidrato AS carboidrato,
            qtde_proteina AS proteina,
            qtde_gordura_boa AS gordura_boa,
            qtde_fibra AS fibra,
            qtde_calcio AS calcio,
            qtde_fosforo AS fosforo,
            qtde_magnesio AS magnesio,
            qtde_ferro AS ferro,
            qtde_potassio AS potassio,
            qtde_sodio AS sodio,
            qtde_zinco AS zinco,
            qtde_selenio AS selenio,
            qtde_cobre AS cobre,
            qtde_vA AS vA,
            qtde_vC AS vC,
            qtde_vD AS vD,
            qtde_vE AS vE,
            qtde_vK AS vK,
            qtde_vB1 AS vB1,
            qtde_vB2 AS vB2,
            qtde_vB3 AS vB3,
            qtde_vB5 AS vB5,
            qtde_vB6 AS vB6,
            qtde_vB7 AS vB7,
            qtde_vB9 AS vB9,
            qtde_vB12 AS vB12
        FROM V_qtde_NutrientesEditable WHERE id_Usuario = '{$ID_Usuario}' AND id = {$TableSelected}");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    function getCronograma(){
        global $conn;
        global $ID_Usuario;
        $result = $conn->query("SELECT * FROM Cronograma_Show WHERE C_idUsuario = '{$ID_Usuario}' ORDER BY C_id");
        return $result->fetchAll(PDO::FETCH_ASSOC);
    }

    function getUsuario($param_id){
        global $conn;
        $result = $conn->query("SELECT Usuario_ID,Usuario_NAME,Usuario_AGE,Usuario_EMAIL,Usuario_SENHA FROM Usuario_Show WHERE Usuario_ID = '{$param_id}'");
        return $result->fetch(PDO::FETCH_ASSOC);
    }
    
	function getComida($nomeComida)
	{
		global $conn;

        $stmt = $conn->query("CALL BuscarComida('{$nomeComida}', @param_cal, @param_carboidrato, @param_proteina, @param_gorduraBoa, @param_fibra, @param_calcio, @param_fosforo, @param_magnesio, @param_ferro, @param_potassio, @param_sodio, @param_zinco, @param_selenio, @param_cobre, @param_vA, @param_vC, @param_vD, @param_vE, @param_vK, @param_vB1, @param_vB2, @param_vB3, @param_vB5, @param_vB6, @param_vB7, @param_vB9, @param_vB12, @param_nomeComidaEncontrada);");
        $stmt->closeCursor();
        $select = $conn->query("
            SELECT
                ROUND(@param_cal, 2) AS cal,
                ROUND(@param_carboidrato, 2) AS carboidrato,
                ROUND(@param_proteina, 2) AS proteina,
                ROUND(@param_gorduraBoa, 2) AS gordura_boa,
                ROUND(@param_fibra, 2) AS fibra,
                ROUND(@param_calcio, 2) AS calcio,
                ROUND(@param_fosforo, 2) AS fosforo,
                ROUND(@param_magnesio, 2) AS magnesio,
                ROUND(@param_ferro, 2) AS ferro,
                ROUND(@param_potassio, 2) AS potassio,
                ROUND(@param_sodio, 2) AS sodio,
                ROUND(@param_zinco, 2) AS zinco,
                ROUND(@param_selenio, 2) AS selenio,
                ROUND(@param_cobre, 2) AS cobre,
                ROUND(@param_vA, 2) AS vA,
                ROUND(@param_vC, 2) AS vC,
                ROUND(@param_vD, 2) AS vD,
                ROUND(@param_vE, 2) AS vE,
                ROUND(@param_vK, 2) AS vK,
                ROUND(@param_vB1, 2) AS vB1,
                ROUND(@param_vB2, 2) AS vB2,
                ROUND(@param_vB3, 2) AS vB3,
                ROUND(@param_vB5, 2) AS vB5,
                ROUND(@param_vB6, 2) AS vB6,
                ROUND(@param_vB7, 2) AS vB7,
                ROUND(@param_vB9, 2) AS vB9,
                ROUND(@param_vB12, 2) AS vB12,
                @param_nomeComidaEncontrada AS nomeComidaEncontrada;
        ");

        return $select->fetch(PDO::FETCH_ASSOC);
	};
?>