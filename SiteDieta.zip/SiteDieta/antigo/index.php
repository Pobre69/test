<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio</title>
    <link rel="stylesheet" href="Design.css">
</head>
<body>
    <main>
        <div id="Texto">
            <h1 class="CenterAlign Negrito">Alimentação</h1>
            <h3 class="MarginTop30 CenterAlign">QUANTIDADE BASEADA EM 100g (POR DIA)</h3>
            <span> <!-- CARBOIDRATOS -->
                <h2 class="MarginTop70 MarginLeft" id="CLink">Carboidrato </h2>
                <h3 class="MarginTop30">Quantidade Diária: Peso corporal  x  6 gramas</h3>
                <h3 class="Negrito MarginTop15">Função:</h3>
                <h4 class="MarginTop15">- Os <span class="Negrito">carboidratos</span> são a principal fonte de energia para o corpo, essenciais para o funcionamento do cérebro, músculos e sistema nervoso.</h4>
                <h3 class="MarginTop50 Negrito">Informação Detalhada:</h3>
                <h4 class="MarginTop15">- Para uma alimentação saudável, é importante <span class="Negrito">priorizar carboidratos complexos</span>, como grãos integrais, legumes, vegetais e frutas, pois eles fornecem energia de forma mais estável e contêm fibras que ajudam na digestão e controle de glicose. Evite o excesso de <span class="Negrito">carboidratos simples</span>, encontrados em alimentos processados e açúcares refinados, que podem levar a picos de glicose no sangue e contribuir para ganho de peso.</h4>
                <h3 class="MarginTop50 Negrito">Melhores opções:</h3>
                <h4 class="MarginTop15">-Aveia 66g <br>
                    -Pão Branco 49g <br>
                    -Arroz Branco 28g <br>
                    -Batata 17g <br>
                    -Mandioca 38g <br>
                </h4>
            </span>
            <span> <!-- Gordura Boa -->
                <h2 class="MarginTop70 MarginLeft" id="GLink">Gordura Boa</h2>
                <h3 class="MarginTop30">Quantidade Diária: 22 a 33g</h3>
                <h3 class="Negrito MarginTop15">Melhor Opção:</h3>
                <h4 class="MarginTop15">-Azeite oliva</h4>
            </span>
            <span> <!-- Fibras -->
                <h2 class="MarginTop70 MarginLeft" id="FLink">Fibras</h2>
                <h3 class="MarginTop30">Quantidade Diária: 40 gramas</h3>
                <h3 class="Negrito MarginTop15">Função:</h3>
                <h4 class="MarginTop15">- A <span class="Negrito">fibra alimentar</span> é essencial para a saúde digestiva, ajudando a prevenir a prisão de ventre e melhorar o trânsito intestinal.</h4>
                <h3 class="MarginTop50 Negrito">Informação Detalhada:</h3>
                <h4 class="MarginTop15">- Ela também auxilia no <span class="Negrito">controle do colesterol</span>, regula os níveis de <span class="Negrito">glicose no sangue</span>, contribui para o <span class="Negrito">controle de peso</span> ao aumentar a saciedade e promove um <span class="Negrito">micro bioma intestinal saudável</span>. Para uma alimentação saudável, inclua alimentos ricos em fibra, como <span class="Negrito">frutas, vegetais, grãos integrais e leguminosas.</span></h4>
                <h3 class="MarginTop50 Negrito">Melhores opções:</h3>
                <h5 class="MarginTop30">FIBRAS INSOLUVEIS</h5>
                <h4 class="MarginTop15">-Cereais integrais 7g <br>
                    -Batata com casca 2g <br>
                    -Pera 2g <br>
                    -Feijão 2g <br>
                </h4>
                <h5 class="MarginTop50">FIBRAS SOLUVEIS</h5>
                <h4 class="MarginTop15">-Psyllium 70g <br>
                    -Aveia 4g <br>
                    -Lentilha 7g <br>
                    -Feijão 6g <br>             
                </h4>
            </span>
            <span> <!-- Proteína -->
                <h2 class="MarginTop70 MarginLeft" id="PLink">Proteína</h2>
                <h3 class="MarginTop30">Quantidade Diária: Peso corporal  x  1.6 gramas</h3>
                <h3 class="Negrito MarginTop15">Função:</h3>
                <h4 class="MarginTop15">- As <span class="Negrito">proteínas</span> são cruciais para o reparo e construção de músculos, células e tecidos.</h4>
                <h3 class="Negrito MarginTop50">Informação Detalhada:</h3>
                <h4 class="MarginTop15">- Elas também são fundamentais para a <span class="Negrito">produção de enzimas, hormônios e anticorpos</span>, além de fornecerem energia quando necessário. As proteínas são compostas por <span class="Negrito">aminoácidos</span>, que o corpo usa para diversas funções, como o fortalecimento do sistema imunológico e a recuperação após exercícios físicos.</h4>
                <h3 class="MarginTop50 Negrito">Melhores opções:</h3>
                <h4 class="MarginTop15">-Ovo 12,6g <br>
                    -Peito de frango 31g <br>
                    -Carne Bovina (Magra) 22g <br>
                    -Queijo parmesão 35g <br>
                    -Atum 23g <br>
                    -Coxa de frango 24g <br>                   
                </h4>
            </span>
            <span> <!-- Minerais -->
                <h2 class="MarginTop70 MarginLeft" id="MLink">Minerais</h2>
                <h3 class="MarginTop50 Negrito">Melhores opções:</h3>
                <!-- Calcio -->
                <h3 class="MarginTop50">Calcio – (Queijo cheddar <span class="Negrito">721mg</span>, Leite integral <span class="Negrito">113mg</span> (100g))</h5>
                <h4 class="MarginTop15"><span class="Negrito">Função:</span> Essencial para a formação e manutenção de ossos e dentes, coagulação sanguínea, função muscular, transmissão nervosa e liberação de hormônios.</h4>
                <h4 class="MarginTop15"><span class="Negrito BackRed">Excesso:</span> Embora o cálcio seja importante para a saúde óssea, um consumo excessivo pode causar pedras nos rins ou interferir na absorção de outros minerais como magnésio e zinco.</h4>
                <h4 class="MarginTop15 CenterAlign BackGray">1200mg necessários por dia (Min de 800mg – Max de 2500mg)</h4>
                <!-- Fosforo -->
                <h3 class="MarginTop50">Fósforo – (Frango cozido <span class="Negrito">200mg</span>, Feijão <span class="Negrito">280mg</span> (100g))</h5>
                <h4 class="MarginTop15"><span class="Negrito">Funções:</span> Importante para a formação de ossos e dentes, além de participar do metabolismo energético e produção de ATP.</h4>
                <h4 class="MarginTop15 CenterAlign BackGray">900mg necessários por dia (Min de 700mg – Max de 4000mg)</h4>
                <!-- Magnesio -->
                <h3 class="MarginTop50">Magnésio – (Chocolate amargo 70-80% <span class="Negrito">228mg</span>, Feijão preto <span class="Negrito">70mg</span> (100g))</h3>
                <h4 class="MarginTop15"><span class="Negrito">Função:</span> Participa em mais de 300 reações enzimáticas, incluindo a produção de energia, síntese de proteínas e função muscular e nervosa.</h4>
                <h4 class="MarginTop15"><span class="BackRed Negrito">Excesso:</span> O excesso de magnésio pode resultar em <span class="Negrito">diarreia</span>, problemas cardíacos e até parada cardíaca em casos extremos.</h4>
                <h4 class="MarginTop15 CenterAlign BackGray">400mg necessários por dia (Min de 350mg – Max de 420mg)</h4>
                <!-- Ferro -->
                <h3 class="MarginTop50">Ferro – (Fígado de boi <span class="Negrito">5mg</span>, Feijão preto <span class="Negrito">9,9mg</span> (100g))</h3>
                <h4 class="MarginTop15"><span class="Negrito">Função:</span> Importante para a produção de hemoglobina, que transporta oxigênio no sangue, e para o sistema imunológico.</h4>
                <h4 class="MarginTop15"><span class="Negrito BackRed">Excesso:</span> O ferro em excesso, especialmente em pessoas que não têm deficiência, pode causar <span class="Negrito">intoxicação</span>, levando a danos no fígado, no coração e em outros órgãos.</h4>
                <h4 class="MarginTop15 CenterAlign BackGray">20mg necessários por dia (Min de 10mg – Max de 40mg)</h4>
                <!-- Potassio -->
                <h3 class="MarginTop50">Potássio – (Banana <span class="Negrito">350mg</span>, Batata cozida <span class="Negrito">366mg</span> (100g))</h3>
                <h4 class="MarginTop15"><span class="Negrito">Função:</span> Regula o equilíbrio de fluidos, contração muscular, função nervosa e pressão arterial.</h4>
                <h4 class="MarginTop15"><span class="Negrito BackRed">Excesso:</span> O excesso de potássio pode causar <span class="Negrito">hipercalemia</span>, que afeta o funcionamento do coração, podendo levar a arritmias graves.</h4>
                <h4 class="MarginTop15 CenterAlign BackGray">4700mg necessários por dia (Min de 3500mg – Max de 5000mg)</h4>
                <!-- Sodio -->
                <h3 class="MarginTop50">Sódio – (Sal de cozinha <span class="Negrito">38758mg</span>, Queijo parmesão <span class="Negrito">1500mg</span> (100g))</h3>
                <h4 class="MarginTop15"><span class="Negrito">Função:</span> Mantém o equilíbrio de fluidos e a pressão sanguínea, além de ser importante para a função muscular e nervosa.</h4>
                <h4 class="MarginTop15"><span class="Negrito BackRed">Excesso:</span> O consumo elevado de sódio, geralmente proveniente do sal, pode levar à <span class="Negrito">hipertensão (pressão alta)</span>, aumentando o risco de doenças cardíacas e derrames.</h4>
                <h4 class="MarginTop15 CenterAlign BackGray">1700mg necessários por dia (Min de 1500mg – Max de 3000mg)</h4>
                <!-- Zinco -->
                <h3 class="MarginTop50">Zinco – (Frango <span class="Negrito">3,2mg</span>, Semente de abobora <span class="Negrito">9mg</span> (100g))</h3>
                <h4 class="MarginTop15"><span class="Negrito">Função:</span> Essencial para o sistema imunológico, cicatrização de feridas, síntese de proteínas e divisão celular.</h4>
                <h4 class="MarginTop15 CenterAlign BackGray">10mg necessários por dia (Min de 8mg – Max de 40mg)</h4>
                <!-- Iodo -->
                <h3 class="MarginTop50">Iodo – (Leite <span class="Negrito">56µg</span>, Bacalhau <span class="Negrito">99µg</span> (100g))</h3>
                <h4 class="MarginTop15"><span class="Negrito">Função:</span> Essencial para a produção dos hormônios da tireoide, que regulam o metabolismo.</h4>
                <h4 class="MarginTop15"><span class="Negrito BackRed">Excesso:</span> O consumo excessivo de iodo pode levar a <span class="Negrito">problemas na tireoide</span>, como hipertireoidismo ou hipotireoidismo, dependendo da quantidade consumida.</h4>
                <h4 class="MarginTop15 CenterAlign BackGray">170µg necessários por dia (Min de 150µg – Max de 1100µg)</h4>
                <!-- Selenio -->
                <h3 class="MarginTop50">Selênio – (Castanha do Pará <span class="Negrito">1920mcg</span>, Ovo cozido <span class="Negrito">30mcg</span> (100g))</h3>
                <h4 class="MarginTop15"><span class="Negrito">Função:</span> Antioxidante, protege as células contra danos e participa na função da tireoide e do sistema imunológico.</h4>
                <h4 class="MarginTop15 CenterAlign BackGray">60mcg necessários por dia (Min de 55mcg – Max de 400 mcg)</h4>
                <!-- Cobre -->
                <h3 class="MarginTop50">Cobre – (Fígado de boi <span class="Negrito">14mg</span>, Semente de girassol <span class="Negrito">1,8mg</span> (100g))</h3>
                <h4 class="MarginTop15"><span class="Negrito">Funções:</span> Participa da formação de hemoglobina e colágeno, metabolismo de ferro, função imunológica e saúde cardiovascular.</h4>
                <h4 class="MarginTop15 CenterAlign BackGray">2mg necessários por dia (Min de 0,9mg – Max de 10mg)</h4>
            </span>
            <span> <!-- Vitamina -->
                <h2 class="MarginTop70 MarginLeft" id="VLink">Vitamina</h2>
                <h3 class="MarginTop50 Negrito">Melhores opções:</h3>
                <!-- Vitaminas Lipossoluveis -->
                <h4 class="MarginTop15">VITAMINA LIPOSSOLÚVEL </h4>
                <!-- Vitamina A -->
                <h3 class="MarginTop50">Vitamina A – (Fígado de boi <span class="Negrito">9000mcg</span>, Cenoura <span class="Negrito">835mcg</span> (100g))</h4>
                <h4 class="MarginTop15"><span class="Negrito">Função:</span> Essencial para a visão, crescimento celular, saúde da pele e sistema imunológico.</h3>
                <h4 class="MarginTop15"><span class="Negrito BackRed">Excesso:</span> O excesso pode levar a <span class="Negrito">toxicidade, com sintomas como náuseas</span>, tontura, dor de cabeça, problemas na pele, e em casos graves, pode afetar o fígado e causar danos permanentes.</h3>
                <h4 class="MarginTop15 CenterAlign BackGray">900mcg necessários por dia (Min de 600mcg - Max de 3000mcg)</h3>
                <!-- Vitamina D -->
                <h3 class="MarginTop50">Vitamina D – (Gema de ovo 122 UI (1 Unidade))</h3>
                <h4 class="MarginTop15"><span class="Negrito">Função:</span> Regula o metabolismo do cálcio e fósforo, importante para a saúde óssea e função imunológica.</h4>
                <h4 class="MarginTop15"><span class="Negrito BackRed">Excesso:</span> O excesso pode causar <span class="Negrito">hipercalcemia (altos níveis de cálcio no sangue)</span>, levando a danos nos <span class="Negrito">rins, ossos e coração.</span></h4>
                <h4 class="MarginTop15 CenterAlign BackGray">900 UI necessários por dia (Min de 600 UI - Max de 2000 UI)</h4>
                <!-- Vitamina E -->
                <h3 class="MarginTop50">Vitamina E – (Manga 1mg, Óleo oliva <span class="Negrito">14,4mg</span>, Óleo de girassol <span class="Negrito">41mg</span> (100g))</h3>
                <h4 class="MarginTop15"><span class="Negrito">Função:</span> Antioxidante, protege as células contra danos, além de ajudar na saúde da pele e sistema imunológico.</h4>
                <h4 class="MarginTop15"><span class="Negrito BackRed">Excesso:</span> O consumo excessivo pode interferir na coagulação sanguínea e aumentar o risco de <span class="Negrito">Infarto</span>.</h4>
                <h4 class="MarginTop15 CenterAlign BackGray">30mg necessários por dia (Min de 15mg - Max de 1000mg)</h4>
                <!-- Vitamina K -->
                <h3 class="MarginTop50">Vitamina K – (Alface romana <span class="Negrito">126mcg</span>, Couve <span class="Negrito">1100mcg</span> (100g))</h3>
                <h4 class="MarginTop15"><span class="Negrito">Função:</span> Essencial para a coagulação sanguínea e saúde óssea.</h4>
                <h4 class="MarginTop15"><span class="Negrito BackRed">Excesso:</span> Embora seja rara, a toxicidade de vitamina K pode <span class="Negrito">interferir na coagulação sanguínea</span>, causando problemas circulatórios.</h4>
                <h4 class="MarginTop15 CenterAlign BackGray">120mcg necessários por dia (Min de 90mcg – Max quase ilimitado)</h4>
                <!-- Vitaminas Hidrossoluveis -->
                <h4 class="MarginTop70">VITAMINA HIDROSSOLÚVEL</h4>
                <h4 class="MarginTop30"><span class="Negrito BackRed">Atenção:</span> O excesso de <span class="Negrito">vitamina B6</span>, por exemplo, pode causar <span class="Negrito">danos aos nervos (neuropatia)</span>, e o excesso de <span class="Negrito">ácido fólico</span> pode mascarar uma deficiência de <span class="Negrito">vitamina B12</span>, o que pode prejudicar o diagnóstico de condições graves.</h4>
                <!-- Vitamina C -->
                <h3 class="MarginTop50">Vitamina C – (Laranja <span class="Negrito">53mg</span>, Acerola <span class="Negrito">1800mg</span>, Limonada <span class="Negrito">78mg</span> (100g))</h3>
                <h4 class="MarginTop15"><span class="Negrito">Função:</span> Antioxidante, ajuda na absorção de ferro, e é essencial para o sistema imunológico e produção de colágeno.</h4>
                <h4 class="MarginTop15"><span class="Negrito BackRed">Excesso:</span> Doses muito altas podem levar a <span class="Negrito">distúrbios digestivos</span>, como diarreia e cólicas.</h4>
                <h4 class="MarginTop15 CenterAlign BackGray">100mg necessários por dia (Min de 75mg – Max de 2000mg)</h4>
                <!-- Vitamina B1 -->
                <h3 class="MarginTop50">Vitamina B1 – (Cereal integral <span class="Negrito">290mcg</span>, 1 Gema de ovo <span class="Negrito">20mcg</span> (100g))</h3>
                <h4 class="MarginTop15"><span class="Negrito">Função:</span> Participa no metabolismo de carboidratos e no funcionamento do sistema nervoso.</h4>
                <h4 class="MarginTop15 CenterAlign BackGray">1600mcg necessários por dia (Min de 1200mcg – Max quase ilimitado)</h4>
                <!-- Vitamina B2 -->
                <h3 class="MarginTop50">Vitamina B2 – (Fígado de boi <span class="Negrito">3,6mg</span>, Ovo <span class="Negrito">0,5mg</span> (100g))</h3>
                <h4 class="MarginTop15"><span class="Negrito">Função:</span> Ajuda na produção de energia, saúde da pele, visão e sistema nervoso.</h4>
                <h4 class="MarginTop15 CenterAlign BackGray">1700mcg necessários por dia (Min de 1300mcg – Max quase ilimitado)</h4>
                <!-- Vitamina B3 -->
                <h3 class="MarginTop50">Vitamina B3 – (Peito de frango <span class="Negrito">13,4mg</span>, Atum em conserva <span class="Negrito">17,9 mg</span> (100g))</h3>
                <h4 class="MarginTop15"><span class="Negrito">Função:</span> Auxilia no metabolismo de carboidratos, lipídios e proteínas, além de ser importante para a função da pele e sistema nervoso.</h4>
                <h4 class="MarginTop15 CenterAlign BackGray">20mg necessários por dia (Min de 16mg – Max de 35mg)</h4>
                <!-- Vitamina B5 -->
                <h3 class="MarginTop50">Vitamina B5 – (Fígado de boi <span class="Negrito">8,3mg</span>, Ovos <span class="Negrito">1,4mg</span>(100g))</h3>
                <h4 class="MarginTop15"><span class="Negrito">Função:</span> Essencial para a produção de energia, síntese de hormônios e metabolismo das gorduras.</h4>
                <h4 class="MarginTop15 CenterAlign BackGray">7mg necessários por dia (Min de 5mg – Max quase ilimitado)</h4>
                <!-- Vitamina B6 -->
                <h3 class="MarginTop50">Vitamina B6 – (Peito de frango <span class="Negrito">900mcg</span>, Banana <span class="Negrito">400mcg</span>, Batata cozida <span class="Negrito">300mcg</span> (100g))</h3>
                <h4 class="MarginTop15"><span class="Negrito">Função:</span> Participa do metabolismo das proteínas e da produção de neurotransmissores.</h4>
                <h4 class="MarginTop15 CenterAlign BackGray">2000mcg necessários por dia (Min de 1300mcg – Max de 100000mcg)</h4>
                <!-- Vitamina B7 -->
                <h3 class="MarginTop50">Vitamina B7 – (Ovos <span class="Negrito">20mcg</span>, Fígado de boi <span class="Negrito">100mcg</span> (100g))</h3>
                <h4 class="MarginTop15"><span class="Negrito">Função:</span> Importante para o metabolismo de carboidratos, gorduras e proteínas, além de ser benéfica para a saúde da pele, cabelo e unhas.</h4>
                <h4 class="MarginTop15 CenterAlign BackGray">40mcg necessários por dia (Min de 30mcg – Max quase ilimitado)</h4>
                <!-- Vitamina B9 -->
                <h3 class="MarginTop50">Vitamina B9 – (Fígado de boi <span class="Negrito">290mcg</span>, Feijão <span class="Negrito">130mcg</span> (100g))</h3>
                <h4 class="MarginTop15"><span class="Negrito">Função:</span> Essencial para a produção e manutenção das células e para a síntese de DNA, crucial durante a gravidez.</h4>
                <h4 class="MarginTop15 CenterAlign BackGray">600mcg necessários por dia (Min de 400mcg – Max de 1000mcg)</h4>
                <!-- Vitamina B12 -->
                <h3 class="MarginTop50">Vitamina B12 – (Fígado de boi <span class="Negrito">70mcg</span>, Queijo suíço <span class="Negrito">3,1mcg</span> (100g))</h3>
                <h4 class="MarginTop15"><span class="Negrito">Função:</span> Fundamental para a formação de glóbulos vermelhos, função cerebral e síntese de DNA.</h4>
                <h4 class="MarginTop15 CenterAlign BackGray">2,7mcg necessários por dia (Min de 2,4mcg – Max quase ilimitado)</h4>
            </span>
        </div>
    </main>
    <div id="BlackScreen"></div>
    <div id="Menu"><img src="MenuIcon.png" id="MenuIcon2" onclick="MenuIconClosing()" alt="">
        <div id="Links">
            <div class="MarginTop15"><a href="infoSecurity.php" onclick="Reset()">Informações</a></div>
            <div class="MarginTop15"><a href="cronogramaSecurity.php" onclick="Reset()">Cronogramas</a></div>
            <div class="MarginTop15"><a href="bdSecurity.php"  onclick="Reset()">Banco de Dados</a></div>
        </div>
    </div>
    <header id="header">
        <img src="MenuIcon.png" id="MenuIcon" onclick="MenuIconOpening()" alt="">
        <div id="MenuLinkDivision">
            <div class="Margin" onclick="Carboidrato()"><h3>Carboidratos</h3></div>
            <div class="Margin" onclick="Gordura()"><h3>Gordura Boa</h3></div>
            <div class="Margin" onclick="Fibra()"><h3>Fibras</h3></div>
            <div class="Margin" onclick="Proteina()"><h3>Proteína</h3></div>
            <div class="Margin" onclick="Minerais()"><h3>Minerais</h3></div>
            <div class="Margin" onclick="Vitamina()"><h3>Vitamina</h3></div>
        </div>
    </header>
    <script src="Script.js"></script>
</body>
</html>