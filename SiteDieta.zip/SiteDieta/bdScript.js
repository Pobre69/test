function BlackScreenShow(){
    var BlackSceen = document.getElementById("BlackScreen")
    BlackSceen.style.opacity = 0.4;
    BlackSceen.style.visibility = 'visible';
}
function BlackScreenHide(){
    var BlackSceen = document.getElementById("BlackScreen")
    BlackSceen.style.opacity = 0;
    BlackSceen.style.visibility = 'hidden';
}
var ScreenSize = false;
var MenuOpen = false;
var InfoComidaBox = false;
var Menu = document.getElementById("Menu");
var Heade = document.getElementById("header");
var BoxInfoComida = document.getElementById("ShowFoodInfo");
const TamanhoMin = 950;

function ShowBoxInfoComida(){
    BoxInfoComida.style.opacity = '1';
    BoxInfoComida.style.visibility = 'visible';
    InfoComidaBox = true;
}
function HideBoxInfoComida(){
    BoxInfoComida.style.opacity = '0';
    BoxInfoComida.style.visibility = 'hidden';
    InfoComidaBox = false;
}
function FecharInfoComida(){
    if(InfoComidaBox == true){
        BlackScreenHide();
        HideBoxInfoComida();
        HeaderShow();
        localStorage.setItem("AbrirInfoComidaBox", false);
    }
}
function InfoComidaCaixa(){
    BlackScreenShow();
    ShowBoxInfoComida();
    HeaderHide();
}
function AbrirInfoComida(form){
    localStorage.setItem("AbrirInfoComidaBox", true);
    document.getElementById(form).submit();
}

function MenuOpening(){
    if(ScreenSize == true){
        Menu.style.left = '50%';
        MenuOpen = true;
    }
    else{
        Menu.style.left = '250px';
        MenuOpen = true;
    }
}
function MenuClosing(){
    if(ScreenSize == true){
        Menu.style.left = '-600px'
        MenuOpen = false;
    }
    else{
        Menu.style.left = '-50%';
        MenuOpen = false;
    }
}
function HeaderShow(){
    if(MenuOpen==true && InfoComidaBox==true){
        return;
    }
    Heade.style.top = '0%';
}
function HeaderHide(){
    Heade.style.top = '-100px';
}
function MenuIconOpening(){
    MenuOpening();
    HeaderHide();
    BlackScreenShow();
    localStorage.setItem("MenuAberto", true)
}
function MenuIconClosing(){
    MenuClosing();
    BlackScreenHide();
    HeaderShow();
    localStorage.setItem("MenuAberto", false)
}
var ScreenScrollCheck = 0
window.addEventListener('scroll', function() {
    if(MenuOpen==true && InfoComidaBox==true){
        return
    }
    const scrollY = window.scrollY;
    if(ScreenScrollCheck>scrollY){
        ScreenScrollCheck = scrollY;
        Heade.style.top = '0%';
    }
    if(ScreenScrollCheck<=scrollY-100){
        ScreenScrollCheck = scrollY
        Heade.style.top = '-100px';
    }
    localStorage.setItem("ScrollSet", scrollY)
});
window.addEventListener("resize", function(){
    var MenuLinks = document.getElementById("MenuLinkDivision");
    var MenuSize = document.getElementById("Menu");
    if(window.innerWidth < TamanhoMin){
        MenuLinks.style.opacity = 0;
        MenuLinks.style.visibility = 'hidden';
        BoxInfoComida.style.width = '100vw';
        BoxInfoComida.style.height = '100vh';
        MenuSize.style.width = '110vw';
        if(MenuOpen == true){
            MenuSize.style.left = '50%'
            ScreenSize = true
        }
        else{
            Menu.style.left = '-600px'
            ScreenSize = true
        }
    }
    else{
        MenuLinks.style.opacity = 1;
        MenuLinks.style.visibility = 'visible';
        BoxInfoComida.style.width = '60vw';
        BoxInfoComida.style.height = '60vh';
        MenuSize.style.width = '600px';
        if(MenuOpen == true){
            MenuSize.style.left = '250px'
            ScreenSize = false
        }
        else{
            Menu.style.left = '-50%';
            ScreenSize = false
        }
    }
});
window.addEventListener('load', function() {
    var Status = localStorage.getItem("MenuAberto")
    var ScrollCheck = localStorage.getItem("ScrollSet")
    var BoxInfoComidaVerify = localStorage.getItem("AbrirInfoComidaBox");
    if(BoxInfoComidaVerify == 'true'){
        InfoComidaCaixa();
    }
    if(Status == 'true'){
        MenuIconOpening()
    }
    if(window.innerWidth < TamanhoMin){
        var MenuLinks = document.getElementById("MenuLinkDivision");
        var MenuSize = document.getElementById("Menu");
        MenuLinks.style.opacity = 0;
        MenuLinks.style.visibility = 'hidden';
        MenuSize.style.width = '110vw';
        if(MenuOpen == true){
            MenuSize.style.left = '50%'
            ScreenSize = true
        }
        else{
            Menu.style.left = '-600px'
            ScreenSize = true
        }
    }
    window.screenY = ScrollCheck
});
function Reset(){
    localStorage.setItem("MenuAberto", false)
    localStorage.setItem("ScrollCheck", null)
}