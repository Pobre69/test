<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cronograma</title>
    <link rel="stylesheet" href="cronogramaDesign.css">
    <?php
        require_once 'BDconection.php';
        include_once 'LoginSecurity.php';

        date_default_timezone_set('America/Sao_Paulo');

        $QTDE_Nutriente_Info = getQTDE_Nutriente();
        $Cronograma_Table_Show = getCronograma();
        $bdFoodTableSearch = [];
        $CronogramaSelecionadoID = null;
        $TabelaSelecionadaID = null;

        if(isset($_POST['table_name']) && !empty($_POST['table_name']) && $_SESSION['id'] > 0){
            global $conn;
            $getEmail = $conn->query("SELECT Usuario_EMAIL FROM Usuario_Show WHERE Usuario_ID = '{$_SESSION['id']}'");
            $emailData = $getEmail->fetch(PDO::FETCH_ASSOC);
            
            $email = $emailData['Usuario_EMAIL'];
            $table_name = $_POST['table_name'];
            $dia = date("Y-m-d");
            $hora = date("H:i:s");

            $stmt = $conn->query("CALL CriarCronograma('{$email}','{$table_name}','{$dia}','{$hora}')");
            $stmt->closeCursor();
            unset($_POST['table_name']);
            header("Location: cronogramaSecurity.php");
            exit;
        }
        if(isset($_POST['table_newname']) && !empty($_POST['table_newname']) && $_SESSION['id'] > 0){
            global $conn;
            $getEmail = $conn->query("SELECT Usuario_EMAIL FROM Usuario_Show WHERE Usuario_ID = '{$_SESSION['id']}'");
            $emailData = $getEmail->fetch(PDO::FETCH_ASSOC);
            
            $email = $emailData['Usuario_EMAIL'];
            $table_newname = $_POST['table_newname'];
            $table_id = $_POST['table_id'];

            $stmt = $conn->query("CALL AlterarCronograma('{$email}','{$table_newname}','{$table_id}')");
            $stmt->closeCursor();
            unset($_POST['table_newname']);
            unset($_POST['table_id']);
            header("Location: cronogramaSecurity.php");
            exit;
        }
        if(isset($_POST['C_Selecionados']) && !empty($_POST['C_Selecionados']) && $_SESSION['id'] > 0){
            $selecionados = json_decode($_POST['C_Selecionados'], true);
            if (is_array($selecionados)) {
                foreach ($selecionados as $idCronograma) {
                    global $conn;
                    $getEmail = $conn->query("SELECT * FROM Usuario_Show WHERE Usuario_ID = '{$_SESSION['id']}'");

                    $emailData = $getEmail->fetch(PDO::FETCH_ASSOC);
                    $email = $emailData['Usuario_EMAIL'];

                    $getCronogramaInfo = $conn->query("SELECT * FROM Cronograma_Show WHERE C_id = '{$idCronograma}'");
                    $cronogramaData = $getCronogramaInfo->fetch(PDO::FETCH_ASSOC);

                    $table_name = $cronogramaData['C_tableName'];
                    $table_date = $cronogramaData['C_tableDate'];
                    $table_time = $cronogramaData['C_tableTime'];

                    $stmt = $conn->query("CALL ExcluirCronograma('{$email}','{$table_name}','{$table_date}','{$table_time}','{$idCronograma}')");
                    $stmt->closeCursor();
                }
            }
            unset($_POST['C_Selecionados']);
            header("Location: cronogramaSecurity.php");
            exit;
        }
        if(isset($_POST['C_Fechado'])){
            unset($_POST['C_Aberto']);
            unset($_POST['C_Fechado']);
            header("Location: cronogramaSecurity.php");
            exit;
        }
        if(isset($_POST['C_Aberto']) && !empty($_POST['C_Aberto']) && $_SESSION['id'] > 0){
            global $CronogramaSelecionadoID;
            $CronogramaSelecionadoID = intval($_POST['C_Aberto']);
        }
        if(isset($_POST['table_NewHorario']) && !empty($_POST['table_NewHorario']) && $_SESSION['id'] > 0 && isset($_POST['C_Aberto2']) && !empty($_POST['C_Aberto2'])){
            global $conn;
            global $ID_Usuario;
            global $CronogramaSelecionadoID;
            
            $CronogramaSelecionadoID = $_POST['C_Aberto2'];
            $_POST['C_Aberto'] = $_POST['C_Aberto2'];

            $getEmail = $conn->query("SELECT * FROM Usuario_Show WHERE Usuario_ID = '{$_SESSION['id']}'");

            $emailData = $getEmail->fetch(PDO::FETCH_ASSOC);
            $email = $emailData['Usuario_EMAIL'];

            $getTableName = $conn->query("SELECT * FROM Cronograma_Show WHERE C_idUsuario = '{$_SESSION['id']}' AND C_id = '{$CronogramaSelecionadoID}'");

            $tableData = $getTableName->fetch(PDO::FETCH_ASSOC);
            $tableName = $tableData['C_tableName'];

            $TableHorario = $_POST['table_NewHorario'];

            $stmt = $conn->query("CALL CriarTabela_Cronograma('{$email}','{$TableHorario}','{$tableName}')");
            $stmt->closeCursor();
            unset($_POST['table_NewHorario']);
        }
        if(isset($_POST['table_Horario']) && !empty($_POST['table_Horario']) && $_SESSION['id'] > 0 && isset($_POST['table_ID']) && !empty($_POST['table_ID']) && isset($_POST['C_Aberto3']) && !empty($_POST['C_Aberto3'])){
            global $CronogramaSelecionadoID;
            global $conn;

            $CronogramaSelecionadoID = $_POST['C_Aberto3'];
            $_POST['C_Aberto'] = $_POST['C_Aberto3'];

            $HorarioNovo = $_POST['table_Horario'];
            $tableID = $_POST['table_ID'];

            $stmt = $conn->query("CALL AlterarTabela_Cronograma('{$HorarioNovo}','{$tableID}','{$CronogramaSelecionadoID}')");
            $stmt->closeCursor();

            unset($_POST['table_Horario']);
            unset($_POST['table_ID']);
        }
        if(isset($_POST['C_TableSelecionados']) && !empty($_POST['C_TableSelecionados']) && $_SESSION['id'] > 0 && isset($_POST['C_Aberto4']) && !empty($_POST['C_Aberto4'])){
            $selecionados = json_decode($_POST['C_TableSelecionados'], true);
            if(is_array($selecionados)) {
                foreach ($selecionados as $idTable) {
                    global $CronogramaSelecionadoID;
                    global $conn;

                    $CronogramaSelecionadoID = $_POST['C_Aberto4'];
                    $_POST['C_Aberto'] = $_POST['C_Aberto4'];

                    $getTableName = $conn->query("SELECT * FROM Cronograma_Show WHERE C_idUsuario = '{$_SESSION['id']}' AND C_id = '{$CronogramaSelecionadoID}'");

                    $tableData = $getTableName->fetch(PDO::FETCH_ASSOC);
                    $tableName = $tableData['C_tableName'];
                    
                    $getEmail = $conn->query("SELECT * FROM Usuario_Show WHERE Usuario_ID = '{$_SESSION['id']}'");

                    $emailData = $getEmail->fetch(PDO::FETCH_ASSOC);
                    $email = $emailData['Usuario_EMAIL'];

                    $stmt = $conn->query("CALL ExcluirTabela_Cronograma('{$email}','{$tableName}','{$idTable}')");
                    $stmt->closeCursor();
                }
            }
            unset($_POST['C_TableSelecionados']);
        }
        if(isset($_POST['TC_Aberto']) && !empty($_POST['TC_Aberto']) && $_SESSION['id'] > 0 && isset($_POST['C_Aberto6']) && !empty($_POST['C_Aberto6'])){
            global $TabelaSelecionadaID;
            global $CronogramaSelecionadoID;
            $TabelaSelecionadaID = intval($_POST['TC_Aberto']);
            $CronogramaSelecionadoID = $_POST['C_Aberto6'];
            $_POST['C_Aberto'] = $_POST['C_Aberto6'];
        }
        if(isset($_POST['ComidaName']) && !empty($_POST['ComidaName']) && $_SESSION['id'] > 0 && isset($_POST['C_Aberto5']) && !empty($_POST['C_Aberto5']) && isset($_POST['TC_Aberto2']) && !empty($_POST['TC_Aberto2']) && isset($_POST['qtdeComida']) && !empty($_POST['qtdeComida'])){
            global $CronogramaSelecionadoID;
            global $TabelaSelecionadaID;

            $CronogramaSelecionadoID = $_POST['C_Aberto5'];
            $_POST['C_Aberto'] = $_POST['C_Aberto5'];

            $TabelaSelecionadaID = $_POST['TC_Aberto2'];
            $_POST['TC_Aberto'] = $_POST['TC_Aberto2'];

            $bdFoodTableSearch = getComida($_POST['ComidaName']);
            $FoodQTDE = $_POST['qtdeComida'];
            $Value = [];
            $Value[] = $FoodQTDE;
            $Value[] = $bdFoodTableSearch;
            $IsExist = false;

            foreach ($_SESSION['FoodListForAdd'] as $item) {
                if ($item[0] == $FoodQTDE && $item[1] == $bdFoodTableSearch) {
                    $IsExist = true;
                    break;
                }
            }

            if (!$IsExist) {
                $_SESSION['FoodListForAdd'][] = $Value;
            }
        }
        if(isset($_POST['ListIndex']) && $_SESSION['id'] > 0 && isset($_POST['TC_Aberto3']) && !empty($_POST['TC_Aberto3']) && isset($_POST['C_Aberto8']) && !empty($_POST['C_Aberto8'])){
            global $CronogramaSelecionadoID;
            global $TabelaSelecionadaID;

            $CronogramaSelecionadoID = $_POST['C_Aberto8'];
            $_POST['C_Aberto'] = $_POST['C_Aberto8'];

            $TabelaSelecionadaID = $_POST['TC_Aberto3'];
            $_POST['TC_Aberto'] = $_POST['TC_Aberto3'];

            $index = $_POST['ListIndex'];

            if(isset($_SESSION['FoodListForAdd'][$index])){
                unset($_SESSION['FoodListForAdd'][$index]);
            }
            $_SESSION['FoodListForAdd'] = array_values($_SESSION['FoodListForAdd']);

            unset($_POST['ListIndex']);
        }
        if(isset($_POST['Excluir_ComidaList']) && !empty($_POST['Excluir_ComidaList']) && $_SESSION['id'] > 0 && isset($_POST['TC_Aberto4']) && !empty($_POST['TC_Aberto4']) && isset($_POST['C_Aberto9']) && !empty($_POST['C_Aberto9'])){
            global $conn;
            global $TabelaSelecionadaID;
            global $CronogramaSelecionadoID;

            $CronogramaSelecionadoID = $_POST['C_Aberto9'];
            $_POST['C_Aberto'] = $_POST['C_Aberto9'];

            $TabelaSelecionadaID = $_POST['TC_Aberto4'];
            $_POST['TC_Aberto'] = $_POST['TC_Aberto4'];

            $dados = json_decode($_POST['Excluir_ComidaList'], true);
            $result = [];

            foreach($dados as $dado){
                $qtde = (int)$dado[0];
                $nome = $dado[1];
                $stmt = $conn->query("SELECT Tabela_ID,food_name,Comida_Qtde FROM V_ShowList_Tabela_Comida INNER JOIN V_TabelasCronograma ON TB_ID = Tabela_ID INNER JOIN Cronograma_Show ON C_id = TB_idCronograma INNER JOIN Comida_Show ON id = Comida_ID WHERE Comida_Qtde = '{$qtde}' AND food_name = '{$nome}' AND Tabela_ID = '{$TabelaSelecionadaID}'");
                $result[] = $stmt->fetchAll(PDO::FETCH_ASSOC);
            }
            foreach($result as $grupo){
                foreach($grupo as $clear){
                    $id_tabela = (int)$clear['Tabela_ID'];
                    $nome_comida = $clear['food_name'];
                    $qtde_comida = (int)$clear['Comida_Qtde'];
                    $IsAdding = 0;
                    
                    $excluir = $conn->query("CALL AlterarTabela_Comida({$id_tabela},{$qtde_comida},'{$nome_comida}',{$IsAdding})");
                    $excluir->closeCursor();
                }
            }
        }
        if(isset($_POST['AlterarTableEditComidasBD']) && $_SESSION['id'] > 0 && isset($_POST['TC_Aberto5']) && !empty($_POST['TC_Aberto5']) && isset($_POST['C_Aberto10']) && !empty($_POST['C_Aberto10'])){
            global $conn;
            global $TabelaSelecionadaID;
            global $CronogramaSelecionadoID;

            $CronogramaSelecionadoID = $_POST['C_Aberto10'];
            $_POST['C_Aberto'] = $_POST['C_Aberto10'];

            $TabelaSelecionadaID = $_POST['TC_Aberto5'];
            $_POST['TC_Aberto'] = $_POST['TC_Aberto5'];

            $verifyIfExist = $conn->query("SELECT COUNT(*) AS Exist FROM V_ShowList_Tabela_Comida INNER JOIN V_TabelasCronograma ON TB_ID = Tabela_ID WHERE Tabela_ID = '{$TabelaSelecionadaID}' AND TB_idCronograma = '{$CronogramaSelecionadoID}'");
            $return = $verifyIfExist->fetch(PDO::FETCH_ASSOC);
            if($return['Exist'] > 0){
                foreach($_SESSION['FoodListForAdd'] as $comida){
                    $Food_Info = $comida[1];
                    $Food = $Food_Info['nomeComidaEncontrada'];
                    $qtdeFood = $comida[0];
                    $IsAdding = true;

                    $stmt = $conn->query("CALL AlterarTabela_Comida('{$TabelaSelecionadaID}','{$qtdeFood}','{$Food}',{$IsAdding})");
                    $stmt->closeCursor();
                }
            }else{
                foreach($_SESSION['FoodListForAdd'] as $index => $comida){
                    $Food_Info = $comida[1];
                    $Food = $Food_Info['nomeComidaEncontrada'];
                    $qtdeFood = $comida[0];
                    $IsAdding = true;

                    if($index = 1){
                        $stmt = $conn->query("CALL CriarTabela_Comida('{$TabelaSelecionadaID}','{$qtdeFood}','{$Food}')");
                        $stmt->closeCursor();
                    }else{
                        $stmt = $conn->query("CALL AlterarTabela_Comida('{$TabelaSelecionadaID}','{$qtdeFood}','{$Food}',{$IsAdding})");
                        $stmt->closeCursor();
                    }
                }
            }
            $_SESSION['FoodListForAdd'] = [];
        }
        if(isset($_POST['ExcluirComidaList'])){
            global $CronogramaSelecionadoID;

            $CronogramaSelecionadoID = $_POST['C_Aberto7'];
            $_POST['C_Aberto'] = $_POST['C_Aberto7'];

            $_SESSION['FoodListForAdd'] = [];
        }
        if(!isset($_POST['TC_Aberto'])){
            $_SESSION['FoodListForAdd'] = [];
        }

        function FindCronograma(){
            global $CronogramaSelecionadoID;
            if(!empty($CronogramaSelecionadoID)){
                global $conn;
                $stmt = $conn->query("SELECT * FROM Cronograma_Show WHERE C_id = '{$CronogramaSelecionadoID}'");
                return $stmt->fetch(PDO::FETCH_ASSOC);
            }
            else{
                return null;
            }
        }

        $CronogramaInfo = FindCronograma();

        function getTabela_Cronograma(){
            global $conn;
            global $ID_Usuario;
            global $CronogramaSelecionadoID;
            $stmt = $conn->query("
                SELECT 
                    TB_ID, 
                    TB_idCronograma, 
                    TB_Horario 
                FROM 
                    V_TabelasCronograma
                        INNER JOIN Cronograma_Show ON TB_idCronograma = C_id
                WHERE
                    C_idUsuario = '{$ID_Usuario}'
                    AND TB_idCronograma = '{$CronogramaSelecionadoID}'
                ORDER BY
                    TB_Horario
            ");
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        }

        $Cronograma_Tabelas = getTabela_Cronograma();

        function getFoodListInfo(){
            global $conn;
            global $CronogramaSelecionadoID;
            global $TabelaSelecionadaID;

            if(isset($CronogramaSelecionadoID) && !empty($CronogramaSelecionadoID) && isset($TabelaSelecionadaID) && !empty($TabelaSelecionadaID)){
                $stmt = $conn->query("SELECT COUNT(*) AS Quantidade FROM V_TabelasCronograma WHERE TB_ID = '{$TabelaSelecionadaID}' AND TB_idCronograma = '{$CronogramaSelecionadoID}'");
                $result = $stmt->fetch(PDO::FETCH_ASSOC);
                $stmt->closeCursor();
                
                if($result && $result['Quantidade'] > 0){
                    return getFoodTabelaList($TabelaSelecionadaID);
                }
            }
            return null;
        }

        $Tabela_FoodListInfo = getFoodListInfo();
    ?>
</head>
<body>
    <div id="BlackScreen" onclick="FecharShowTabelaCronogramaInfo()"></div>
    <div id="Menu"><img src="MenuIcon.png" id="MenuIcon2" onclick="MenuIconClosing()" alt="">
        <div id="Links">
            <div class="MarginTop15"><a href="index.html" onclick="Reset()">Menu</a></div>
            <div class="MarginTop15"><a href="infoSecurity.php" onclick="Reset()">Informações</a></div>
            <div class="MarginTop15"><a href="bdSecurity.php" onclick="Reset()">Banco de Dados</a></div>
        </div>
    </div>
    <div id="DropBox">
        <div class="DropBoxButton" id="Drop" onclick="ConfirmDrop()">Excluir</div>
        <div class="DropBoxButton" id="Back" onclick="CancelDrop()">Cancelar</div>
    </div>
    <div id="EditBox">
        <?php if(isset($_SESSION['id']) && $_SESSION['id'] > 0): ?>
            <p style="width: 100%;text-align:center;font-size:2em;"><strong>Digite o Nome</strong></p>
            <form id="CronogramaEditForm" style="margin-top: 20px;" action="cronogramaSecurity.php" method="post">
                <input style="width: 100%; height: 20px;" type="text" 
                    name="table_newname" id="CronogramaText" 
                    placeholder="Digite o nome" maxlength="20"
                >
                <input type="hidden" id="table_id" name="table_id" value="">
                <div style="display:flex;justify-content:center;width: 100%;">
                    <div class="CriarCronograma" id="Create" onclick="EndEB()">
                        Alterar
                    </div>
                    <div class="CriarCronograma" id="Close" onclick="CloseEB()">
                        Fechar
                    </div>
                </div>
            </form>
        <?php else: ?>
            <p style="width: 100%; text-align: center; font-size: 2em;"><strong>Faça o login antes</strong></p>
            <div id="Close2" onclick="CloseEB()">
                Fechar
            </div>
        <?php endif ?>
    </div>
    <div id="AddBox">
        <?php if(isset($_SESSION['id']) && $_SESSION['id'] > 0): ?>
            <p style="width: 100%; text-align: center; font-size: 2em;"><strong>Digite o Nome</strong></p>
            <form id="CronogramaCreateForm" style="margin-top: 20px;" action="cronogramaSecurity.php" method="post">
                <input style="width: 100%; height: 20px;" type="text" 
                    name="table_name" id="CronogramaText" 
                    placeholder="Digite o nome" maxlength="20"
                >
                <div style="display: flex;justify-content: center;width: 100%;">
                    <div class="CriarCronograma" id="Create" onclick="CreateDiv()">
                        Criar
                    </div>
                    <div class="CriarCronograma" id="Close" onclick="CloseCC()">
                        Fechar
                    </div>
                </div>
            </form>
        <?php else: ?>
            <p style="width: 100%; text-align: center; font-size: 2em;"><strong>Faça o login antes</strong></p>
            <div id="Close2" onclick="CloseCC()">
                Fechar
            </div>
        <?php endif ?>
    </div>
    <header id="header">
        <img src="MenuIcon.png" id="MenuIcon" onclick="MenuIconOpening()" alt="">
        <div id="MenuLinkDivision">
            <div class="Margin" onclick="StartEB(this)" id="EditarButton">Editar Nome</div>
            <div class="Margin" onclick="DropCC()">Excluir Cronograma</div>
        </div>
    </header>
    <form action="cronogramaSecurity.php" id="ExcluirCronograma" method="post">
        <input type="hidden" value="" name="C_Selecionados" id="InsertSelecionados">
    </form>
    <form action="cronogramaSecurity.php" id="CronogramaAberto" method="post">
        <input type="hidden" value="" name="C_Aberto" id="C_Aberto">
    </form>
    <form action="cronogramaSecurity.php" id="CronogramaFechado" method="post">
        <input type="hidden" name="C_Fechado">
    </form>
    <form action="cronogramaSecurity.php" id="ExcluirTable" method="post">
        <input type="hidden" value="" name="C_TableSelecionados" id="InsertTableSelecionados">
        <?php if(isset($_POST['C_Aberto']) && !empty($_POST['C_Aberto']) && $_SESSION['id'] > 0): ?>
            <input type="hidden" value="<?= $_POST['C_Aberto']?>" name="C_Aberto4">
        <?php endif ?>
    </form>
    <form action="cronogramaSecurity.php" id="TabelaComidasAberto" method="post">
        <input type="hidden" value="" name="TC_Aberto" id="TC_Aberto">
        <?php if(isset($_POST['C_Aberto']) && !empty($_POST['C_Aberto']) && $_SESSION['id'] > 0): ?>
            <input type="hidden" value="<?= $_POST['C_Aberto']?>" name="C_Aberto6">
        <?php endif ?>
        <?php if(isset($_POST['TC_Aberto']) && !empty($_POST['TC_Aberto']) && $_SESSION['id'] > 0): ?>
            <input type="hidden" id="VerificarTable">
        <?php endif ?>
    </form>
    <div id="Tabelas_Show" style="position:relative;opacity:0;visibility:hidden;">
        <div style="position:absolute;">
            <div id="ShowTabelaCronogramaInfo">
                <div id="EditUsuarioFoodInfo">
                    <?php if(!empty($QTDE_Nutriente_Info)): ?>
                        <div>Calorias: <?= $QTDE_Nutriente_Info['qtde_kcal'] ?> kcal</div>
                        <div>Carboidrato: <?= $QTDE_Nutriente_Info['qtde_carboidrato'] ?> g</div>
                        <div>Proteína: <?= $QTDE_Nutriente_Info['qtde_proteina'] ?> g</div>
                        <div>Gordura Boa: <?= $QTDE_Nutriente_Info['qtde_gordura_boa'] ?> g</div>
                        <div>Fibra: <?= $QTDE_Nutriente_Info['qtde_fibra'] ?> g</div>

                        <!-- Minerais -->
                        <div>Cálcio: <?= $QTDE_Nutriente_Info['qtde_calcio'] ?> mg</div>
                        <div>Fósforo: <?= $QTDE_Nutriente_Info['qtde_fosforo'] ?> mg</div>
                        <div>Magnésio: <?= $QTDE_Nutriente_Info['qtde_magnesio'] ?> mg</div>
                        <div>Ferro: <?= $QTDE_Nutriente_Info['qtde_ferro'] ?> mg</div>
                        <div>Potássio: <?= $QTDE_Nutriente_Info['qtde_potassio'] ?> mg</div>
                        <div>Sódio: <?= $QTDE_Nutriente_Info['qtde_sodio'] ?> mg</div>
                        <div>Zinco: <?= $QTDE_Nutriente_Info['qtde_zinco'] ?> mg</div>
                        <div>Selênio: <?= $QTDE_Nutriente_Info['qtde_selenio'] ?> mcg</div>
                        <div>Cobre: <?= $QTDE_Nutriente_Info['qtde_cobre'] ?> mg</div>

                        <!-- Vitaminas -->
                        <div>Vitamina A: <?= $QTDE_Nutriente_Info['qtde_vA'] ?> mcg</div>
                        <div>Vitamina C: <?= $QTDE_Nutriente_Info['qtde_vC'] ?> mg</div>
                        <div>Vitamina D: <?= $QTDE_Nutriente_Info['qtde_vD'] ?> UI</div>
                        <div>Vitamina E: <?= $QTDE_Nutriente_Info['qtde_vE'] ?> mg</div>
                        <div>Vitamina K: <?= $QTDE_Nutriente_Info['qtde_vK'] ?> mcg</div>
                        <div>Vitamina B1: <?= $QTDE_Nutriente_Info['qtde_vB1'] ?> mcg</div>
                        <div>Vitamina B2: <?= $QTDE_Nutriente_Info['qtde_vB2'] ?> mg</div>
                        <div>Vitamina B3: <?= $QTDE_Nutriente_Info['qtde_vB3'] ?> mg</div>
                        <div>Vitamina B5: <?= $QTDE_Nutriente_Info['qtde_vB5'] ?> mg</div>
                        <div>Vitamina B6: <?= $QTDE_Nutriente_Info['qtde_vB6'] ?> mcg</div>
                        <div>Vitamina B7: <?= $QTDE_Nutriente_Info['qtde_vB7'] ?> mcg</div>
                        <div>Vitamina B9: <?= $QTDE_Nutriente_Info['qtde_vB9'] ?> mcg</div>
                        <div>Vitamina B12: <?= $QTDE_Nutriente_Info['qtde_vB12'] ?> mcg</div>
                    <?php else: ?>
                        <div style="grid-column:1/3;text-align:center;font-size:2em;">Preencha as informações para ver.</div>
                    <?php endif ?>
                </div>
            </div>
            <div id="EditButtonsFromTable">
                <div><img id="EditVoltarImg" src="Voltar.png" alt="" onclick="VoltarParaCronogramas()"></div>
                <div><img id="EditInfoImg" src="info.png" alt="" onclick="AbrirShowTabelaCronogramaInfo()"></div>
            </div>
            <div id="EditTabelas">
                <div id="DefinirHorario">
                    <p style="width: 100%; text-align: center; font-size: 2em;"><strong>Digite o Horario</strong></p>
                    <form id="TableEditHorario" style="margin-top: 20px;" action="cronogramaSecurity.php" method="post">
                        <input style="width: 100%; height: 20px;" type="time" 
                            name="table_Horario" id="TableHorario" 
                            placeholder="Digite o horario" maxlength="20"
                        >
                        <input type="hidden" value="" id="table_ID" name="table_ID">
                        <?php if(isset($_POST['C_Aberto']) && !empty($_POST['C_Aberto']) && $_SESSION['id'] > 0): ?>
                            <input type="hidden" value="<?= $_POST['C_Aberto']?>" name="C_Aberto3">
                        <?php endif ?>
                        <div style="display: flex;justify-content: center;width: 100%;">
                            <div class="CriarCronograma" id="Create" onclick="alterarHorario()">
                                Alterar
                            </div>
                            <div class="CriarCronograma" id="Close" onclick="FecharTableEditHorario()">
                                Fechar
                            </div>
                        </div>
                    </form>
                </div>
                <div id="DefinirTabela_Comida" class="Flex">
                    <div id="ItensGridEdit">
                        <div id="ShowFoodInfoStats">
                            <div>
                                <div></div>
                                <div></div>
                                <div></div>
                            </div>
                            <div id="FecharShowFoodInfoStats" onclick="FecharShowFoodInfoStats()">Fechar</div>
                        </div>
                        <div id="AddItemBox">
                            <span class="TextDesignF_Mobile">Adicionar</span>
                            <div class="Flex" style="margin-top:20px;">
                                <form action="cronogramaSecurity.php" id="ComidaSearch" method="post">
                                    <p style="font-size:1.2em;">Digite o nome da comida:</p>
                                    <input type="text" id="ComidaName" placeholder="Pesquise aqui" name="ComidaName" maxlength="100">
                                    <p style="font-size:1.2em;margin-top:5px;">Selecione a quantidade:</p>
                                    <input type="number" id="QtdeComida" placeholder="Digite aqui" name="qtdeComida">
                                    <?php if(isset($_POST['C_Aberto']) && !empty($_POST['C_Aberto']) && $_SESSION['id'] > 0): ?>
                                        <input type="hidden" value="<?= $_POST['C_Aberto']?>" name="C_Aberto5">
                                    <?php endif ?>
                                    <?php if(isset($_POST['TC_Aberto']) && !empty($_POST['TC_Aberto']) && $_SESSION['id'] > 0): ?>
                                        <input type="hidden" value="<?= $_POST['TC_Aberto']?>" name="TC_Aberto2">
                                    <?php endif ?>
                                </form>
                            </div>
                            <div class="Flex" style="gap:20px;">
                                <div class="AdicionarComidaButtonEdit" onclick="AdicionarComidaTable()">ADICIONAR</div>
                                <div id="InserirComidaButtonEdit" onclick="AlterarTableEditComidas(null)">
                                    <form action="cronogramaSecurity.php" method="post" id="AlterarTableEditComidasBD">
                                        <input type="hidden" name="AlterarTableEditComidasBD">
                                        <?php if(isset($_POST['C_Aberto']) && !empty($_POST['C_Aberto']) && $_SESSION['id'] > 0): ?>
                                            <input type="hidden" value="<?= $_POST['C_Aberto']?>" name="C_Aberto10">
                                        <?php endif ?>
                                        <?php if(isset($_POST['TC_Aberto']) && !empty($_POST['TC_Aberto']) && $_SESSION['id'] > 0): ?>
                                            <input type="hidden" value="<?= $_POST['TC_Aberto']?>" name="TC_Aberto5">
                                        <?php endif ?>
                                    </form>
                                    INSERIR
                                </div>
                            </div>
                            <div class="SB_FoodInfo" style="height: 40vh;">
                                <?php if(isset($_SESSION['FoodListForAdd']) && !empty($_SESSION['FoodListForAdd'])): ?>
                                    <form action="cronogramaSecurity.php" method="post" id="ExcluirComidaList">
                                        <input type="hidden" name="ExcluirComidaList" value="">
                                        <?php if(isset($_POST['C_Aberto']) && !empty($_POST['C_Aberto']) && $_SESSION['id'] > 0): ?>
                                            <input type="hidden" value="<?= $_POST['C_Aberto']?>" name="C_Aberto7">
                                        <?php endif ?>
                                    </form>
                                    <ul>
                                        <form action="cronogramaSecurity.php" method="post" id="RemoverItemComidaList">
                                            <input type="hidden" value="" name="ListIndex" id="ListIndex">
                                            <?php if(isset($_POST['C_Aberto']) && !empty($_POST['C_Aberto']) && $_SESSION['id'] > 0): ?>
                                                <input type="hidden" value="<?= $_POST['C_Aberto']?>" name="C_Aberto8">
                                            <?php endif ?>
                                            <?php if(isset($_POST['TC_Aberto']) && !empty($_POST['TC_Aberto']) && $_SESSION['id'] > 0): ?>
                                                <input type="hidden" value="<?= $_POST['TC_Aberto']?>" name="TC_Aberto3">
                                            <?php endif ?>
                                        </form>
                                        <?php foreach($_SESSION['FoodListForAdd'] as $index => $comida): 
                                            $Food_Info = $comida[1];?>
                                            <li onclick="AlterarTableEditComidas(<?= $index ?>)" style="cursor:pointer;"><?= $comida[0] ?>g - <?= $Food_Info['nomeComidaEncontrada'] ?></li>
                                        <?php endforeach ?>
                                    </ul>
                                    <div class="Flex"><div class="Viz_FoodStatsInfo">VER</div></div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div id="RemoveItemBox">
                            <span class="TextDesignF_Mobile">Excluir</span>
                            <div class="Flex" style="margin-top:20px;">
                                <div class="AdicionarComidaButtonEdit DesignF_Mobile" onclick="Selecionar_ComidaList(this)">SELECIONAR</div>
                            </div>
                            <div class="Flex">
                                <form action="cronogramaSecurity.php" method="post" id="Exclur_ComidaList">
                                    <input type="hidden" name="Excluir_ComidaList" id="Comida_List_SetValues">
                                    <?php if(isset($_POST['C_Aberto']) && !empty($_POST['C_Aberto']) && $_SESSION['id'] > 0): ?>
                                        <input type="hidden" value="<?= $_POST['C_Aberto']?>" name="C_Aberto9">
                                    <?php endif ?>
                                    <?php if(isset($_POST['TC_Aberto']) && !empty($_POST['TC_Aberto']) && $_SESSION['id'] > 0): ?>
                                        <input type="hidden" value="<?= $_POST['TC_Aberto']?>" name="TC_Aberto4">
                                    <?php endif ?>
                                </form>
                                <div id="ExcluirComidaButtonEdit" class="DesignF_Mobile" onclick="Excluir_ComidaList()">EXCLUIR</div>
                            </div>
                            <div class="SB_FoodInfo">
                                <ul id="GetItensForDelete">
                                    <form action="cronogramaSecurity.php" method="post" id="RemoveItemFromFoodList2">
                                        <input type="hidden" value="" name="ListIndex2" id="ListIndex2">
                                        <?php if(isset($_POST['C_Aberto']) && !empty($_POST['C_Aberto']) && $_SESSION['id'] > 0): ?>
                                            <input type="hidden" value="<?= $_POST['C_Aberto']?>" name="C_Aberto11">
                                        <?php endif ?>
                                        <?php if(isset($_POST['TC_Aberto']) && !empty($_POST['TC_Aberto']) && $_SESSION['id'] > 0): ?>
                                            <input type="hidden" value="<?= $_POST['TC_Aberto']?>" name="TC_Aberto6">
                                        <?php endif ?>
                                    </form>
                                </ul>
                            </div>
                        </div>
                        <?php if(isset($_SESSION['FoodListForAdd']) && !empty($_SESSION['FoodListForAdd'])): ?>
                            <div id="FecharTabela_Comida" onclick="FecharTableEditComidas(true)">FECHAR</div>
                        <?php else: ?>
                            <div id="FecharTabela_Comida" onclick="FecharTableEditComidas(false)">FECHAR</div>
                        <?php endif; ?>
                        <div id="Tabela_ComidaListShow">
                            <ul>
                                <?php if(!empty($Tabela_FoodListInfo)): ?>
                                    <form action="cronogramaSecurity.php" method="post" id="Verificar_FoodInfo">
                                        <input type="hidden" value="" name="Verificar_FoodInfo">
                                    </form>
                                    <?php foreach($Tabela_FoodListInfo as $index => $foodInfo): 
                                        $qtde = $foodInfo['Comida_Qtde'];
                                        $name = $foodInfo['food_name']; ?>
                                        <li id="FoodId_<?= $index ?>" style="cursor:pointer;font-size:2em;" onclick="SelecionarComida_FoodInfo(<?= $qtde ?>, '<?= $name ?>', <?= $index ?>)"><?= $qtde ?> - <?= $name ?></li>
                                    <?php endforeach ?>
                                <?php endif ?>
                            </ul>
                        </div>
                    </div>
                </div>
                <div id="CriarTabela_Cronograma">
                    <p style="width: 100%; text-align: center; font-size: 2em;"><strong>Digite o Horario</strong></p>
                    <form id="CreateTabelaCronograma" style="margin-top: 20px;" action="cronogramaSecurity.php" method="post">
                        <input style="width: 100%; height: 20px;" type="time" 
                            name="table_NewHorario" id="table_NewHorario" 
                            placeholder="Digite o horario" maxlength="20"
                        >
                        <?php if(isset($_POST['C_Aberto']) && !empty($_POST['C_Aberto']) && $_SESSION['id'] > 0): ?>
                            <input type="hidden" value="<?= $_POST['C_Aberto']?>" name="C_Aberto2">
                        <?php endif ?>
                        <div style="display: flex;justify-content: center;width: 100%;">
                            <div class="CriarCronograma" id="Create" onclick="CriarCTC()">
                                Criar
                            </div>
                            <div class="CriarCronograma" id="Close" onclick="FecharCTC_Box()">
                                Fechar
                            </div>
                        </div>
                    </form>
                </div>
                <div id="DropBox2">
                    <div class="DropBoxButton" id="Drop2" onclick="ExcluirCTC()">Excluir</div>
                    <div class="DropBoxButton" id="Back2" onclick="CancelarECTC()">Cancelar</div>
                </div>
                <div>
                    <?php if(isset($_SESSION['id']) && $_SESSION['id'] > 0 && !empty($CronogramaInfo)):?>
                        <div class="Flex" style="font-size:3em;margin-bottom:30px;"><strong><?= $CronogramaInfo['C_tableName']?></strong></div>
                    <?php else: ?>
                        <div class="Flex" style="font-size:3em;margin-bottom:30px;" id="Verificar"><strong>Selecione um Cronograma</strong></div>
                    <?php endif ?>
                    <?php foreach($Cronograma_Tabelas as $Tabela):
                        $TB_ID = $Tabela['TB_ID']; ?>
                        <div class="EditTabela" id="<?= $TB_ID ?>" onclick="TableSelected(<?= $TB_ID ?>)">
                            <div style="height:10vh;" class="HorarioDesign" onclick="AbrirTableEditHorario(<?= $TB_ID ?>)">
                                <strong><?= substr($Tabela['TB_Horario'], 0, 5) ?></strong>
                            </div>
                            <div style="height:10vh;" class="InfoDesign" onclick="AbrirTableEditComidas(<?= $TB_ID ?>)"></div>
                        </div>
                    <?php endforeach ?>
                    <div class="Flex" style="justify-content:center;gap:10px;">
                        <div class="AddTable" onclick="AbrirCTC_Box()"><img id="MaisIcon2" src="MaisIcon.png" alt=""></div>
                        <div class="AddTable" onclick="AbrirECTC()"><img id="MenosIcon" src="MenosIcon.png" alt=""></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <main id="Main">
        <?php if(isset($_SESSION['id']) && $_SESSION['id'] > 0): ?>
            <div class="BoxCreate" id="Original" onclick="OpenCC(this)"><img id="MaisIcon" src="MaisIcon.png" alt=""></div>
            <?php foreach($Cronograma_Table_Show as $Cronograma): 
                $Tabela_id = $Cronograma['C_id'];
                $Tabela_name = $Cronograma['C_tableName']; ?>
                <div class="BoxCreate" id="<?= $Tabela_id; ?>" onclick="Select(<?= $Tabela_id; ?>)"><strong><?= $Tabela_name; ?></strong></div>
            <?php endforeach ?>
        <?php else: ?>
            <div style="text-align:center;font-size:3em;grid-column:1/4;" class="Flex">
                <div>Faça login antes de criar um cronogrma</div>
            </div>
        <?php endif ?>
    </main>
    <script src="cronogramaScript.js"></script>
</body>
</html>