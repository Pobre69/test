function BlackScreenShow(){
    var BlackSceen = document.getElementById("BlackScreen")
    BlackSceen.style.opacity = 0.4;
    BlackSceen.style.visibility = 'visible';
}
function BlackScreenHide(){
    var BlackSceen = document.getElementById("BlackScreen")
    BlackSceen.style.opacity = 0;
    BlackSceen.style.visibility = 'hidden';
}
var ScreenSize = false;
var MenuOpen = false;
var CaixaLoginOpen = false;
var CaixaCadastroOpen = false;
var Menu = document.getElementById("Menu");
var Heade = document.getElementById("header");
var Main = document.getElementById("Main");
var CaixaLogin = document.getElementById("CaixaLogin");
var CaixaCadastrar = document.getElementById("CaixaCadastrar");
var ButtonCadastrar = document.getElementById("Cadastrar");
var ScreenScrollCheck = 0;
const TamanhoMin = 950;

function Deslogar(){
    const CadastroForm3 = document.getElementById("EditForm3");
    CaixaCadastrarClosing();
    localStorage.setItem("CDOpen",false);
    CadastroForm3.submit();
}
function LogarUsuario(){
    const CadastroForm2 = document.getElementById("EditForm2");
    const email = document.getElementById("L_Email");
    const senha = document.getElementById("L_Senha");

    if (senha.value.trim() === "" || email.value.trim() === ""){
        alert("Preencha todas as informações!");
    } else{
        CadastroForm2.submit();
    }
}
function CadastrarUsuario(){
    const CadastroForm = document.getElementById("EditForm1");
    const nome = document.getElementById("U_Nome");
    const idade = document.getElementById("U_Idade");
    const senha = document.getElementById("U_Senha");
    const email = document.getElementById("U_Email");

    if (
        nome.value.trim() === "" ||
        idade.value.trim() === "" ||
        senha.value.trim() === "" ||
        email.value.trim() === ""
    ) {
        alert("Preencha todas as informações!");
    } else{
        CaixaCadastrarClosing();
        localStorage.setItem("CDOpen",false);
        CadastroForm.submit();
    }
}
function MenuOpening(){
    if(ScreenSize == true){
        Menu.style.left = '50%';
        MenuOpen = true;
    }
    else{
        Menu.style.left = '250px';
        MenuOpen = true;
    }
}
function MenuClosing(){
    if(ScreenSize == true){
        Menu.style.left = '-600px'
        MenuOpen = false;
    }
    else{
        Menu.style.left = '-50%';
        MenuOpen = false;
    }
}
function HeaderShow(){
    if(MenuOpen==true || CaixaLoginOpen==true || CaixaCadastroOpen==true){
        return;
    }
    Heade.style.top = '0%';
}
function HeaderHide(){
    Heade.style.top = '-100px';
}
function MenuIconOpening(){
    MenuOpening();
    HeaderHide();
    BlackScreenShow();
    localStorage.setItem("MenuAberto", true)
}
function MenuIconClosing(){
    MenuClosing();
    BlackScreenHide();
    HeaderShow();
    localStorage.setItem("MenuAberto", false)
}

function CaixaLoginAnimationOpen(){
    CaixaLogin.style.top = '50%'
}
function CaixaLoginAnimationClose(){
    CaixaLogin.style.top = '-70%';
}
function CaixaCadastrarAnimationOpen(){
    CaixaCadastrar.style.top = '50%'
}
function CaixaCadastrarAnimationClose(){
    CaixaCadastrar.style.top = '-70%';
}

function CaixaLoginOpening(){
    BlackScreenShow()
    HeaderHide()
    CaixaLoginAnimationOpen()
    localStorage.setItem("CLOpen", true)
}
function CaixaLoginClosing(){
    BlackScreenHide()
    HeaderShow()
    CaixaLoginAnimationClose()
    localStorage.setItem("CLOpen", false)
}
function CaixaCadastrarOpening(){
    BlackScreenShow()
    HeaderHide()
    CaixaCadastrarAnimationOpen()
    localStorage.setItem("CDOpen", true)
}
function CaixaCadastrarClosing(){
    BlackScreenHide()
    HeaderShow()
    CaixaCadastrarAnimationClose()
    localStorage.setItem("CDOpen", false)
}
function OpenMain(){
    Main.style.opacity = '1';
    Main.style.visibility = 'visible';
}
function CloseMain(){
    Main.style.opacity = '0';
    Main.style.visibility = 'hidden';
}

var SetStartInfoBox = document.getElementById("SetStartInfoBox");
var PesoInfo = document.getElementById("PesoInfo");
var TableSetSelected = document.getElementById("TableSetSelected");
var TableInfoSelected = document.getElementById("TableInfoSelected");
var SetStartInfoForm = document.getElementById("SetStartInfoForm");
var DesignFoodTableInfo = document.getElementById("DesignFoodTableInfo");
const customSelect = document.getElementById('checkboxSelect');
const header = customSelect.querySelector('.SelectHeader');

function OpenStartInfoBox(){
    BlackScreenShow()
    HeaderHide()
    CloseMain()
    SetStartInfoBox.style.top = '50%';
    localStorage.setItem("SSIBOpen", true);
}
function CloseStartInfoBox(){
    BlackScreenHide()
    HeaderShow()
    OpenMain()
    SetStartInfoBox.style.top = '-100%';
    localStorage.setItem("SSIBOpen", false);
}
function SubmitStartInfoBox(){
    localStorage.setItem("SSIBOpen", false);
    SetStartInfoForm.submit();
}
function SetTableInfoSelected(value){
    TableInfoSelected.value = value;
    TableSetSelected.submit();
}
function OpenDesignFoodTableInfo(){
    BlackScreenShow()
    HeaderHide()
    CloseMain()
    DesignFoodTableInfo.style.top = '50%';
    localStorage.setItem("TableInfoEditableOpen", true);
}
function CloseDesignFoodTableInfo(){
    BlackScreenHide()
    HeaderShow()
    OpenMain()
    DesignFoodTableInfo.style.top = '-100%';
    localStorage.setItem("TableInfoEditableOpen", false);
}

PesoInfo.addEventListener('input', () => {
    let valor = PesoInfo.value.replace(/kg/g, '').replace(/[^0-9.]/g, '');
    const partes = valor.split('.');

    if (partes.length > 2) {
        valor = partes[0] + '.' + partes.slice(1).join('');
    }

    if (valor) {
        PesoInfo.value = valor + 'kg';
        PesoInfo.setSelectionRange(valor.length, valor.length);
    } else {
        PesoInfo.value = '';
    }
});

PesoInfo.addEventListener('click', () => {
    const pos = PesoInfo.selectionStart;
    const limite = PesoInfo.value.length - 2;

    if (pos > limite) {
        PesoInfo.setSelectionRange(limite, limite);
    }
});

PesoInfo.addEventListener('keyup', () => {
    const pos = PesoInfo.selectionStart;
    const limite = PesoInfo.value.length - 2;

    if (pos > limite) {
        PesoInfo.setSelectionRange(limite, limite);
    }
});

header.addEventListener('click', () => {
    customSelect.classList.toggle('open');
});

window.addEventListener('click', function(e) {
    if (!customSelect.contains(e.target)) {
        customSelect.classList.remove('open');
    }
});
window.addEventListener('scroll', function() {
    if(MenuOpen==true){
        return
    }
    const scrollY = window.scrollY;
    if(ScreenScrollCheck>scrollY){
        ScreenScrollCheck = scrollY;
        Heade.style.top = '0%';
    }
    if(ScreenScrollCheck<=scrollY-100){
        ScreenScrollCheck = scrollY
        Heade.style.top = '-100px';
    }
    localStorage.setItem("ScrollSet", scrollY)
});
window.addEventListener("resize", function(){
    var MenuSize = document.getElementById("Menu");
    if(window.innerWidth < TamanhoMin){
        MenuSize.style.width = '105vw';
        CaixaLogin.style.width = '100vw';
        CaixaLogin.style.height = '110vh';
        CaixaCadastrar.style.width = '100vw';
        CaixaCadastrar.style.height = '110vh';
        if(MenuOpen == true){
            MenuSize.style.left = '50%'
            ScreenSize = true
        }
        else{
            Menu.style.left = '-600px'
            ScreenSize = true
        }
    }
    else{
        MenuSize.style.width = '600px';
        CaixaLogin.style.width = '700px';
        CaixaLogin.style.height = '500px';
        CaixaCadastrar.style.width = '700px';
        CaixaCadastrar.style.height = '500px';
        if(MenuOpen == true){
            MenuSize.style.left = '250px'
            ScreenSize = false
        }
        else{
            Menu.style.left = '-50%';
            ScreenSize = false
        }
    }
});
window.addEventListener('load', function() {
    var Status = localStorage.getItem("MenuAberto")
    var ScrollCheck = localStorage.getItem("ScrollSet")
    var CLCheck = localStorage.getItem("CLOpen")
    var CDCheck = localStorage.getItem("CDOpen")
    var Verificar = localStorage.getItem("SSIBOpen")
    var FoodTableEditableVerify = this.localStorage.getItem("TableInfoEditableOpen")
    if(FoodTableEditableVerify == 'true'){
        OpenDesignFoodTableInfo()
    }
    if(Verificar == 'true'){
        OpenStartInfoBox()
    }
    if(Status == 'true'){
        MenuIconOpening()
    }
    if(CLCheck == 'true'){
        CaixaLoginOpening()
    }
    if(CDCheck == 'true'){
        CaixaCadastrarOpening()
    }
    if(window.innerWidth < TamanhoMin){
        var MenuSize = document.getElementById("Menu");
        MenuSize.style.width = '110vw';
        if(MenuOpen == true){
            MenuSize.style.left = '50%'
            ScreenSize = true
        }
        else{
            Menu.style.left = '-600px'
            ScreenSize = true
        }
    }
    window.screenY = ScrollCheck
});
function Reset(){
    localStorage.setItem("MenuAberto", false)
    localStorage.setItem("ScrollCheck", null)
    localStorage.setItem("CLOpen", false)
    localStorage.setItem("CDOpen", false)
    localStorage.setItem("SSIBOpen", false)
    localStorage.setItem("TableInfoEditableOpen", false)
}