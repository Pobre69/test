function BlackScreenShow(){
    var BlackSceen = document.getElementById("BlackScreen")
    BlackSceen.style.opacity = 0.4;
    BlackSceen.style.visibility = 'visible';
}
function BlackScreenHide(){
    var BlackSceen = document.getElementById("BlackScreen")
    BlackSceen.style.opacity = 0;
    BlackSceen.style.visibility = 'hidden';
}
var ScreenSize = false;
var MenuOpen = false;
var Menu = document.getElementById("Menu");
var Heade = document.getElementById("header");
var ScreenScrollCheck = 0
const TamanhoMin = 950;

function MenuOpening(){
    if(ScreenSize == true){
        Menu.style.left = '50%';
        MenuOpen = true;
    }
    else{
        Menu.style.left = '250px';
        MenuOpen = true;
    }
}
function MenuClosing(){
    if(ScreenSize == true){
        Menu.style.left = '-600px'
        MenuOpen = false;
    }
    else{
        Menu.style.left = '-50%';
        MenuOpen = false;
    }
}
function HeaderShow(){
    if(MenuOpen==true){
        return;
    }
    Heade.style.top = '0%';
}
function HeaderHide(){
    Heade.style.top = '-100px';
}
function MenuIconOpening(){
    MenuOpening();
    HeaderHide();
    BlackScreenShow();
    localStorage.setItem("MenuAberto", true)
}
function MenuIconClosing(){
    MenuClosing();
    BlackScreenHide();
    HeaderShow();
    localStorage.setItem("MenuAberto", false)
}

function Carboidrato() {
    var element = document.getElementById("CLink");
    element.scrollIntoView({behavior: "smooth", block: "center"});
}
function Gordura() {
    var element = document.getElementById("GLink");
    element.scrollIntoView({behavior: "smooth", block: "center"});
}
function Fibra() {
    var element = document.getElementById("FLink");
    element.scrollIntoView({behavior: "smooth", block: "center"});
}
function Proteina() {
    var element = document.getElementById("PLink");
    element.scrollIntoView({behavior: "smooth", block: "center"});
}
function Minerais() {
    var element = document.getElementById("MLink");
    element.scrollIntoView({behavior: "smooth", block: "center"});
}
function Vitamina() {
    var element = document.getElementById("VLink");
    element.scrollIntoView({behavior: "smooth", block: "center"});
}
window.addEventListener('scroll', function() {
    if(MenuOpen==true){
        return
    }
    const scrollY = window.scrollY;
    if(ScreenScrollCheck>scrollY){
        ScreenScrollCheck = scrollY;
        Heade.style.top = '0%';
    }
    if(ScreenScrollCheck<=scrollY-100){
        ScreenScrollCheck = scrollY
        Heade.style.top = '-100px';
    }
    localStorage.setItem("ScrollSet", scrollY)
});
window.addEventListener("resize", function(){
    var MenuLinks = document.getElementById("MenuLinkDivision");
    var MenuSize = document.getElementById("Menu");
    if(window.innerWidth < TamanhoMin){
        MenuLinks.style.opacity = 0;
        MenuLinks.style.visibility = 'hidden';
        MenuSize.style.width = '110vw';
        if(MenuOpen == true){
            MenuSize.style.left = '50%'
            ScreenSize = true
        }
        else{
            Menu.style.left = '-600px'
            ScreenSize = true
        }
    }
    else{
        MenuLinks.style.opacity = 1;
        MenuLinks.style.visibility = 'visible';
        MenuSize.style.width = '600px';
        if(MenuOpen == true){
            MenuSize.style.left = '250px'
            ScreenSize = false
        }
        else{
            Menu.style.left = '-50%';
            ScreenSize = false
        }
    }
});
window.addEventListener('load', function() {
    var Status = localStorage.getItem("MenuAberto")
    var ScrollCheck = localStorage.getItem("ScrollSet")
    if(Status == 'true'){
        MenuIconOpening()
    }
    if(window.innerWidth < TamanhoMin){
        var MenuLinks = document.getElementById("MenuLinkDivision");
        var MenuSize = document.getElementById("Menu");
        MenuLinks.style.opacity = 0;
        MenuLinks.style.visibility = 'hidden';
        MenuSize.style.width = '110vw';
        if(MenuOpen == true){
            MenuSize.style.left = '50%'
            ScreenSize = true
        }
        else{
            Menu.style.left = '-600px'
            ScreenSize = true
        }
    }
    window.screenY = ScrollCheck
});
function Reset(){
    localStorage.setItem("MenuAberto", false)
    localStorage.setItem("ScrollCheck", null)
}