<?php

class UsuarioController extends Usuario
{
    public function Index()
    {
        
    }
    public function create()
    {
        
    }
    public function store()
    {
        
    }
    public function show()
    {
        
    }
    public function edit()
    {
        
    }
    public function update()
    {

    }
    public function destroy()
    {
        
    }
}