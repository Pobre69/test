<?php

namespace Repository;

use DataBase\DB_Global_Conection\DB_Conection;
use PDO;
use Repository\RepositoryInterface;

class QtdeNutrientesRepository implements RepositoryInterface
{
    private PDO $conn;

    public function __construct()
    {
        $this->conn = DB_Conection::getConnection();
    }

    public function create(array $data): bool
    {
        $sql = 'INSERT INTO qtde_Nutrientes (ID, qtde_kcal, qtde_carboidrato, qtde_proteina, qtde_gordura_boa, qtde_fibra, qtde_calcio, qtde_fosforo, qtde_magnesio, qtde_ferro, qtde_potassio, qtde_sodio, qtde_zinco, qtde_selenio, qtde_cobre, qtde_vA, qtde_vC, qtde_vD, qtde_vE, qtde_vK, qtde_vB1, qtde_vB2, qtde_vB3, qtde_vB5, qtde_vB6, qtde_vB7, qtde_vB9, qtde_vB12) VALUES (:ID, :qtde_kcal, :qtde_carboidrato, :qtde_proteina, :qtde_gordura_boa, :qtde_fibra, :qtde_calcio, :qtde_fosforo, :qtde_magnesio, :qtde_ferro, :qtde_potassio, :qtde_sodio, :qtde_zinco, :qtde_selenio, :qtde_cobre, :qtde_vA, :qtde_vC, :qtde_vD, :qtde_vE, :qtde_vK, :qtde_vB1, :qtde_vB2, :qtde_vB3, :qtde_vB5, :qtde_vB6, :qtde_vB7, :qtde_vB9, :qtde_vB12)';

        $stmt = $this->conn->prepare($sql);
        return $stmt->execute([
            ':ID' => $data['ID'] ?? 0,
            ':qtde_kcal' => $data['qtde_kcal'] ?? 0,
            ':qtde_carboidrato' => $data['qtde_carboidrato'] ?? 0.0,
            ':qtde_proteina' => $data['qtde_proteina'] ?? 0.0,
            ':qtde_gordura_boa' => $data['qtde_gordura_boa'] ?? 0.0,
            ':qtde_fibra' => $data['qtde_fibra'] ?? 0.0,
            ':qtde_calcio' => $data['qtde_calcio'] ?? 0.0,
            ':qtde_fosforo' => $data['qtde_fosforo'] ?? 0.0,
            ':qtde_magnesio' => $data['qtde_magnesio'] ?? 0.0,
            ':qtde_ferro' => $data['qtde_ferro'] ?? 0.0,
            ':qtde_potassio' => $data['qtde_potassio'] ?? 0.0,
            ':qtde_sodio' => $data['qtde_sodio'] ?? 0.0,
            ':qtde_zinco' => $data['qtde_zinco'] ?? 0.0,
            ':qtde_selenio' => $data['qtde_selenio'] ?? 0.0,
            ':qtde_cobre' => $data['qtde_cobre'] ?? 0.0,
            ':qtde_vA' => $data['qtde_vA'] ?? 0.0,
            ':qtde_vC' => $data['qtde_vC'] ?? 0.0,
            ':qtde_vD' => $data['qtde_vD'] ?? 0.0,
            ':qtde_vE' => $data['qtde_vE'] ?? 0.0,
            ':qtde_vK' => $data['qtde_vK'] ?? 0.0,
            ':qtde_vB1' => $data['qtde_vB1'] ?? 0.0,
            ':qtde_vB2' => $data['qtde_vB2'] ?? 0.0,
            ':qtde_vB3' => $data['qtde_vB3'] ?? 0.0,
            ':qtde_vB5' => $data['qtde_vB5'] ?? 0.0,
            ':qtde_vB6' => $data['qtde_vB6'] ?? 0.0,
            ':qtde_vB7' => $data['qtde_vB7'] ?? 0.0,
            ':qtde_vB9' => $data['qtde_vB9'] ?? 0.0,
            ':qtde_vB12' => $data['qtde_vB12'] ?? 0.0,
        ]);
    }

    public function findById(int $id): ?array
    {
        $stmt = $this->conn->prepare('SELECT * FROM qtde_Nutrientes WHERE ID = :id');
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row === false ? null : $row;
    }

    public function findAll(): array
    {
        $stmt = $this->conn->query('SELECT * FROM qtde_Nutrientes');
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function update(int $id, array $data): bool
    {
        $fields = [
            'qtde_kcal','qtde_carboidrato','qtde_proteina','qtde_gordura_boa','qtde_fibra','qtde_calcio','qtde_fosforo','qtde_magnesio','qtde_ferro','qtde_potassio','qtde_sodio','qtde_zinco','qtde_selenio','qtde_cobre','qtde_vA','qtde_vC','qtde_vD','qtde_vE','qtde_vK','qtde_vB1','qtde_vB2','qtde_vB3','qtde_vB5','qtde_vB6','qtde_vB7','qtde_vB9','qtde_vB12'
        ];

        $sets = [];
        $params = [':id' => $id];
        foreach ($fields as $f) {
            if (array_key_exists($f, $data)) {
                $sets[] = "$f = :$f";
                $params[":$f"] = $data[$f];
            }
        }

        if (empty($sets)) {
            return false;
        }

        $sql = 'UPDATE qtde_Nutrientes SET ' . implode(', ', $sets) . ' WHERE ID = :id';
        $stmt = $this->conn->prepare($sql);
        return $stmt->execute($params);
    }

    public function delete(int $id): bool
    {
        $stmt = $this->conn->prepare('DELETE FROM qtde_Nutrientes WHERE ID = :id');
        return $stmt->execute([':id' => $id]);
    }
}
