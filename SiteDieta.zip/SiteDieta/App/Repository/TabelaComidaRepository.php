<?php

namespace Repository;

use DataBase\DB_Global_Conection\DB_Conection;
use PDO;
use Repository\RepositoryInterface;

class TabelaComidaRepository implements RepositoryInterface
{
    private PDO $conn;

    public function __construct()
    {
        $this->conn = DB_Conection::getConnection();
    }

    public function create(array $data): bool
    {
        $sql = 'INSERT INTO Tabela_Comida (ID_Tabela, ID_Comida, Gramas) VALUES (:id_tabela, :id_comida, :gramas)';
        $stmt = $this->conn->prepare($sql);
        return $stmt->execute([
            ':id_tabela' => $data['ID_Tabela'] ?? 0,
            ':id_comida' => $data['ID_Comida'] ?? 0,
            ':gramas' => $data['Gramas'] ?? 0.0
        ]);
    }

    /**
     * Find by composite id or by tabela id.
     * Accepts int (ID_Tabela) or array ['ID_Tabela'=>..,'ID_Comida'=>..]
     */
    public function findById($id): ?array
    {
        if (is_array($id) && isset($id['ID_Tabela'], $id['ID_Comida'])) {
            $stmt = $this->conn->prepare('SELECT * FROM Tabela_Comida WHERE ID_Tabela = :id_tabela AND ID_Comida = :id_comida');
            $stmt->execute([':id_tabela' => $id['ID_Tabela'], ':id_comida' => $id['ID_Comida']]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            return $row === false ? null : $row;
        }

        // if single int, return first record for that tabela
        $stmt = $this->conn->prepare('SELECT * FROM Tabela_Comida WHERE ID_Tabela = :id_tabela LIMIT 1');
        $stmt->execute([':id_tabela' => (int)$id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row === false ? null : $row;
    }

    public function findAll(): array
    {
        $stmt = $this->conn->query('SELECT * FROM Tabela_Comida');
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function findByTabela(int $idTabela): array
    {
        $stmt = $this->conn->prepare('SELECT * FROM Tabela_Comida WHERE ID_Tabela = :idTabela');
        $stmt->execute([':idTabela' => $idTabela]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function update($id, array $data): bool
    {
        // $id can be array with ID_Tabela and ID_Comida
        if (!is_array($id) || !isset($id['ID_Tabela'], $id['ID_Comida'])) {
            return false;
        }
        $sql = 'UPDATE Tabela_Comida SET Gramas = :gramas WHERE ID_Tabela = :id_tabela AND ID_Comida = :id_comida';
        $stmt = $this->conn->prepare($sql);
        return $stmt->execute([
            ':gramas' => $data['Gramas'] ?? 0.0,
            ':id_tabela' => $id['ID_Tabela'],
            ':id_comida' => $id['ID_Comida']
        ]);
    }

    public function delete($id): bool
    {
        if (is_array($id) && isset($id['ID_Tabela'], $id['ID_Comida'])) {
            $stmt = $this->conn->prepare('DELETE FROM Tabela_Comida WHERE ID_Tabela = :id_tabela AND ID_Comida = :id_comida');
            return $stmt->execute([':id_tabela' => $id['ID_Tabela'], ':id_comida' => $id['ID_Comida']]);
        }
        return false;
    }
}
