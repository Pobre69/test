<?php

namespace Repository;

use DataBase\DB_Global_Conection\DB_Conection;
use PDO;
use Repository\RepositoryInterface;

class UsuarioEditableTablesRepository implements RepositoryInterface
{
    private PDO $conn;

    public function __construct()
    {
        $this->conn = DB_Conection::getConnection();
    }

    public function create(array $data): bool
    {
        $sql = 'INSERT INTO UsuarioEditableTables (ID_Usuario, ID_QTDE_NUTRIENTES, Selected) VALUES (:id_usuario, :id_qtde, :selected)';
        $stmt = $this->conn->prepare($sql);
        return $stmt->execute([
            ':id_usuario' => $data['ID_Usuario'] ?? 0,
            ':id_qtde' => $data['ID_QTDE_NUTRIENTES'] ?? 0,
            ':selected' => isset($data['Selected']) ? (int)$data['Selected'] : 0
        ]);
    }

    public function findById(int $idUsuario): ?array
    {
        $stmt = $this->conn->prepare('SELECT * FROM UsuarioEditableTables WHERE ID_Usuario = :id');
        $stmt->execute([':id' => $idUsuario]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row === false ? null : $row;
    }

    public function findAll(): array
    {
        $stmt = $this->conn->query('SELECT * FROM UsuarioEditableTables');
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function update(int $idUsuario, array $data): bool
    {
        $sql = 'UPDATE UsuarioEditableTables SET ID_QTDE_NUTRIENTES = :id_qtde, Selected = :selected WHERE ID_Usuario = :id';
        $stmt = $this->conn->prepare($sql);
        return $stmt->execute([
            ':id_qtde' => $data['ID_QTDE_NUTRIENTES'] ?? 0,
            ':selected' => isset($data['Selected']) ? (int)$data['Selected'] : 0,
            ':id' => $idUsuario
        ]);
    }

    public function delete(int $idUsuario): bool
    {
        $stmt = $this->conn->prepare('DELETE FROM UsuarioEditableTables WHERE ID_Usuario = :id');
        return $stmt->execute([':id' => $idUsuario]);
    }
}
