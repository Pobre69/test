<?php

namespace Repository;

interface RepositoryInterface
{
    public function create(array $data);

    public function findById($id): ?array;

    public function findAll(): array;

    public function update($id, array $data): bool;
    
    public function delete($id): bool;
}
