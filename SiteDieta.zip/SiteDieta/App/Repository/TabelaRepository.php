<?php

namespace Repository;

use DataBase\DB_Global_Conection\DB_Conection;
use PDO;
use Repository\RepositoryInterface;

class TabelaRepository implements RepositoryInterface
{
    private PDO $conn;

    public function __construct()
    {
        $this->conn = DB_Conection::getConnection();
    }

    public function create(array $data): int
    {
        $sql = 'INSERT INTO Tabela (ID_Cronograma, Day_Time) VALUES (:id_cronograma, :day_time)';
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([
            ':id_cronograma' => $data['ID_Cronograma'] ?? 0,
            ':day_time' => $data['Day_Time'] ?? '00:00:00'
        ]);
        return (int)$this->conn->lastInsertId();
    }

    public function findById(int $id): ?array
    {
        $stmt = $this->conn->prepare('SELECT * FROM Tabela WHERE ID = :id');
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row === false ? null : $row;
    }

    public function findAll(): array
    {
        $stmt = $this->conn->query('SELECT * FROM Tabela');
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function findByCronograma(int $idCronograma): array
    {
        $stmt = $this->conn->prepare('SELECT * FROM Tabela WHERE ID_Cronograma = :idCronograma');
        $stmt->execute([':idCronograma' => $idCronograma]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function update(int $id, array $data): bool
    {
        $sql = 'UPDATE Tabela SET ID_Cronograma = :id_cronograma, Day_Time = :day_time WHERE ID = :id';
        $stmt = $this->conn->prepare($sql);
        return $stmt->execute([
            ':id_cronograma' => $data['ID_Cronograma'] ?? 0,
            ':day_time' => $data['Day_Time'] ?? '00:00:00',
            ':id' => $id
        ]);
    }

    public function delete(int $id): bool
    {
        $stmt = $this->conn->prepare('DELETE FROM Tabela WHERE ID = :id');
        return $stmt->execute([':id' => $id]);
    }
}
