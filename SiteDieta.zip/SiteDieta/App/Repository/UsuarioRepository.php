<?php

namespace Repository;

use DataBase\DB_Global_Conection\DB_Conection;
use PDO;
use Repository\RepositoryInterface;

class UsuarioRepository implements RepositoryInterface
{
    private PDO $conn;

    public function __construct()
    {
        $this->conn = DB_Conection::getConnection();
    }

    public function create(array $data): int
    {
        $sql = 'INSERT INTO Usuario (Name, Age, Email, Senha) VALUES (:name, :age, :email, :senha)';
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([
            ':name' => $data['Name'] ?? '',
            ':age' => $data['Age'] ?? 0,
            ':email' => $data['Email'] ?? '',
            ':senha' => $data['Senha'] ?? ''
        ]);

        return (int)$this->conn->lastInsertId();
    }

    public function findById(int $id): ?array
    {
        $stmt = $this->conn->prepare('SELECT * FROM Usuario WHERE ID = :id');
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row === false ? null : $row;
    }

    public function findAll(): array
    {
        $stmt = $this->conn->query('SELECT * FROM Usuario');
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function update(int $id, array $data): bool
    {
        $sql = 'UPDATE Usuario SET Name = :name, Age = :age, Email = :email, Senha = :senha WHERE ID = :id';
        $stmt = $this->conn->prepare($sql);
        return $stmt->execute([
            ':name' => $data['Name'] ?? '',
            ':age' => $data['Age'] ?? 0,
            ':email' => $data['Email'] ?? '',
            ':senha' => $data['Senha'] ?? '',
            ':id' => $id
        ]);
    }

    public function delete(int $id): bool
    {
        $stmt = $this->conn->prepare('DELETE FROM Usuario WHERE ID = :id');
        return $stmt->execute([':id' => $id]);
    }
}
