<?php

namespace Repository;

use DataBase\DB_Global_Conection\DB_Conection;
use PDO;
use Repository\RepositoryInterface;

class ComidaRepository implements RepositoryInterface
{
    private PDO $conn;

    public function __construct()
    {
        $this->conn = DB_Conection::getConnection();
    }

    public function create(array $data): bool
    {
        // ID is expected to come from qtde_Nutrientes (not auto-increment)
        $sql = 'INSERT INTO Comida (ID, Name) VALUES (:id, :name)';
        $stmt = $this->conn->prepare($sql);
        return $stmt->execute([
            ':id' => $data['ID'] ?? 0,
            ':name' => $data['Name'] ?? ''
        ]);
    }

    public function findById(int $id): ?array
    {
        $stmt = $this->conn->prepare('SELECT * FROM Comida WHERE ID = :id');
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row === false ? null : $row;
    }

    public function findAll(): array
    {
        $stmt = $this->conn->query('SELECT * FROM Comida');
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function update(int $id, array $data): bool
    {
        $sql = 'UPDATE Comida SET Name = :name WHERE ID = :id';
        $stmt = $this->conn->prepare($sql);
        return $stmt->execute([
            ':name' => $data['Name'] ?? '',
            ':id' => $id
        ]);
    }

    public function delete(int $id): bool
    {
        $stmt = $this->conn->prepare('DELETE FROM Comida WHERE ID = :id');
        return $stmt->execute([':id' => $id]);
    }
}
