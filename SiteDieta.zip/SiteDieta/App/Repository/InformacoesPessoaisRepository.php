<?php

namespace Repository;

use DataBase\DB_Global_Conection\DB_Conection;
use PDO;
use Repository\RepositoryInterface;

class InformacoesPessoaisRepository implements RepositoryInterface
{
    private PDO $conn;

    public function __construct()
    {
        $this->conn = DB_Conection::getConnection();
    }

    public function create(array $data): bool
    {
        $sql = 'INSERT INTO InformacoesPessoais (ID_Usuario, Idade, Sexo, Peso_Kg, Data_cadastro) VALUES (:id_usuario, :idade, :sexo, :peso, :data_cadastro)';
        $stmt = $this->conn->prepare($sql);
        return $stmt->execute([
            ':id_usuario' => $data['ID_Usuario'] ?? 0,
            ':idade' => $data['Idade'] ?? 0,
            ':sexo' => $data['Sexo'] ?? '',
            ':peso' => $data['Peso_Kg'] ?? 0.0,
            ':data_cadastro' => $data['Data_cadastro'] ?? null
        ]);
    }

    public function findById(int $idUsuario): ?array
    {
        $stmt = $this->conn->prepare('SELECT * FROM InformacoesPessoais WHERE ID_Usuario = :id');
        $stmt->execute([':id' => $idUsuario]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row === false ? null : $row;
    }

    public function findAll(): array
    {
        $stmt = $this->conn->query('SELECT * FROM InformacoesPessoais');
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function update(int $idUsuario, array $data): bool
    {
        $sql = 'UPDATE InformacoesPessoais SET Idade = :idade, Sexo = :sexo, Peso_Kg = :peso, Data_cadastro = :data_cadastro WHERE ID_Usuario = :id';
        $stmt = $this->conn->prepare($sql);
        return $stmt->execute([
            ':idade' => $data['Idade'] ?? 0,
            ':sexo' => $data['Sexo'] ?? '',
            ':peso' => $data['Peso_Kg'] ?? 0.0,
            ':data_cadastro' => $data['Data_cadastro'] ?? null,
            ':id' => $idUsuario
        ]);
    }

    public function delete(int $idUsuario): bool
    {
        $stmt = $this->conn->prepare('DELETE FROM InformacoesPessoais WHERE ID_Usuario = :id');
        return $stmt->execute([':id' => $idUsuario]);
    }
}
