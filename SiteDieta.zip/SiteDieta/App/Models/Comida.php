<?php

namespace Models;

class Comida
{
    public int $ID;
    public string $Name;

    public function __construct(array $data = [])
    {
        $this->ID = isset($data['ID']) ? (int)$data['ID'] : 0;
        $this->Name = isset($data['Name']) ? (string)$data['Name'] : '';
    }

    public function toArray(): array
    {
        return [
            'ID' => $this->ID,
            'Name' => $this->Name
        ];
    }
}
