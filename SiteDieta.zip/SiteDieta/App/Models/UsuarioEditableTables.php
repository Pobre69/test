<?php

namespace Models;

class UsuarioEditableTables
{
    public int $ID_Usuario;
    public int $ID_QTDE_NUTRIENTES;
    public bool $Selected;

    public function __construct(array $data = [])
    {
        $this->ID_Usuario = isset($data['ID_Usuario']) ? (int)$data['ID_Usuario'] : 0;
        $this->ID_QTDE_NUTRIENTES = isset($data['ID_QTDE_NUTRIENTES']) ? (int)$data['ID_QTDE_NUTRIENTES'] : 0;
        $this->Selected = isset($data['Selected']) ? (bool)$data['Selected'] : false;
    }

    public function toArray(): array
    {
        return [
            'ID_Usuario' => $this->ID_Usuario,
            'ID_QTDE_NUTRIENTES' => $this->ID_QTDE_NUTRIENTES,
            'Selected' => $this->Selected
        ];
    }
}
