<?php

namespace Models;

class Usuario
{
	public int $ID;
	public string $Name;
	public int $Age;
	public string $Email;
	public string $Senha;

	public function __construct(array $data = [])
	{
		$this->ID = isset($data['ID']) ? (int)$data['ID'] : 0;
		$this->Name = isset($data['Name']) ? (string)$data['Name'] : '';
		$this->Age = isset($data['Age']) ? (int)$data['Age'] : 0;
		$this->Email = isset($data['Email']) ? (string)$data['Email'] : '';
		$this->Senha = isset($data['Senha']) ? (string)$data['Senha'] : '';
	}

	public function toArray(): array
	{
		return [
			'ID' => $this->ID,
			'Name' => $this->Name,
			'Age' => $this->Age,
			'Email' => $this->Email,
			'Senha' => $this->Senha
		];
	}
}

