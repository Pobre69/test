<?php

namespace Models;

class InformacoesPessoais
{
    public int $ID_Usuario;
    public int $Idade;
    public string $Sexo;
    public float $Peso_Kg;
    public string $Data_cadastro;

    public function __construct(array $data = [])
    {
        $this->ID_Usuario = isset($data['ID_Usuario']) ? (int)$data['ID_Usuario'] : 0;
        $this->Idade = isset($data['Idade']) ? (int)$data['Idade'] : 0;
        $this->Sexo = isset($data['Sexo']) ? (string)$data['Sexo'] : '';
        $this->Peso_Kg = isset($data['Peso_Kg']) ? (float)$data['Peso_Kg'] : 0.0;
        $this->Data_cadastro = isset($data['Data_cadastro']) ? (string)$data['Data_cadastro'] : '';
    }

    public function toArray(): array
    {
        return [
            'ID_Usuario' => $this->ID_Usuario,
            'Idade' => $this->Idade,
            'Sexo' => $this->Sexo,
            'Peso_Kg' => $this->Peso_Kg,
            'Data_cadastro' => $this->Data_cadastro
        ];
    }
}
