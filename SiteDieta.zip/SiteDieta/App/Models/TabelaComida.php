<?php

namespace Models;

class TabelaComida
{
    public int $ID_Tabela;
    public int $ID_Comida;
    public float $Gramas;

    public function __construct(array $data = [])
    {
        $this->ID_Tabela = isset($data['ID_Tabela']) ? (int)$data['ID_Tabela'] : 0;
        $this->ID_Comida = isset($data['ID_Comida']) ? (int)$data['ID_Comida'] : 0;
        $this->Gramas = isset($data['Gramas']) ? (float)$data['Gramas'] : 0.0;
    }

    public function toArray(): array
    {
        return [
            'ID_Tabela' => $this->ID_Tabela,
            'ID_Comida' => $this->ID_Comida,
            'Gramas' => $this->Gramas
        ];
    }
}
