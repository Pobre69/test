<?php

namespace Models;

class Tabela
{
	public int $ID;
	public int $ID_Cronograma;
	public string $Day_Time;

	public function __construct(array $data = [])
	{
		$this->ID = isset($data['ID']) ? (int)$data['ID'] : 0;
		$this->ID_Cronograma = isset($data['ID_Cronograma']) ? (int)$data['ID_Cronograma'] : 0;
		$this->Day_Time = isset($data['Day_Time']) ? (string)$data['Day_Time'] : '';
	}

	public function toArray(): array
	{
		return [
			'ID' => $this->ID,
			'ID_Cronograma' => $this->ID_Cronograma,
			'Day_Time' => $this->Day_Time
		];
	}
}

