<?php

namespace Models;

class Cronograma
{
	public int $ID;
	public int $ID_Usuario;
	public string $Table_Name;
	public string $Date;

	public function __construct(array $data = [])
	{
		$this->ID = isset($data['ID']) ? (int)$data['ID'] : 0;
		$this->ID_Usuario = isset($data['ID_Usuario']) ? (int)$data['ID_Usuario'] : 0;
		$this->Table_Name = isset($data['Table_Name']) ? (string)$data['Table_Name'] : '';
		$this->Date = isset($data['Date']) ? (string)$data['Date'] : '';
	}

	public function toArray(): array
	{
		return [
			'ID' => $this->ID,
			'ID_Usuario' => $this->ID_Usuario,
			'Table_Name' => $this->Table_Name,
			'Date' => $this->Date
		];
	}
}

