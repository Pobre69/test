<?php

namespace Models;

class QtdeNutrientes
{
    public int $ID;
    public int $qtde_kcal;
    public float $qtde_carboidrato;
    public float $qtde_proteina;
    public float $qtde_gordura_boa;
    public float $qtde_fibra;
    public float $qtde_calcio;
    public float $qtde_fosforo;
    public float $qtde_magnesio;
    public float $qtde_ferro;
    public float $qtde_potassio;
    public float $qtde_sodio;
    public float $qtde_zinco;
    public float $qtde_selenio;
    public float $qtde_cobre;
    public float $qtde_vA;
    public float $qtde_vC;
    public float $qtde_vD;
    public float $qtde_vE;
    public float $qtde_vK;
    public float $qtde_vB1;
    public float $qtde_vB2;
    public float $qtde_vB3;
    public float $qtde_vB5;
    public float $qtde_vB6;
    public float $qtde_vB7;
    public float $qtde_vB9;
    public float $qtde_vB12;

    public function __construct(array $data = [])
    {
        $this->ID = isset($data['ID']) ? (int)$data['ID'] : 0;
        $this->qtde_kcal = isset($data['qtde_kcal']) ? (int)$data['qtde_kcal'] : 0;
        $this->qtde_carboidrato = isset($data['qtde_carboidrato']) ? (float)$data['qtde_carboidrato'] : 0.0;
        $this->qtde_proteina = isset($data['qtde_proteina']) ? (float)$data['qtde_proteina'] : 0.0;
        $this->qtde_gordura_boa = isset($data['qtde_gordura_boa']) ? (float)$data['qtde_gordura_boa'] : 0.0;
        $this->qtde_fibra = isset($data['qtde_fibra']) ? (float)$data['qtde_fibra'] : 0.0;
        $this->qtde_calcio = isset($data['qtde_calcio']) ? (float)$data['qtde_calcio'] : 0.0;
        $this->qtde_fosforo = isset($data['qtde_fosforo']) ? (float)$data['qtde_fosforo'] : 0.0;
        $this->qtde_magnesio = isset($data['qtde_magnesio']) ? (float)$data['qtde_magnesio'] : 0.0;
        $this->qtde_ferro = isset($data['qtde_ferro']) ? (float)$data['qtde_ferro'] : 0.0;
        $this->qtde_potassio = isset($data['qtde_potassio']) ? (float)$data['qtde_potassio'] : 0.0;
        $this->qtde_sodio = isset($data['qtde_sodio']) ? (float)$data['qtde_sodio'] : 0.0;
        $this->qtde_zinco = isset($data['qtde_zinco']) ? (float)$data['qtde_zinco'] : 0.0;
        $this->qtde_selenio = isset($data['qtde_selenio']) ? (float)$data['qtde_selenio'] : 0.0;
        $this->qtde_cobre = isset($data['qtde_cobre']) ? (float)$data['qtde_cobre'] : 0.0;
        $this->qtde_vA = isset($data['qtde_vA']) ? (float)$data['qtde_vA'] : 0.0;
        $this->qtde_vC = isset($data['qtde_vC']) ? (float)$data['qtde_vC'] : 0.0;
        $this->qtde_vD = isset($data['qtde_vD']) ? (float)$data['qtde_vD'] : 0.0;
        $this->qtde_vE = isset($data['qtde_vE']) ? (float)$data['qtde_vE'] : 0.0;
        $this->qtde_vK = isset($data['qtde_vK']) ? (float)$data['qtde_vK'] : 0.0;
        $this->qtde_vB1 = isset($data['qtde_vB1']) ? (float)$data['qtde_vB1'] : 0.0;
        $this->qtde_vB2 = isset($data['qtde_vB2']) ? (float)$data['qtde_vB2'] : 0.0;
        $this->qtde_vB3 = isset($data['qtde_vB3']) ? (float)$data['qtde_vB3'] : 0.0;
        $this->qtde_vB5 = isset($data['qtde_vB5']) ? (float)$data['qtde_vB5'] : 0.0;
        $this->qtde_vB6 = isset($data['qtde_vB6']) ? (float)$data['qtde_vB6'] : 0.0;
        $this->qtde_vB7 = isset($data['qtde_vB7']) ? (float)$data['qtde_vB7'] : 0.0;
        $this->qtde_vB9 = isset($data['qtde_vB9']) ? (float)$data['qtde_vB9'] : 0.0;
        $this->qtde_vB12 = isset($data['qtde_vB12']) ? (float)$data['qtde_vB12'] : 0.0;
    }

    public function toArray(): array
    {
        return get_object_vars($this);
    }
}
