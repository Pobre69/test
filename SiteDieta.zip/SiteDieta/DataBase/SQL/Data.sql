INSERT INTO 
    Comida(food_name,caloria, carboidrato, proteina, gordura_boa, fibra, calcio, fosforo, magnesio, ferro, potassio, sodio, zinco, selenio, cobre, vA, vC, vD, vE, vK, vB1, vB2, vB3, vB5, vB6, vB7, vB9, vB12) 
VALUES
('Tomate',18,3.1,1.1,0.2,1.2,8,24,11,0.3,237,1,0.2,0.1,0.07,250,13.7,0,0.5,8,30,50,0.6,0.1,80,0,15,0),
('Feijão Carioca',76,13.6,4.8,0.2,1.2,8,24,11,0.3,237,1,0.2,0.1,0.07,250,13.7,0,0.5,8,30,50,0.6,0.1,80,0,15,0),
('Arroz Branco',130,28.1,2.7,0.2,0.3,3,43,8,0.2,20,1,0.5,7,0.07,0,0,0,0.1,0.1,40,10,1.5,0.4,60,0,8,0);

/*INSERT INTO 
    Comida(nome,caloria, carboidrato, proteina, gordura_boa, fibra, calcio, fosforo, magnesio, ferro, potassio, sodio, zinco, selenio, cobre, vA, vC, vD, vE, vK, vB1, vB2, vB3, vB5, vB6, vB7, vB9, vB12) 
VALUES
('Arroz Branco',130,28.1,2.7,0.2,0.3,3,43,8,0.2,20,1,0.5,7,0.07,0,0,0,0.1,0.1,40,10,1.5,0.4,60,0,8,0),
('Feijão Preto',62,14,4.8),
('Feijão Carioca',76,13.6,4.8),
('Tomate',18,3.1,1.1,0.2,1.2,8,24,11,0.3,237,1,0.2,0.1,0.07,250,13.7,0,0.5,8,30,50,0.6,0.1,80,0,15,0),
('Manga',0,15,0.8),
('Ovo Cozido',0,1.6,10),
('Ovo Frito',0,1.1,15.6),
('Ovo Mechido',0,2,12),
('Pão de Sal',0,51.9,8.8),
('Pão de Milho',0,48,7.2),
('Pão de Forma',0,49,9.1),
('Pipoca com Óleo',0,64,9.4),
('Pipoca sem Óleo',0,78.9,12.9),
('Peito de Frango Assado',0,0,33.4),
('Peito de Frango Cozido',0,0,31.5),
('Asa de Frango Assado',0,0,26.9),
('Aveia',0,66.3,16.9),
('Batata Cozida',0,11.9,1.2),
('Batata Assada',0,20.1,23),
('Batata Frita',0,45,5),
('Azeite Oliva',0,0,0),
('Cereal Integral',0,70,9),
('Pera',0,15.5,0.4),
('Psyllium',0,4,2.5),
('Lentilha',0,19.8,9),
('Carne Cozida',0,0,29.7),
('Carne Magra',0,0,26),
('Atum',0,0.4,27.3),
('Atum Cru',0,0,25.7);*/