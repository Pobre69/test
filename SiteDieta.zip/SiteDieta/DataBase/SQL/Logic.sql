DELIMITER %
CREATE PROCEDURE INSERIR_USUARIO(IN PARAM_NAME VARCHAR(100),IN PARAM_AGE INT,IN PARAM_EMAIL VARCHAR(100),IN PARAM_SENHA VARCHAR(20))
BEGIN
	DECLARE VAR_VERIFICAR_EMAIL INT DEFAULT 0;
    
    SELECT COUNT(EMAIL) INTO VAR_VERIFICAR_EMAIL FROM USUARIO WHERE EMAIL = PARAM_EMAIL;
    
    IF (VAR_VERIFICAR_EMAIL = 0 AND PARAM_NAME REGEXP '^[A-Za-z0-9 ]+$' AND PARAM_AGE > 0) THEN
		INSERT INTO USUARIO (NAME,AGE,EMAIL,SENHA) VALUES
			(PARAM_NAME,PARAM_AGE,PARAM_EMAIL,PARAM_SENHA);
    ELSE
		SELECT 'ERRO AO PASSAR PARAMETRO' AS RESULTADO;
	END IF;
END%
CREATE PROCEDURE ALTERAR_USUARIO(IN PARAM_ID INT,IN PARAM_NAME VARCHAR(100),IN PARAM_AGE INT,IN PARAM_EMAIL VARCHAR(100),IN PARAM_SENHA VARCHAR(20))
BEGIN
	DECLARE VAR_VERIFICAR_EMAIL INT DEFAULT 0;
    DECLARE VAR_VERIFICAR_USUARIO INT DEFAULT 0;
    
    SELECT COUNT(ID) INTO VAR_VERIFICAR_USUARIO FROM USUARIO WHERE ID = PARAM_ID;
    SELECT COUNT(EMAIL) INTO VAR_VERIFICAR_EMAIL FROM USUARIO WHERE EMAIL = PARAM_EMAIL;
    
    IF (VAR_VERIFICAR_EMAIL = 0 AND PARAM_NAME REGEXP '^[A-Za-z0-9 ]+$' AND PARAM_AGE > 0 AND LOCATE(' ', PARAM_SENHA) = 0) THEN
		IF (VAR_VERIFICAR_USUARIO > 0) THEN
			UPDATE USUARIO
            SET 
				NAME = PARAM_NOME,
                EMAIL = PARAM_EMAIL,
                AGE = PARAM_AGE,
                SENHA = PARAM_SENHA
			WHERE ID = PARAM_ID;
		ELSE
			SELECT 'USUARIO NAO EXISTENTE' AS RESULTADO;
		END IF;
    ELSE
		SELECT 'ERRO AO PASSAR PARAMETRO' AS RESULTADO;
	END IF;
END%
CREATE PROCEDURE EXCLUIR_USUARIO(IN PARAM_ID INT)
BEGIN
	DECLARE VAR_VERIFICAR_USUARIO INT DEFAULT 0;
    
    SELECT COUNT(ID) INTO VAR_VERIFICAR_USUARIO FROM USUARIO WHERE ID = PARAM_ID;
    
    IF (VAR_VERIFICAR_USUARIO > 0) THEN
		DELETE FROM USUARIO WHERE ID = PARAM_ID;
	ELSE
		SELECT 'USUARIO NAO EXISTENTE' AS RESULTADO;
	END IF;
END%
CREATE PROCEDURE INSERIR_CRONOGRAMA(IN PARAM_ID_USUARIO INT,IN PARAM_TABLE_NAME VARCHAR(25))
BEGIN
    DECLARE VAR_VERIFICAR_USUARIO INT DEFAULT 0;

    SELECT COUNT(ID) INTO VAR_VERIFICAR_USUARIO FROM USUARIO WHERE ID = PARAM_ID_USUARIO;

    IF (VAR_VERIFICAR_USUARIO > 0 AND PARAM_TABLE_NAME REGEXP '^[A-Za-z0-9 ]+$') THEN
        INSERT INTO CRONOGRAMA (ID_USUARIO,TABLE_NAME,DATE) VALUES
            (PARAM_ID_USUARIO,PARAM_TABLE_NAME,CURRENT_TIMESTAMP());
    ELSE
        SELECT 'ERRO AO PASSAR PARAMETRO' AS RESULTADO;
    END IF;
END%
CREATE PROCEDURE ALTERAR_CRONOGRAMA(IN PARAM_ID INT,IN PARAM_ID_USUARIO INT,IN PARAM_TABLE_NAME VARCHAR(25))
BEGIN
    DECLARE VAR_VERIFICAR_USUARIO INT DEFAULT 0;
    DECLARE VAR_VERIFICAR_CRONOGRAMA INT DEFAULT 0;

    SELECT COUNT(ID) INTO VAR_VERIFICAR_USUARIO FROM USUARIO WHERE ID = PARAM_ID_USUARIO;
    SELECT COUNT(ID) INTO VAR_VERIFICAR_CRONOGRAMA FROM CRONOGRAMA WHERE ID = PARAM_ID;

    IF (VAR_VERIFICAR_USUARIO > 0 AND VAR_VERIFICAR_CRONOGRAMA > 0 AND PARAM_TABLE_NAME REGEXP '^[A-Za-z0-9 ]+$') THEN
        UPDATE CRONOGRAMA
        SET 
            ID_USUARIO = PARAM_ID_USUARIO,
            TABLE_NAME = PARAM_TABLE_NAME
        WHERE ID = PARAM_ID;
    ELSE
        SELECT 'ERRO AO PASSAR PARAMETRO' AS RESULTADO;
    END IF;
END%
CREATE PROCEDURE EXCLUIR_CRONOGRAMA(IN PARAM_ID INT)
BEGIN
    DECLARE VAR_VERIFICAR_CRONOGRAMA INT DEFAULT 0;

    SELECT COUNT(ID) INTO VAR_VERIFICAR_CRONOGRAMA FROM CRONOGRAMA WHERE ID = PARAM_ID;

    IF (VAR_VERIFICAR_CRONOGRAMA > 0) THEN
        DELETE FROM CRONOGRAMA WHERE ID = PARAM_ID;
    ELSE
        SELECT 'CRONOGRAMA NAO EXISTENTE' AS RESULTADO;
    END IF;
END%
CREATE PROCEDURE INSERIR_TABELA(IN PARAM_ID_CRONOGRAMA INT,IN PARAM_DAY_TIME TIME)
BEGIN
    DECLARE VAR_VERIFICAR_CRONOGRAMA INT DEFAULT 0;

    SELECT COUNT(ID) INTO VAR_VERIFICAR_CRONOGRAMA FROM CRONOGRAMA WHERE ID = PARAM_ID_CRONOGRAMA;

    IF (VAR_VERIFICAR_CRONOGRAMA > 0) THEN
        INSERT INTO TABELA_CRONOGRAMA (ID_CRONOGRAMA,DAY_TIME) VALUES
            (PARAM_ID_CRONOGRAMA,PARAM_DAY_TIME);
    ELSE
        SELECT 'ERRO AO PASSAR PARAMETRO' AS RESULTADO;
    END IF;
END%
CREATE PROCEDURE ALTERAR_TABELA(IN PARAM_ID INT,IN PARAM_ID_CRONOGRAMA INT,IN PARAM_DAY_TIME TIME)
BEGIN
    DECLARE VAR_VERIFICAR_CRONOGRAMA INT DEFAULT 0;
    DECLARE VAR_VERIFICAR_TABELA INT DEFAULT 0;

    SELECT COUNT(ID) INTO VAR_VERIFICAR_CRONOGRAMA FROM CRONOGRAMA WHERE ID = PARAM_ID_CRONOGRAMA;
    SELECT COUNT(ID) INTO VAR_VERIFICAR_TABELA FROM TABELA_CRONOGRAMA WHERE ID = PARAM_ID;

    IF (VAR_VERIFICAR_CRONOGRAMA > 0 AND VAR_VERIFICAR_TABELA > 0) THEN
        UPDATE TABELA_CRONOGRAMA
        SET 
            ID_CRONOGRAMA = PARAM_ID_CRONOGRAMA,
            DAY_TIME = PARAM_DAY_TIME
        WHERE ID = PARAM_ID;
    ELSE
        SELECT 'ERRO AO PASSAR PARAMETRO' AS RESULTADO;
    END IF;
END%
CREATE PROCEDURE EXCLUIR_TABELA(IN PARAM_ID INT)
BEGIN
    DECLARE VAR_VERIFICAR_TABELA INT DEFAULT 0;

    SELECT COUNT(ID) INTO VAR_VERIFICAR_TABELA FROM TABELA_CRONOGRAMA WHERE ID = PARAM_ID;

    IF (VAR_VERIFICAR_TABELA > 0) THEN
        DELETE FROM TABELA_CRONOGRAMA WHERE ID = PARAM_ID;
    ELSE
        SELECT 'TABELA NAO EXISTENTE' AS RESULTADO;
    END IF;
END%
CREATE PROCEDURE INSERIR_TABELA_COMIDA(IN PARAM_ID_TABELA INT,IN PARAM_ID_COMIDA INT,IN PARAM_GRAMAS FLOAT)
BEGIN
    DECLARE VAR_VERIFICAR_TABELA INT DEFAULT 0;
    DECLARE VAR_VERIFICAR_COMIDA INT DEFAULT 0;

    SELECT COUNT(ID) INTO VAR_VERIFICAR_TABELA FROM TABELA_CRONOGRAMA WHERE ID = PARAM_ID_TABELA;
    SELECT COUNT(ID) INTO VAR_VERIFICAR_COMIDA FROM COMIDA WHERE ID = PARAM_ID_COMIDA;

    IF (VAR_VERIFICAR_TABELA > 0 AND VAR_VERIFICAR_COMIDA > 0 AND PARAM_GRAMAS >= 0) THEN
        INSERT INTO TABELA_COMIDA (ID_TABELA,ID_COMIDA,GRAMAS) VALUES
            (PARAM_ID_TABELA,PARAM_ID_COMIDA,PARAM_GRAMAS);
    ELSE
        SELECT 'ERRO AO PASSAR PARAMETRO' AS RESULTADO;
    END IF;
END%
CREATE PROCEDURE ALTERAR_TABELA_COMIDA(IN PARAM_ID_TABELA INT,IN PARAM_ID_COMIDA INT,IN PARAM_GRAMAS FLOAT)
BEGIN
    DECLARE VAR_VERIFICAR_TABELA INT DEFAULT 0;
    DECLARE VAR_VERIFICAR_COMIDA INT DEFAULT 0;

    SELECT COUNT(ID) INTO VAR_VERIFICAR_TABELA FROM TABELA_CRONOGRAMA WHERE ID = PARAM_ID_TABELA;
    SELECT COUNT(ID) INTO VAR_VERIFICAR_COMIDA FROM COMIDA WHERE ID = PARAM_ID_COMIDA;

    IF (VAR_VERIFICAR_TABELA > 0 AND VAR_VERIFICAR_COMIDA > 0 AND PARAM_GRAMAS >= 0) THEN
        UPDATE TABELA_COMIDA
        SET 
            GRAMAS = PARAM_GRAMAS
        WHERE ID_TABELA = PARAM_ID_TABELA AND ID_COMIDA = PARAM_ID_COMIDA;
    ELSE
        SELECT 'ERRO AO PASSAR PARAMETRO' AS RESULTADO;
    END IF;
END%
CREATE PROCEDURE EXCLUIR_TABELA_COMIDA(IN PARAM_ID_TABELA INT,IN PARAM_ID_COMIDA INT)
BEGIN
    DECLARE VAR_VERIFICAR_TABELA INT DEFAULT 0;
    DECLARE VAR_VERIFICAR_COMIDA INT DEFAULT 0;

    SELECT COUNT(ID) INTO VAR_VERIFICAR_TABELA FROM TABELA_CRONOGRAMA WHERE ID = PARAM_ID_TABELA;
    SELECT COUNT(ID) INTO VAR_VERIFICAR_COMIDA FROM COMIDA WHERE ID = PARAM_ID_COMIDA;

    IF (VAR_VERIFICAR_TABELA > 0 AND VAR_VERIFICAR_COMIDA > 0) THEN
        DELETE FROM TABELA_COMIDA WHERE ID_TABELA = PARAM_ID_TABELA AND ID_COMIDA = PARAM_ID_COMIDA;
    ELSE
        SELECT 'ERRO AO PASSAR PARAMETRO' AS RESULTADO;
    END IF;
END%
CREATE PROCEDURE INSERIR_COMIDA(IN PARAM_NAME VARCHAR(100),IN PARAM_ID_QTDE_NUTRIENTES INT)
BEGIN
    DECLARE VAR_VERIFICAR_QTDE_NUTRIENTES INT DEFAULT 0;

    SELECT COUNT(ID) INTO VAR_VERIFICAR_QTDE_NUTRIENTES FROM QTDE_NUTRIENTES WHERE ID = PARAM_ID_QTDE_NUTRIENTES;

    IF (VAR_VERIFICAR_QTDE_NUTRIENTES > 0 AND PARAM_NAME REGEXP '^[A-Za-z0-9 ]+$') THEN
        INSERT INTO COMIDA (ID,NAME) VALUES
            (PARAM_NAME,PARAM_ID_QTDE_NUTRIENTES);
    ELSE
        SELECT 'ERRO AO PASSAR PARAMETRO' AS RESULTADO;
    END IF;
END%
CREATE PROCEDURE ALTERAR_COMIDA(IN PARAM_ID INT,IN PARAM_NAME VARCHAR(100),IN PARAM_ID_QTDE_NUTRIENTES INT)
BEGIN
    DECLARE VAR_VERIFICAR_QTDE_NUTRIENTES INT DEFAULT 0;
    DECLARE VAR_VERIFICAR_COMIDA INT DEFAULT 0;

    SELECT COUNT(ID) INTO VAR_VERIFICAR_QTDE_NUTRIENTES FROM QTDE_NUTRIENTES WHERE ID = PARAM_ID_QTDE_NUTRIENTES;
    SELECT COUNT(ID) INTO VAR_VERIFICAR_COMIDA FROM COMIDA WHERE ID = PARAM_ID;

    IF (VAR_VERIFICAR_QTDE_NUTRIENTES > 0 AND VAR_VERIFICAR_COMIDA > 0 AND PARAM_NAME REGEXP '^[A-Za-z0-9 ]+$') THEN
        UPDATE COMIDA
        SET 
            NAME = PARAM_NAME,
            ID_QTDE_NUTRIENTES = PARAM_ID_QTDE_NUTRIENTES
        WHERE ID = PARAM_ID;
    ELSE
        SELECT 'ERRO AO PASSAR PARAMETRO' AS RESULTADO;
    END IF;
END%
CREATE PROCEDURE EXCLUIR_COMIDA(IN PARAM_ID INT)
BEGIN
    DECLARE VAR_VERIFICAR_COMIDA INT DEFAULT 0;

    SELECT COUNT(ID) INTO VAR_VERIFICAR_COMIDA FROM COMIDA WHERE ID = PARAM_ID;

    IF (VAR_VERIFICAR_COMIDA > 0) THEN
        DELETE FROM COMIDA WHERE ID = PARAM_ID;
    ELSE
        SELECT 'COMIDA NAO EXISTENTE' AS RESULTADO;
    END IF;
END%
CREATE PROCEDURE INSERIR_INFORMACOES_PESSOAIS(IN PARAM_ID_USUARIO INT,IN PARAM_IDADE INT,IN PARAM_SEXO CHAR(1),IN PARAM_PESO FLOAT)
BEGIN
    DECLARE VAR_VERIFICAR_USUARIO INT DEFAULT 0;

    SELECT COUNT(ID) INTO VAR_VERIFICAR_USUARIO FROM USUARIO WHERE ID = PARAM_ID_USUARIO;

    IF (VAR_VERIFICAR_USUARIO > 0 AND (PARAM_SEXO = 'M' OR PARAM_SEXO = 'F') AND PARAM_PESO > 0 AND PARAM_IDADE > 0) THEN
        INSERT INTO INFORMACOESPESSOAIS (ID_USUARIO,IDADE,SEXO,Peso_Kg,DATA_CADASTRO) VALUES
            (PARAM_ID_USUARIO,PARAM_IDADE,PARAM_SEXO,PARAM_PESO,CURRENT_TIMESTAMP());
    ELSE
        SELECT 'ERRO AO PASSAR PARAMETRO' AS RESULTADO;
    END IF;
END%
CREATE PROCEDURE ALTERAR_INFORMACOES_PESSOAIS(IN PARAM_ID_USUARIO INT,IN PARAM_IDADE INT,IN PARAM_SEXO CHAR(1),IN PARAM_PESO FLOAT)
BEGIN
    DECLARE VAR_VERIFICAR_USUARIO INT DEFAULT 0;

    SELECT COUNT(ID) INTO VAR_VERIFICAR_USUARIO FROM USUARIO WHERE ID = PARAM_ID_USUARIO;

    IF (VAR_VERIFICAR_USUARIO > 0 AND (PARAM_SEXO = 'M' OR PARAM_SEXO = 'F') AND PARAM_PESO > 0 AND PARAM_IDADE > 0) THEN
        UPDATE INFORMACOESPESSOAIS
        SET 
            IDADE = PARAM_IDADE,
            SEXO = PARAM_SEXO,
            Peso_Kg = PARAM_PESO
        WHERE ID_USUARIO = PARAM_ID_USUARIO;
    ELSE
        SELECT 'ERRO AO PASSAR PARAMETRO' AS RESULTADO;
    END IF;
END%
CREATE PROCEDURE EXCLUIR_INFORMACOES_PESSOAIS(IN PARAM_ID_USUARIO INT)
BEGIN
    DECLARE VAR_VERIFICAR_USUARIO INT DEFAULT 0;

    SELECT COUNT(ID) INTO VAR_VERIFICAR_USUARIO FROM USUARIO WHERE ID = PARAM_ID_USUARIO;

    IF (VAR_VERIFICAR_USUARIO > 0) THEN
        DELETE FROM INFORMACOESPESSOAIS WHERE ID_USUARIO = PARAM_ID_USUARIO;
    ELSE
        SELECT 'ERRO AO PASSAR PARAMETRO' AS RESULTADO;
    END IF;
END%
CREATE PROCEDURE INSERIR_USUARIO_EDITABLE_TABLES(IN PARAM_ID_USUARIO INT,IN PARAM_ID_QTDE_NUTRIENTES INT,IN PARAM_SELECTED TINYINT(1))
BEGIN
    DECLARE VAR_VERIFICAR_USUARIO INT DEFAULT 0;
    DECLARE VAR_VERIFICAR_QTDE_NUTRIENTES INT DEFAULT 0;

    SELECT COUNT(ID) INTO VAR_VERIFICAR_USUARIO FROM USUARIO WHERE ID = PARAM_ID_USUARIO;
    SELECT COUNT(ID) INTO VAR_VERIFICAR_QTDE_NUTRIENTES FROM QTDE_NUTRIENTES WHERE ID = PARAM_ID_QTDE_NUTRIENTES;

    IF (VAR_VERIFICAR_USUARIO > 0 AND VAR_VERIFICAR_QTDE_NUTRIENTES > 0) THEN
        INSERT INTO USUARIOEDITABLETABLES (ID_USUARIO,ID_QTDE_NUTRIENTES,SELECTED) VALUES
            (PARAM_ID_USUARIO,PARAM_ID_QTDE_NUTRIENTES,PARAM_SELECTED);
    ELSE
        SELECT 'ERRO AO PASSAR PARAMETRO' AS RESULTADO;
    END IF;
END%
CREATE PROCEDURE ALTERAR_USUARIO_EDITABLE_TABLES(IN PARAM_ID_USUARIO INT,IN PARAM_ID_QTDE_NUTRIENTES INT,IN PARAM_SELECTED TINYINT(1))
BEGIN
    DECLARE VAR_VERIFICAR_USUARIO INT DEFAULT 0;
    DECLARE VAR_VERIFICAR_QTDE_NUTRIENTES INT DEFAULT 0;

    SELECT COUNT(ID) INTO VAR_VERIFICAR_USUARIO FROM USUARIO WHERE ID = PARAM_ID_USUARIO;
    SELECT COUNT(ID) INTO VAR_VERIFICAR_QTDE_NUTRIENTES FROM QTDE_NUTRIENTES WHERE ID = PARAM_ID_QTDE_NUTRIENTES;

    IF (VAR_VERIFICAR_USUARIO > 0 AND VAR_VERIFICAR_QTDE_NUTRIENTES > 0) THEN
        UPDATE USUARIOEDITABLETABLES
        SET 
            ID_QTDE_NUTRIENTES = PARAM_ID_QTDE_NUTRIENTES,
            SELECTED = PARAM_SELECTED
        WHERE ID_USUARIO = PARAM_ID_USUARIO;
    ELSE
        SELECT 'ERRO AO PASSAR PARAMETRO' AS RESULTADO;
    END IF;
END%
CREATE PROCEDURE EXCLUIR_USUARIO_EDITABLE_TABLES(IN PARAM_ID_USUARIO INT,IN PARAM_ID_QTDE_NUTRIENTES INT)
BEGIN
    DECLARE VAR_VERIFICAR_USUARIO INT DEFAULT 0;
    DECLARE VAR_VERIFICAR_QTDE_NUTRIENTES INT DEFAULT 0;

    SELECT COUNT(ID) INTO VAR_VERIFICAR_USUARIO FROM USUARIO WHERE ID = PARAM_ID_USUARIO;
    SELECT COUNT(ID) INTO VAR_VERIFICAR_QTDE_NUTRIENTES FROM QTDE_NUTRIENTES WHERE ID = PARAM_ID_QTDE_NUTRIENTES;

    IF (VAR_VERIFICAR_USUARIO > 0 AND VAR_VERIFICAR_QTDE_NUTRIENTES > 0) THEN
        DELETE FROM USUARIOEDITABLETABLES
        WHERE ID_USUARIO = PARAM_ID_USUARIO;
        DELETE FROM QTDE_NUTRIENTES
        WHERE ID = PARAM_ID_QTDE_NUTRIENTES;
    ELSE
        SELECT 'ERRO AO PASSAR PARAMETRO' AS RESULTADO;
    END IF;
END%
CREATE PROCEDURE INSERIR_QTDE_NUTRIENTES(IN param_cal FLOAT,IN param_carboidrato FLOAT,IN param_proteina FLOAT,IN param_gorduraBoa FLOAT,IN param_fibra FLOAT,IN param_calcio FLOAT,IN param_fosforo FLOAT,IN param_magnesio FLOAT,IN param_ferro FLOAT,IN param_potassio FLOAT,IN param_sodio FLOAT,IN param_zinco FLOAT,IN param_selenio FLOAT,IN param_cobre FLOAT,IN param_vA FLOAT,IN param_vC FLOAT,IN param_vD FLOAT,IN param_vE FLOAT,IN param_vK FLOAT,IN param_vB1 FLOAT,IN param_vB2 FLOAT,IN param_vB3 FLOAT,IN param_VB5 FLOAT,IN param_vB6 FLOAT,IN param_vB7 FLOAT,IN param_vB9 FLOAT,IN param_vB12 FLOAT)
BEGIN
    IF (LEAST(param_cal,param_carboidrato,param_proteina,param_gorduraBoa,param_fibra,param_calcio,param_fosforo,param_magnesio,param_ferro,param_potassio,param_sodio,param_zinco,param_selenio,param_cobre,param_vA,param_vC,param_vD,param_vE,param_vK,param_vB1,param_vB2,param_vB3,param_VB5,param_vB6,param_vB7,param_vB9,param_vB12)>=0) THEN
        INSERT INTO qtde_Nutrientes(id_Usuario,caloria,table_name, carboidrato, proteina, gordura_boa, fibra, calcio, fosforo, magnesio, ferro, potassio, sodio, zinco, selenio, cobre, vA, vC, vD, vE, vK, vB1, vB2, vB3, vB5, vB6, vB7, vB9, vB12) VALUES 
            (param_UsuarioID,param_cal,param_TableName,param_carboidrato,param_proteina,param_gorduraBoa,param_fibra,param_calcio,param_fosforo,param_magnesio,param_ferro,param_potassio,param_sodio,param_zinco,param_selenio,param_cobre,param_vA,param_vC,param_vD,param_vE,param_vK,param_vB1,param_vB2,param_vB3,param_VB5,param_vB6,param_vB7,param_vB9,param_vB12);
    ELSE   
        SELECT 'ERRO AO PASSAR PARAMETRO' AS RESULTADO;
    END IF;
END%
CREATE PROCEDURE ALTERAR_QTDE_NUTRIENTES(IN param_ID INT,IN param_cal FLOAT,IN param_carboidrato FLOAT,IN param_proteina FLOAT,IN param_gorduraBoa FLOAT,IN param_fibra FLOAT,IN param_calcio FLOAT,IN param_fosforo FLOAT,IN param_magnesio FLOAT,IN param_ferro FLOAT,IN param_potassio FLOAT,IN param_sodio FLOAT,IN param_zinco FLOAT,IN param_selenio FLOAT,IN param_cobre FLOAT,IN param_vA FLOAT,IN param_vC FLOAT,IN param_vD FLOAT,IN param_vE FLOAT,IN param_vK FLOAT,IN param_vB1 FLOAT,IN param_vB2 FLOAT,IN param_vB3 FLOAT,IN param_VB5 FLOAT,IN param_vB6 FLOAT,IN param_vB7 FLOAT,IN param_vB9 FLOAT,IN param_vB12 FLOAT)
BEGIN
    IF (LEAST(param_cal,param_carboidrato,param_proteina,param_gorduraBoa,param_fibra,param_calcio,param_fosforo,param_magnesio,param_ferro,param_potassio,param_sodio,param_zinco,param_selenio,param_cobre,param_vA,param_vC,param_vD,param_vE,param_vK,param_vB1,param_vB2,param_vB3,param_VB5,param_vB6,param_vB7,param_vB9,param_vB12)>=0) THEN
        UPDATE qtde_Nutrientes
        SET 
            QTDE_KCAL = param_cal,
            QTDE_CARBOIDRATO = param_carboidrato,
            QTDE_PROTEINA = param_proteina,
            QTDE_gordura_boa = param_gorduraBoa,
            QTDE_fibra = param_fibra,
            QTDE_calcio = param_calcio,
            QTDE_fosforo = param_fosforo,
            QTDE_magnesio = param_magnesio,
            QTDE_ferro = param_ferro,
            QTDE_potassio = param_potassio,
            QTDE_sodio = param_sodio,
            QTDE_zinco = param_zinco,
            QTDE_selenio = param_selenio,
            QTDE_cobre = param_cobre,
            QTDE_vA = param_vA,
            QTDE_vC = param_vC,
            QTDE_vD = param_vD,
            QTDE_vE = param_vE,
            QTDE_vK = param_vK,
            QTDE_vB1 = param_vB1,
            QTDE_vB2 = param_vB2,
            QTDE_vB3 = param_vB3,
            QTDE_vB5 = param_VB5,
            QTDE_vB6 = param_vB6,
            QTDE_vB7 = param_vB7,
            QTDE_vB9 = param_vB9,
            QTDE_vB12 = param_vB12
        WHERE ID = param_ID;
    ELSE   
        SELECT 'ERRO AO PASSAR PARAMETRO' AS RESULTADO;
    END IF;
END%
CREATE PROCEDURE EXCLUIR_QTDE_NUTRIENTES(IN PARAM_ID INT)
BEGIN
    DECLARE VAR_VERIFICAR_TABELA INT DEFAULT 0;

    SELECT COUNT(ID) INTO VAR_VERIFICAR_TABELA FROM qtde_Nutrientes WHERE ID = PARAM_ID;

    IF (VAR_VERIFICAR_TABELA > 0) THEN
        DELETE FROM qtde_Nutrientes
        WHERE ID = PARAM_ID;
    ELSE
        SELECT 'ERRO AO PASSAR PARAMETRO' AS RESULTADO;
    END IF;
END%
DELIMITER ;








DELIMITER %
CREATE PROCEDURE CriarUsuario(IN param_nome VARCHAR(100), IN param_idade INT, IN param_email VARCHAR(100),IN param_senha VARCHAR(20),OUT param_UsuarioID INT) 
BEGIN
	DECLARE var_ExistEmail INT DEFAULT 0;
    SELECT COUNT(email) INTO var_ExistEmail FROM Usuario WHERE email = param_email;
    IF (LOCATE('@',param_email) != 0 AND var_ExistEmail = 0) THEN
        IF (LENGTH(param_senha) <= 20 AND LOCATE(' ',param_senha) = 0 AND LOCATE('-',param_senha) = 0) THEN
            INSERT INTO Usuario(u_name,age,email,senha) VALUE (param_nome,param_idade,param_email,param_senha);
            SELECT id INTO param_UsuarioID FROM Usuario WHERE email = param_email;
        ELSE
            SELECT 'SENHA INVALIDA' AS RESULTADO;
        END IF;
    ELSE
        SELECT 'EMAIL INVALIDO' AS RESULTADO;
    END IF;
END%
CREATE PROCEDURE BuscarUsuario(IN param_email VARCHAR(100),IN param_senha VARCHAR(20),OUT param_UsuarioID_Show INT)
BEGIN
    IF (LOCATE('@',param_email) > 0) THEN
        IF (LENGTH(param_senha) <= 20 AND LOCATE(' ',param_senha) = 0 AND LOCATE('-',param_senha) = 0) THEN
            SELECT IFNULL(id,0) INTO param_UsuarioID_Show FROM Usuario WHERE email = param_email AND senha = param_senha;
        ELSE
            SELECT 'SENHA INVALIDA' AS RESULTADO;
        END IF;
    ELSE
        SELECT 'EMAIL INVALIDO' AS RESULTADO;
    END IF;
END%
CREATE PROCEDURE AlterarUsaurio(IN param_UsuarioID INT,IN param_IsDeleteing TINYINT(1),IN param_nome VARCHAR(100), IN param_idade INT, IN param_email VARCHAR(100),IN param_senha VARCHAR(20))
BEGIN
	IF (param_UsuarioID > 0) THEN
		IF (param_IsDeleteing = 1) THEN
			DELETE FROM Usuario WHERE ID = param_UsuarioID;
		ELSE
			IF (LENGTH(param_senha) <= 20 AND LOCATE(' ',param_senha) = 0 AND LOCATE('-',param_senha) = 0) THEN
				UPDATE Usuario 
                SET 
					u_name = param_nome,
                    email = param_email,
                    senha = param_senha,
                    age = param_idade
				WHERE
					ID = param_UsuarioID;
			ELSE
				SELECT 'SENHA INVALIDA' AS RESULTADO;
			END IF;
		END IF;
    ELSE
		SELECT 'ERRO AO PASSAR PARAMETRO' AS RESULTADO;
	END IF;
END%
CREATE PROCEDURE CriarCronograma(IN param_UsuarioID INT,IN param_nome VARCHAR(25),OUT param_ID INT)
BEGIN
    DECLARE var_verificarNome INT DEFAULT 0;
    
    IF (param_nome REGEXP '^[A-Za-z0-9 ]+$' AND param_UsuarioID > 0) THEN
        SELECT
            COUNT(table_name) INTO var_verificarNome
        FROM
            Cronograma
        WHERE
            table_name = param_nome
            AND id_Usuario = var_idUsuario;
        IF (var_verificarNome = 0) THEN
            INSERT INTO Cronograma(id_Usuario,table_name) VALUE (param_UsuarioID,param_nome);
            SELECT id INTO param_ID FROM Cronograma WHERE id_Usuario = param_UsuarioID AND table_name = param_nome;
        ELSE
            SELECT 'TABELA JA EXISTENTE' AS RESULTADO;
        END IF;
    ELSE
        SELECT 'ERRO AO PASSAR PARAEMTRO' AS RESULTADO;
    END IF;
END%
CREATE PROCEDURE ExcluirCronograma(IN param_UsuarioID INT,IN param_nome VARCHAR(25),IN param_cronogramaID INT)
BEGIN
    IF (param_cronogramaID > 0 AND param_nome REGEXP '^[A-Za-z0-9 ]+$' AND param_UsuarioID > 0) THEN
        DELETE FROM Cronograma
        WHERE
            id_Usuario = param_UsuarioID
            AND table_name = param_nome
            AND id = param_cronogramaID;
    ELSE
        SELECT 'ERRO AO PASSAR PARAMETROS' AS RESULTADO;
    END IF;
END%
CREATE PROCEDURE AlterarCronograma(IN param_UsuarioID INT,IN param_NovoNome VARCHAR(25),IN param_id INT)
BEGIN
	DECLARE var_verificarNome INT DEFAULT 0;
	IF (param_NovoNome REGEXP '^[A-Za-z0-9 ]+$' AND param_UsuarioID > 0 AND param_id > 0) THEN
        SELECT
            COUNT(table_name) INTO var_verificarNome
        FROM
            Cronograma
        WHERE
            table_name = param_NovoNome
            AND id_Usuario = var_idUsuario;
        IF (var_verificarNome = 0) THEN
            UPDATE Cronograma 
            SET table_name = param_NovoNome 
            WHERE 
				id = param_id 
                AND id_Usuario = param_UsuarioID;
		ELSE
            SELECT 'NOME DE TABELA JA EXISTENTE' AS RESULTADO;
        END IF;
    ELSE
        SELECT 'ERRO AO PASSAR PARAMETRO' AS RESULTADO;
    END IF;
END%
CREATE PROCEDURE CriarTabela_Cronograma(IN param_idUsuario INT,IN param_hora TIME,IN param_tableName VARCHAR(25),OUT param_IdTabela INT)
BEGIN
    DECLARE var_idCronograma INT DEFAULT 0;
    DECLARE var_Verificar INT DEFAULT 0;
    SELECT
        id INTO var_idCronograma
	FROM
		Cronograma
    WHERE
        id_Usuario = param_idUsuario
        AND table_name = param_tableName;
	SELECT
		COUNT(day_time) INTO var_Verificar
	FROM
		Tabela_Cronograma
	WHERE
		id_cronograma = var_idCronograma
        AND day_time = param_hora;
    IF (param_idUsuario > 0 AND var_idCronograma > 0) THEN
		IF (var_Verificar = 0) THEN
			INSERT INTO Tabela_Cronograma(id_Cronograma,day_time) VALUE (var_idCronograma,param_hora);
            SELECT
				id INTO param_IdTabela
			FROM
				Tabela_Cronograma
			WHERE
				id_Cronograma = var_idCronograma
                AND day_time = param_hora;
		ELSE
			SELECT 'TABELA JA EXISTENTE' AS RESULTADO;
		END IF;
    ELSE
        SELECT 'ERRO AO PASSAR PARAMETRO' AS RESULTADO;
    END IF;
END%
CREATE PROCEDURE ExcluirTabela_Cronograma(IN param_UsuarioID VARCHAR(100),IN param_CronogramaID VARCHAR(25),IN param_tableID INT)
BEGIN
    IF (param_UsuarioID > 0 AND param_CronogramaID > 0 AND param_tableID > 0) THEN
		DELETE FROM Tabela_Cronograma 
		WHERE 
			id_Cronograma = param_CronogramaID
			AND Tabela_Cronograma.id = param_tableID;
    ELSE
        SELECT 'ERRO AO PASSAR PARAMETRO' AS RESULTADO;
    END IF;
END%
CREATE PROCEDURE AlterarTabela_Cronograma(IN param_horarioNovo TIME,IN param_tableID INT,IN param_cronogramaID INT)
BEGIN
	DECLARE var_idCronograma INT DEFAULT 0;

	SELECT
		COUNT(day_time) INTO var_idCronograma
	FROM
		Tabela_Cronograma
	WHERE
		id_cronograma = param_cronogramaID
        AND day_time = param_horarioNovo;
	IF(param_tableID > 0 AND param_cronogramaID > 0) THEN
		IF (var_idCronograma = 0) THEN
			UPDATE Tabela_Cronograma SET day_time = param_horarioNovo WHERE id = param_tableID AND id_Cronograma = param_cronogramaID;
		ELSE
			SELECT 'TABELA JA EXISTE' AS RESULTADO;
		END IF;
	ELSE
		SELECT 'ERRO AO PASSAR PARAMETRO' AS RESULTADO;
	END IF;
END%
CREATE PROCEDURE CriarInfoUsuario(IN param_UsuarioID INT,IN param_sexo CHAR(1),IN param_peso INT,OUT param_Idade INT)
BEGIN
    DECLARE var_verificarID INT DEFAULT 0;
    DECLARE var_Idade INT DEFAULT 0;
    SELECT id INTO var_verificarID FROM Usuario WHERE id = param_UsuarioID;
    IF (var_verificarID > 0) THEN
        SELECT age INTO var_Idade FROM Usuario WHERE id = param_UsuarioID;
        IF ((param_sexo = 'M' OR param_sexo = 'F') AND param_peso > 0) THEN
            INSERT INTO InformacoesPessoais(id_Usuario,Idade,Sexo,Peso,QTDE_TableSelected,TableEditableSelected) VALUE (param_UsuarioID,var_Idade,param_sexo,param_peso,0,0);
        ELSE
            SELECT 'ERRO AO PASSAR PARAMETRO' AS RESULTADO;
        END IF;
    ELSE
        SELECT 'ERRO AO ENCONTRAR USUARIO' AS RESULTADO;
    END IF;
END%
CREATE PROCEDURE AlterarInfoUsuario(IN param_UsuarioID INT,IN param_Idade INT,IN param_sexo CHAR(1),IN param_peso INT,IN param_TableSelected INT,IN param_TableEditable INT,IN param_IsDeleting TINYINT(1))
BEGIN
    DECLARE var_verificarID INT DEFAULT 0;
    SELECT id INTO var_verificarID FROM Usuario WHERE id = param_UsuarioID;
    IF (var_verificarID > 0) THEN
		IF (param_IsDeleting = 1) THEN
			DELETE FROM InformacoesPessoais WHERE id_Usuario = param_UsuarioID;
        ELSE
			IF ((param_sexo = 'M' OR param_sexo = 'F') AND param_peso > 0 AND param_Idade > 0) THEN
				UPDATE InformacoesPessoais
				SET 
					Idade = param_Idade,
					Sexo = param_sexo,
					Peso = param_peso,
					QTDE_TableSelected = param_TableSelected,
					TableEditableSelected = param_TableEditable
				WHERE id_Usuario = param_UsuarioID;
			ELSE
				SELECT 'ERRO AO PASSAR PARAMETRO' AS RESULTADO;
			END IF;
        END IF;
    ELSE
        SELECT 'ERRO AO ENCONTRAR USUARIO' AS RESULTADO;
    END IF;
END%
CREATE PROCEDURE CriarInfoDoenca(IN param_UsuarioID INT,IN param_Doenca VARCHAR(100))
BEGIN
	DECLARE var_verificarID INT DEFAULT 0;
    SELECT id INTO var_verificarID FROM Usuario WHERE id = param_UsuarioID;
    IF (var_verificarID > 0) THEN
		IF (param_Doenca REGEXP '^[A-Za-z0-9 ]+$') THEN
			INSERT INTO InfoDoenca(id,Doenca) VALUES (param_UsuarioID,param_Doenca);
		ELSE
			SELECT 'ERRO AO PASSAR PARAMETRO' AS RESULTADO;
		END IF;
	ELSE
		SELECT 'ERRO AO ENCONTRAR USUARIO' AS RESULTADO;
	END IF;
END%
CREATE PROCEDURE AlterarInfoDoenca(IN param_UsuarioID INT,IN param_Doenca VARCHAR(100),IN param_IsDeleting TINYINT(1))
BEGIN
	DECLARE var_verificarID INT DEFAULT 0;
    SELECT id INTO var_verificarID FROM Usuario WHERE id = param_UsuarioID;
    IF (var_verificarID > 0) THEN
		IF (param_IsDeleting = 1) THEN
			DELETE FROM InfoDoenca WHERE id = param_UsuarioID;
        ELSE
			IF (param_Doenca REGEXP '^[A-Za-z0-9 ]+$') THEN
				INSERT INTO InfoDoenca(id,Doenca) VALUES (param_UsuarioID,param_Doenca);
			ELSE
				SELECT 'ERRO AO PASSAR PARAMETRO' AS RESULTADO;
			END IF;
		END IF;
	ELSE
		SELECT 'ERRO AO ENCONTRAR USUARIO' AS RESULTADO;
	END IF;
END%
CREATE PROCEDURE CriarInfoDeficiencia(IN param_UsuarioID INT,IN param_Deficiencia VARCHAR(100),OUT param_ID INT)
BEGIN
	DECLARE var_verificarID INT DEFAULT 0;
    SELECT id INTO var_verificarID FROM Usuario WHERE id = param_UsuarioID;
    IF (var_verificarID > 0) THEN
		IF (param_Deficiencia REGEXP '^[A-Za-z0-9 ]+$') THEN
			INSERT INTO InfoDoenca(id_Usuario,Deficiencia) VALUES (param_UsuarioID,param_Deficiencia);
            SELECT
				id INTO param_Id
			FROM
				InfoDoenca
			WHERE
				id_Usuario = param_UsuarioID
                AND Deficiencia = param_Deficiencia
			ORDER BY id DESC;
		ELSE
			SELECT 'ERRO AO PASSAR PARAMETRO' AS RESULTADO;
		END IF;
	ELSE
		SELECT 'ERRO AO ENCONTRAR USUARIO' AS RESULTADO;
	END IF;
END%
CREATE PROCEDURE AlterarInfoDeficiencia(IN param_ID INT,IN param_Deficiencia VARCHAR(100),IN param_IsDeleting TINYINT(1))
BEGIN
    IF (param_ID > 0) THEN
		IF (param_IsDeleting = 1) THEN
			DELETE FROM InfoDoenca WHERE id = param_ID;
        ELSE
			IF (param_Deficiencia REGEXP '^[A-Za-z0-9 ]+$') THEN
				UPDATE InfoDoenca
                SET Deficiencia = param_Deficiencia
				WHERE id = param_ID;
			ELSE
				SELECT 'ERRO AO PASSAR PARAMETRO' AS RESULTADO;
			END IF;
		END IF;
	ELSE
		SELECT 'ERRO AO ENCONTRAR DE ID' AS RESULTADO;
	END IF;
END%
CREATE PROCEDURE CriarInfoEA(IN param_UsuarioID INT,IN param_EventoAgudo VARCHAR(100),IN param_Gravidez TINYINT(1),IN param_Lactacao TINYINT(1))
BEGIN
	DECLARE var_verificarID INT DEFAULT 0;
    SELECT id INTO var_verificarID FROM Usuario WHERE id = param_UsuarioID;
	IF (var_verificarID > 0 AND param_EventoAgudo REGEXP '^[A-Za-z0-9 ]+$') THEN
		INSERT INTO InfoEvento_agudo(id,Evento_Agudo,Gravidez,Lactacao) VALUES (param_UsuarioID,param_EventoAgudo,param_Gravidez,param_Lactacao);
    ELSE
		SELECT 'ERRO AO PASSAR PARAMETRO' AS RESULTADO;
    END IF;
END%
CREATE PROCEDURE AlterarInfoEA(IN param_UsuarioID INT,IN param_EventoAgudo VARCHAR(100),IN param_Gravidez TINYINT(1),IN param_Lactacao TINYINT(1),IN param_IsDeleting TINYINT(1))
BEGIN
	IF (param_UsuarioID > 0) THEN
		IF (param_IsDeleting = 1) THEN
			DELETE FROM InfoEvento_agudo WHERE id = param_UsuarioID;
        ELSE
			IF (param_EventoAgudo REGEXP '^[A-Za-z0-9 ]+$') THEN
				INSERT INTO InfoEvento_agudo(id,Evento_Agudo,Gravidez,Lactacao) VALUES (param_UsuarioID,param_EventoAgudo,param_Gravidez,param_Lactacao);
			ELSE
				SELECT 'ERRO AO PASSAR PARAMETRO' AS RESULTADO;
			END IF;
		END IF;
    ELSE
		SELECT 'ERRO AO PASSAR USUARIO' AS RESULTADO;
	END IF;
END%




CREATE PROCEDURE BuscarComida(IN param_nomeComida VARCHAR(100),OUT param_cal FLOAT,OUT param_carboidrato FLOAT,OUT param_proteina FLOAT,OUT param_gorduraBoa FLOAT,OUT param_fibra FLOAT,OUT param_calcio FLOAT,OUT param_fosforo FLOAT,OUT param_magnesio FLOAT,OUT param_ferro FLOAT,OUT param_potassio FLOAT,OUT param_sodio FLOAT,OUT param_zinco FLOAT,OUT param_selenio FLOAT,OUT param_cobre FLOAT,OUT param_vA FLOAT,OUT param_vC FLOAT,OUT param_vD FLOAT,OUT param_vE FLOAT,OUT param_vK FLOAT,OUT param_vB1 FLOAT,OUT param_vB2 FLOAT,OUT param_vB3 FLOAT,OUT param_vB5 FLOAT,OUT param_vB6 FLOAT,OUT param_vB7 FLOAT,OUT param_vB9 FLOAT,OUT param_vB12 FLOAT,OUT param_nomeComidaEncontrada VARCHAR(100))
BEGIN
    DECLARE var_verificarComida VARCHAR(100) DEFAULT NULL;
    SELECT food_name INTO var_verificarComida FROM Comida WHERE food_name LIKE CONCAT(param_nomeComida, '%') ORDER BY food_name ASC LIMIT 1;
    IF (var_verificarComida = NULL) THEN
		SET param_cal = 0;
        SET param_carboidrato = 0;
        SET param_proteina = 0;
        SET param_gorduraBoa = 0;
        SET param_fibra = 0;
        SET param_calcio = 0;
        SET param_fosforo = 0;
        SET param_magnesio = 0;
        SET param_ferro = 0;
        SET param_potassio = 0;
        SET param_sodio = 0;
        SET param_zinco = 0;
        SET param_selenio = 0;
        SET param_cobre = 0;
        SET param_vA = 0;
        SET param_vC = 0;
        SET param_vD = 0;
        SET param_vE = 0;
        SET param_vK = 0;
        SET param_vB1 = 0;
        SET param_vB2 = 0;
        SET param_vB3 = 0;
        SET param_VB5 = 0;
        SET param_vB6 = 0;
        SET param_vB7 = 0;
        SET param_vB9 = 0;
        SET param_vB12 = 0;
        SET param_nomeComidaEncontrada = 'Nome inválido';
    ELSE
        SELECT
			ROUND(caloria, 2),
			ROUND(carboidrato, 2),
			ROUND(proteina, 2),
			ROUND(gordura_boa, 2),
			ROUND(fibra, 2),
			ROUND(calcio, 2),
			ROUND(fosforo, 2),
			ROUND(magnesio, 2),
			ROUND(ferro, 2),
			ROUND(potassio, 2),
			ROUND(sodio, 2),
			ROUND(zinco, 2),
			ROUND(selenio, 2),
			ROUND(cobre, 2),
			ROUND(vA, 2),
			ROUND(vC, 2),
			ROUND(vD, 2),
			ROUND(vE, 2),
			ROUND(vK, 2),
			ROUND(vB1, 2),
			ROUND(vB2, 2),
			ROUND(vB3, 2),
			ROUND(vB5, 2),
			ROUND(vB6, 2),
			ROUND(vB7, 2),
			ROUND(vB9, 2),
			ROUND(vB12, 2),
			food_name
        INTO
            param_cal,
            param_carboidrato,
            param_proteina,
            param_gorduraBoa,
            param_fibra,
            param_calcio,
            param_fosforo,
            param_magnesio,
            param_ferro,
            param_potassio,
            param_sodio,
            param_zinco,
            param_selenio,
            param_cobre,
            param_vA,
            param_vC,
            param_vD,
            param_vE,
            param_vK,
            param_vB1,
            param_vB2,
            param_vB3,
            param_VB5,
            param_vB6,
            param_vB7,
            param_vB9,
            param_vB12,
            param_nomeComidaEncontrada
        FROM Comida
        WHERE food_name = var_verificarComida;
    END IF;
END%
CREATE PROCEDURE AdicionarComida(IN param_senha VARCHAR(60),IN param_nomeComida VARCHAR(100),IN param_cal FLOAT,IN param_carboidrato FLOAT,IN param_proteina FLOAT,IN param_gorduraBoa FLOAT,IN param_fibra FLOAT,IN param_calcio FLOAT,IN param_fosforo FLOAT,IN param_magnesio FLOAT,IN param_ferro FLOAT,IN param_potassio FLOAT,IN param_sodio FLOAT,IN param_zinco FLOAT,IN param_selenio FLOAT,IN param_cobre FLOAT,IN param_vA FLOAT,IN param_vC FLOAT,IN param_vD FLOAT,IN param_vE FLOAT,IN param_vK FLOAT,IN param_vB1 FLOAT,IN param_vB2 FLOAT,IN param_vB3 FLOAT,IN param_VB5 FLOAT,IN param_vB6 FLOAT,IN param_vB7 FLOAT,IN param_vB9 FLOAT,IN param_vB12 FLOAT) 
BEGIN
    DECLARE var_qtde INT DEFAULT 0;
    DECLARE var_verificarComida INT DEFAULT 0;
    SELECT Count(food_name) INTO var_verificarComida FROM Comida WHERE food_name = param_nome;
    SELECT Count(Senhas) INTO var_qtde FROM SenhaDeAcesso WHERE Senhas = param_senha;
    IF (param_nome REGEXP '^[A-Za-z ]+$') THEN
        IF (LEAST(param_cal,param_carboidrato,param_proteina,param_gorduraBoa,param_fibra,param_calcio,param_fosforo,param_magnesio,param_ferro,param_potassio,param_sodio,param_zinco,param_selenio,param_cobre,param_vA,param_vC,param_vD,param_vE,param_vK,param_vB1,param_vB2,param_vB3,param_VB5,param_vB6,param_vB7,param_vB9,param_vB12)>=0 AND var_verificarComida <= 0) THEN
            IF (var_qtde > 0) THEN
                INSERT INTO Comida(nome,caloria, carboidrato, proteina, gordura_boa, fibra, calcio, fosforo, magnesio, ferro, potassio, sodio, zinco, selenio, cobre, vA, vC, vD, vE, vK, vB1, vB2, vB3, vB5, vB6, vB7, vB9, vB12) VALUE (param_nomeComida,param_cal,param_carboidrato,param_proteina,param_gorduraBoa,param_fibra,param_calcio,param_fosforo,param_magnesio,param_ferro,param_potassio,param_sodio,param_zinco,param_selenio,param_cobre,param_vA,param_vC,param_vD,param_vE,param_vK,param_vB1,param_vB2,param_vB3,param_VB5,param_vB6,param_vB7,param_vB9,param_vB12);
                SELECT 'Comida adicionada ao Banco de Dados' AS RESULTADO;
            ELSE
                SELECT 'Senha invalido' AS RESULTADO;
            END IF;
        ELSE
            SELECT 'Valor invalido' AS RESULTADO;
        END IF;
    ELSE
        SELECT 'Erro ao nomear' AS RESULTADO;
    END IF;
END%
CREATE PROCEDURE CriarTabela_Comida(IN param_tableID INT,IN param_qtdeComida INT,IN param_nomeComida VARCHAR(100))
BEGIN
    DECLARE var_verificarComida INT DEFAULT 0;
    DECLARE var_ComidaID INT DEFAULT 0;

    SELECT COUNT(food_name) INTO var_verificarComida FROM Comida WHERE food_name = param_nomeComida;

    IF (var_verificarComida > 0) THEN
        SELECT id INTO var_ComidaID FROM Comida WHERE food_name = param_nomeComida;
        IF (param_tableID > 0) THEN
            IF (param_qtdeComida > 0) THEN
                INSERT INTO Tabela_Comida(id_Tabela_Cronograma,id_Comida,qtde_Comida) VALUE (param_tableID,var_ComidaID,param_qtdeComida);
            ELSE
                SELECT 'Quantidade Invalida' AS RESULTADO;
            END IF;
        ELSE
            SELECT 'ID invalido' AS RESULTADO;
        END IF;
    ELSE
        SELECT 'Nome invalido' AS RESULTADO;
    END IF;
END%
CREATE PROCEDURE ExcluirTabela_Comida(IN param_tableID INT,IN param_ComidaID INT)
BEGIN
    IF (param_tableID > 0 AND param_ComidaID > 0 AND param_qtdeComida) THEN
        DELETE FROM Tabela_Comida WHERE id_Tabela_Cronograma = param_tableID AND id_Comida = param_ComidaID;
    ELSE
        SELECT 'ID invalido' AS RESULTADO;
    END IF;
END%
CREATE PROCEDURE AlterarTabela_Comida(IN param_tableID INT,IN param_qtdeComida INT,IN param_nomeComida VARCHAR(100),IN param_IsAdding BOOLEAN)
BEGIN
    DECLARE var_verificarComida INT DEFAULT 0;
    DECLARE var_ComidaID INT DEFAULT 0;
	
    SELECT COUNT(food_name) INTO var_verificarComida FROM Comida WHERE food_name = param_nomeComida;
    
    IF (var_verificarComida > 0) THEN
        SELECT id INTO var_ComidaID FROM Comida WHERE food_name = param_nomeComida;
        IF (param_tableID > 0) THEN
            IF (param_qtdeComida > 0) THEN
                IF (param_IsAdding = 1) THEN
                    INSERT INTO Tabela_Comida(id_Tabela_Cronograma,id_Comida,qtde_Comida) VALUE (param_tableID,var_ComidaID,param_qtdeComida);
                ELSE
                    DELETE FROM Tabela_Comida WHERE id_Tabela_Cronograma = param_tableID AND id_Comida = var_ComidaID AND qtde_Comida = param_qtdeComida;
                END IF;
            ELSE
                SELECT 'Quantidade Invalida' AS RESULTADO;
            END IF;
        ELSE
            SELECT 'ID invalido' AS RESULTADO;
        END IF;
    ELSE
        SELECT 'Nome invalido' AS RESULTADO;
    END IF;
END%
CREATE PROCEDURE RegistrarQtdeNutrientesCompleta (IN param_idUsuario INT)
BEGIN
    DECLARE var_idade INT;
    DECLARE var_sexo CHAR(1);
    DECLARE var_gravidez BOOLEAN DEFAULT FALSE;
    DECLARE var_lactacao BOOLEAN DEFAULT FALSE;
    DECLARE var_doenca VARCHAR(100);
    DECLARE var_deficiencia VARCHAR(100);
    DECLARE var_evento VARCHAR(100);

    SELECT idade, sexo, gravidez, lactacao, doenca, deficiencia, evento_agudo
    INTO var_idade, var_sexo, var_gravidez, var_lactacao, var_doenca, var_deficiencia, var_evento
    FROM Pessoa WHERE id = param_idUsuario;

    DELETE FROM qtde_Nutrientes WHERE id_Usuario = param_idUsuario;

    INSERT INTO qtde_Nutrientes VALUES (
        param_idUsuario,
        CASE
            WHEN var_evento = 'queimadura' THEN 3500
            WHEN var_evento = 'cirurgia' THEN 3000
            WHEN var_idade < 1 THEN 1000
            WHEN var_idade BETWEEN 1 AND 3 THEN 1300
            WHEN var_idade BETWEEN 4 AND 8 THEN 1800
            WHEN var_idade BETWEEN 9 AND 13 THEN CASE WHEN var_sexo='M' THEN 2200 ELSE 2000 END
            WHEN var_idade BETWEEN 14 AND 18 THEN CASE WHEN var_sexo='M' THEN 2800 ELSE 2200 END
            WHEN var_idade BETWEEN 19 AND 30 THEN CASE WHEN var_sexo='M' THEN 2600 ELSE 2000 END
            WHEN var_idade BETWEEN 31 AND 50 THEN CASE WHEN var_sexo='M' THEN 2400 ELSE 1800 END
            WHEN var_idade > 50 THEN CASE WHEN var_sexo='M' THEN 2200 ELSE 1600 END
            ELSE 2000
        END,
        CASE
            WHEN var_deficiencia = 'diabetes' THEN 130
            WHEN var_evento = 'queimadura' THEN 400
            ELSE 275
        END,
        CASE
            WHEN var_evento = 'queimadura' THEN 150
            WHEN var_evento = 'cirurgia' THEN 120
            WHEN var_deficiencia = 'proteina' THEN 100
            WHEN var_idade < 1 THEN 13
            WHEN var_idade BETWEEN 1 AND 3 THEN 16
            WHEN var_idade BETWEEN 4 AND 8 THEN 19
            WHEN var_idade BETWEEN 9 AND 13 THEN 34
            WHEN var_idade BETWEEN 14 AND 18 THEN CASE WHEN var_sexo='M' THEN 52 ELSE 46 END
            WHEN var_idade BETWEEN 19 AND 50 THEN CASE WHEN var_sexo='M' THEN 56 ELSE 46 END
            WHEN var_idade > 50 THEN CASE WHEN var_sexo='M' THEN 56 ELSE 46 END
            ELSE 56
        END,
        CASE
            WHEN var_doenca = 'cardiopatia' THEN 50
            WHEN var_evento = 'queimadura' THEN 80
            ELSE 70
        END,
        CASE
            WHEN var_idade < 1 THEN 10
            WHEN var_idade BETWEEN 1 AND 3 THEN 19
            WHEN var_idade BETWEEN 4 AND 8 THEN 25
            WHEN var_idade BETWEEN 9 AND 13 THEN 31
            WHEN var_idade BETWEEN 14 AND 18 THEN CASE WHEN var_sexo='M' THEN 38 ELSE 26 END
            ELSE 30
        END,
        CASE
            WHEN var_gravidez THEN 1300
            WHEN var_lactacao THEN 1300
            WHEN var_idade < 1 THEN 260
            WHEN var_idade BETWEEN 1 AND 3 THEN 700
            WHEN var_idade BETWEEN 4 AND 8 THEN 1000
            WHEN var_idade BETWEEN 9 AND 18 THEN 1300
            WHEN var_idade > 50 THEN 1200
            ELSE 1000
        END,
        CASE
            WHEN var_idade < 1 THEN 275
            WHEN var_idade BETWEEN 1 AND 3 THEN 460
            WHEN var_idade BETWEEN 4 AND 8 THEN 500
            WHEN var_idade BETWEEN 9 AND 18 THEN 1250
            ELSE 700
        END,
        CASE
            WHEN var_idade < 1 THEN 30
            WHEN var_idade BETWEEN 1 AND 3 THEN 80
            WHEN var_idade BETWEEN 4 AND 8 THEN 130
            WHEN var_idade BETWEEN 9 AND 13 THEN 240
            WHEN var_idade BETWEEN 14 AND 18 THEN CASE WHEN var_sexo='M' THEN 410 ELSE 360 END
            ELSE 400
        END,
        CASE
            WHEN var_gravidez THEN 27
            WHEN var_lactacao THEN 9
            WHEN var_deficiencia = 'ferro' THEN 30
            WHEN var_idade < 1 THEN 11
            WHEN var_idade BETWEEN 1 AND 3 THEN 7
            WHEN var_idade BETWEEN 4 AND 8 THEN 10
            WHEN var_idade BETWEEN 9 AND 13 THEN 8
            WHEN var_idade BETWEEN 14 AND 18 THEN CASE WHEN var_sexo='M' THEN 11 ELSE 15 END
            WHEN var_idade > 18 THEN CASE WHEN var_sexo='M' THEN 8 ELSE 18 END
            ELSE 8
        END,
        CASE
            WHEN var_idade < 1 THEN 700
            WHEN var_idade BETWEEN 1 AND 3 THEN 3000
            WHEN var_idade BETWEEN 4 AND 8 THEN 3800
            WHEN var_idade >= 9 THEN 4700
            ELSE 4700
        END,
        CASE
            WHEN var_doenca = 'hipertensao' THEN 1500
            WHEN var_idade < 1 THEN 1100
            ELSE 2300
        END,
        CASE
            WHEN var_gravidez THEN 12
            WHEN var_lactacao THEN 13
            WHEN var_idade < 1 THEN 2
            WHEN var_idade BETWEEN 1 AND 3 THEN 3
            WHEN var_idade BETWEEN 4 AND 8 THEN 5
            WHEN var_idade BETWEEN 9 AND 13 THEN 8
            ELSE 11
        END,
        CASE
            WHEN var_idade < 1 THEN 20
            WHEN var_idade BETWEEN 1 AND 3 THEN 30
            WHEN var_idade BETWEEN 4 AND 8 THEN 40
            ELSE 55
        END,
        CASE
            WHEN var_idade < 1 THEN 0.2
            WHEN var_idade BETWEEN 1 AND 3 THEN 0.44
            WHEN var_idade BETWEEN 4 AND 8 THEN 0.7
            ELSE 0.9
        END,
        CASE
            WHEN var_gravidez THEN 770
            WHEN var_lactacao THEN 1300
            WHEN var_idade < 1 THEN 400
            WHEN var_idade BETWEEN 1 AND 3 THEN 300
            WHEN var_idade BETWEEN 4 AND 8 THEN 400
            WHEN var_idade BETWEEN 9 AND 13 THEN 600
            ELSE CASE WHEN var_sexo='M' THEN 900 ELSE 700 END
        END,
        CASE
            WHEN var_gravidez THEN 85
            WHEN var_lactacao THEN 120
            WHEN var_idade < 1 THEN 40
            WHEN var_idade BETWEEN 1 AND 3 THEN 15
            WHEN var_idade BETWEEN 4 AND 8 THEN 25
            WHEN var_idade BETWEEN 9 AND 13 THEN 45
            ELSE 90
        END,
        CASE
            WHEN var_idade < 1 THEN 400
            WHEN var_idade BETWEEN 1 AND 70 THEN 600
            ELSE 800
        END,
        CASE
            WHEN var_idade < 1 THEN 4
            WHEN var_idade BETWEEN 1 AND 3 THEN 6
            ELSE 15
        END,
        CASE
            WHEN var_idade < 1 THEN 2
            WHEN var_idade BETWEEN 1 AND 3 THEN 30
            ELSE 120
        END,
        CASE
            WHEN var_idade < 1 THEN 0.2
            WHEN var_idade BETWEEN 1 AND 3 THEN 0.5
            ELSE CASE WHEN var_sexo='M' THEN 1.2 ELSE 1.1 END
        END,
        CASE
            WHEN var_idade < 1 THEN 0.3
            WHEN var_idade BETWEEN 1 AND 3 THEN 0.5
            ELSE CASE WHEN var_sexo='M' THEN 1.3 ELSE 1.1 END
        END,
        CASE
            WHEN var_idade < 1 THEN 4
            WHEN var_idade BETWEEN 1 AND 3 THEN 6
            ELSE CASE WHEN var_sexo='M' THEN 16 ELSE 14 END
        END,
        CASE
            WHEN var_idade < 1 THEN 1.7
            WHEN var_idade BETWEEN 1 AND 3 THEN 2
            ELSE 5
        END,
        CASE
            WHEN var_gravidez THEN 1.9
            WHEN var_lactacao THEN 2
            WHEN var_idade < 1 THEN 0.3
            WHEN var_idade BETWEEN 1 AND 3 THEN 0.5
            ELSE CASE WHEN var_sexo='M' THEN 1.3 ELSE 1.2 END
        END,
        CASE
            WHEN var_idade < 1 THEN 5
            WHEN var_idade BETWEEN 1 AND 3 THEN 8
            ELSE 30
        END,
        CASE
            WHEN var_gravidez THEN 600
            WHEN var_lactacao THEN 500
            WHEN var_idade < 1 THEN 65
            WHEN var_idade BETWEEN 1 AND 3 THEN 150
            ELSE 400
        END,
        CASE
            WHEN var_gravidez THEN 2.6
            WHEN var_lactacao THEN 2.8
            WHEN var_idade < 1 THEN 0.4
            WHEN var_idade BETWEEN 1 AND 3 THEN 0.9
            ELSE 2.4
        END
    );
END%
CREATE PROCEDURE RegistrarQtdeNutrientesEditable(IN param_IsEditing BOOLEAN,IN param_TableID INT,IN param_UsuarioID INT,IN param_TableName VARCHAR(100),IN param_cal FLOAT,IN param_carboidrato FLOAT,IN param_proteina FLOAT,IN param_gorduraBoa FLOAT,IN param_fibra FLOAT,IN param_calcio FLOAT,IN param_fosforo FLOAT,IN param_magnesio FLOAT,IN param_ferro FLOAT,IN param_potassio FLOAT,IN param_sodio FLOAT,IN param_zinco FLOAT,IN param_selenio FLOAT,IN param_cobre FLOAT,IN param_vA FLOAT,IN param_vC FLOAT,IN param_vD FLOAT,IN param_vE FLOAT,IN param_vK FLOAT,IN param_vB1 FLOAT,IN param_vB2 FLOAT,IN param_vB3 FLOAT,IN param_VB5 FLOAT,IN param_vB6 FLOAT,IN param_vB7 FLOAT,IN param_vB9 FLOAT,IN param_vB12 FLOAT) 
BEGIN
    DECLARE var_qtde INT DEFAULT 0;
    DECLARE var_VerificarNome INT DEFAULT 0;
    SELECT COUNT(id_Usuario) INTO var_qtde FROM Usuario WHERE id_Usuario = param_UsuarioID;
    SELECT COUNT(table_name) INTO var_VerificarNome FROM qtde_NutrientesEditable WHERE table_name = param_TableName AND id_Usuario = param_UsuarioID;
    IF (LEAST(param_cal,param_carboidrato,param_proteina,param_gorduraBoa,param_fibra,param_calcio,param_fosforo,param_magnesio,param_ferro,param_potassio,param_sodio,param_zinco,param_selenio,param_cobre,param_vA,param_vC,param_vD,param_vE,param_vK,param_vB1,param_vB2,param_vB3,param_VB5,param_vB6,param_vB7,param_vB9,param_vB12)>=0) THEN
        IF (var_VerificarNome = 0 AND param_TableName REGEXP '^[A-Za-z0-9 ]+$') THEN
            IF (var_qtde > 0) THEN
                IF (param_IsEditing = 0) THEN
                    INSERT INTO qtde_NutrientesEditable(id_Usuario,caloria,table_name, carboidrato, proteina, gordura_boa, fibra, calcio, fosforo, magnesio, ferro, potassio, sodio, zinco, selenio, cobre, vA, vC, vD, vE, vK, vB1, vB2, vB3, vB5, vB6, vB7, vB9, vB12) VALUE (param_UsuarioID,param_cal,param_TableName,param_carboidrato,param_proteina,param_gorduraBoa,param_fibra,param_calcio,param_fosforo,param_magnesio,param_ferro,param_potassio,param_sodio,param_zinco,param_selenio,param_cobre,param_vA,param_vC,param_vD,param_vE,param_vK,param_vB1,param_vB2,param_vB3,param_VB5,param_vB6,param_vB7,param_vB9,param_vB12);
                    SELECT 'Tabela adicionada ao Banco de Dados' AS RESULTADO;
                ELSE
                    IF (param_TableID > 0) THEN
                        DELETE FROM qtde_NutrientesEditable WHERE id_Usuario = param_UsuarioID AND id = param_TableID;
                        INSERT INTO qtde_NutrientesEditable(id_Usuario,caloria,table_name, carboidrato, proteina, gordura_boa, fibra, calcio, fosforo, magnesio, ferro, potassio, sodio, zinco, selenio, cobre, vA, vC, vD, vE, vK, vB1, vB2, vB3, vB5, vB6, vB7, vB9, vB12) VALUE (param_UsuarioID,param_cal,param_carboidrato,param_proteina,param_gorduraBoa,param_fibra,param_calcio,param_fosforo,param_magnesio,param_ferro,param_potassio,param_sodio,param_zinco,param_selenio,param_cobre,param_vA,param_vC,param_vD,param_vE,param_vK,param_vB1,param_vB2,param_vB3,param_VB5,param_vB6,param_vB7,param_vB9,param_vB12);
                        SELECT 'Tabela editada' AS RESULTADO;
                    ELSE
                        SELECT 'Erro ao passar parametro do ID da Tabela' AS RESULTADO;
                    END IF;
                END IF;
            ELSE
                SELECT 'Usuario invalido' AS RESULTADO;
            END IF;
        ELSE
            SELECT 'Erro ao passar parametro do nome da tabela' AS RESULTADO;
		END IF;
    ELSE
        SELECT 'Valor invalido' AS RESULTADO;
    END IF;
END%
CREATE PROCEDURE ExcluirQtdeNutrientesEditable(IN param_UsuarioID INT,IN param_TableName VARCHAR(100))
BEGIN
    DECLARE var_VerificarParametros INT DEFAULT 0;
    SELECT COUNT(*) INTO var_VerificarParametros FROM qtde_NutrientesEditable WHERE id_Usuario = param_UsuarioID AND table_name = param_TableName;
    IF (var_VerificarParametros > 0) THEN
        DELETE FROM qtde_NutrientesEditable WHERE id_Usuario = param_UsuarioID AND table_name = param_TableName;
    ELSE
        SELECT 'Valor não encontrado' AS RESULTADO;
    END IF;
END%
DELIMITER ;