CREATE OR REPLACE VIEW Show_Usuario AS
SELECT 
	ID,
    NAME AS NOME,
    AGE AS IDADE,
    EMAIL,
    SENHA
FROM
	USUARIO;

CREATE OR REPLACE VIEW Show_Cronograma AS
SELECT 
    ID,
    ID_Usuario,
    Table_Name AS NOME_TABELA,
    Date AS DATA
FROM
    CRONOGRAMA;

CREATE OR REPLACE VIEW Show_Tabela AS
SELECT 
    ID,
    ID_Cronograma,
    Day_Time AS HORARIO
FROM
    Tabela;

CREATE OR REPLACE VIEW Show_Tabela_Comida AS
SELECT 
    ID_Tabela,
    ID_Comida,
    Gramas
FROM
    Tabela_Comida;

CREATE OR REPLACE VIEW Show_Comida AS
SELECT 
    ID,
    Name AS NOME
FROM
    Comida;

CREATE OR REPLACE VIEW Show_Informacoes_Usuario AS
SELECT 
    ID_Usuario,
    Idade AS IDADE,
    Sexo,
    Peso_Kg AS PESO_KG,
    Data_cadastro AS DATA_CADASTRO
FROM
    InformacoesPessoais;

CREATE OR REPLACE VIEW Show_Usuario_Editable_Tables AS
SELECT 
    ID_Usuario,
    ID_QTDE_NUTRIENTES,
    Selected
FROM
    UsuarioEditableTables;

CREATE OR REPLACE VIEW SHOW_QTDE_NUTRIENTES AS
SELECT 
    ID,
    QTDE_KCAL  AS cal,
    QTDE_CARBOIDRATO AS carboidrato,
    QTDE_PROTEINA AS proteina,
    QTDE_gordura_boa AS gorduraBoa,
    QTDE_fibra AS fibra,
    QTDE_calcio AS calcio,
    QTDE_fosforo AS fosforo,
    QTDE_magnesio AS magnesio,
    QTDE_ferro AS ferro,
    QTDE_potassio AS potassio,
    QTDE_sodio AS sodio,
    QTDE_zinco AS zinco,
    QTDE_selenio AS selenio,
    QTDE_cobre AS cobre,
    QTDE_vA AS vA,
    QTDE_vC AS vC,
    QTDE_vD AS vD,
    QTDE_vE AS vE,
    QTDE_vK AS vK,
    QTDE_vB1 AS vB1,
    QTDE_vB2 AS vB2,
    QTDE_vB3 AS vB3,
    QTDE_vB5 AS VB5,
    QTDE_vB6 AS vB6,
    QTDE_vB7 AS vB7,
    QTDE_vB9 AS vB9,
    QTDE_vB12 AS vB12
FROM
    QTDE_NUTRIENTES;