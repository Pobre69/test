CREATE OR REPLACE VIEW Show_Usuario AS
SELECT 
	ID,
    NAME AS NOME,
    AGE AS IDADE,
    EMAIL,
    SENHA
FROM
	USUARIO;

CREATE OR REPLACE VIEW Show_Cronograma AS
SELECT 
    ID,
    ID_Usuario,
    Table_Name AS NOME_TABELA,
    Date AS DATA
FROM
    CRONOGRAMA;

CREATE OR REPLACE VIEW Show_Tabela AS
SELECT 
    ID,
    ID_Cronograma,
    Day_Time AS HORARIO
FROM
    Tabela;

CREATE OR REPLACE VIEW Show_Tabela_Comida AS
SELECT 
    ID_Tabela,
    ID_Comida,
    Gramas
FROM
    Tabela_Comida;

CREATE OR REPLACE VIEW Show_Comida AS
SELECT 
    ID,
    Name AS NOME
FROM
    Comida;

CREATE OR REPLACE VIEW Show_Informacoes_Usuario AS
SELECT 
    ID_Usuario,
    Idade AS IDADE,
    Sexo,
    Peso_Kg AS PESO_KG,
    Data_cadastro AS DATA_CADASTRO
FROM
    InformacoesPessoais;

CREATE OR REPLACE VIEW Show_Usuario_Editable_Tables AS
SELECT 
    ID_Usuario,
    ID_QTDE_NUTRIENTES,
    Selected
FROM
    UsuarioEditableTables;