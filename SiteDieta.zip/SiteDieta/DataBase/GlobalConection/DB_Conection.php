<?php

namespace DataBase\DB_Global_Conection;

use PDO;
use PDOException;

class DB_Conection {

    private static ?PDO $conn = null;
    private static string $host;
    private static string $usuario;
    private static string $senha;
    private static string $banco;

    public function __construct(string $host, string $usuario, string $senha, string $banco) {
        self::$host = $host;
        self::$usuario = $usuario;
        self::$senha = $senha;
        self::$banco = $banco;

    }

    public static function getConnection(): PDO {
        if (self::$conn === null) {
            try {
                $host = self::$host;
                $usuario = self::$usuario;
                $senha = self::$senha;
                $banco = self::$banco;

                $tempConn = new PDO("mysql:host=$host", $usuario, $senha);
                $tempConn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                $dsn = "mysql:host=$host;dbname=$banco;charset=utf8mb4";
                self::$conn = new PDO($dsn, $usuario, $senha, [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false
                ]);
            } catch (PDOException $e) {
                error_log("Erro na conexão com o banco: " . $e->getMessage());
                throw new \RuntimeException("Erro na conexão com o banco de dados. Verifique se o MySQL está rodando e as credenciais estão corretas.");
            }
        }

        return self::$conn;
    }
    public static function Start_DataBase(array $Routes): void{
        $host = self::$host;
        $usuario = self::$usuario;
        $senha = self::$senha;
        $banco = self::$banco;

        $tempConn = new PDO("mysql:host=$host", $usuario, $senha);
        $tempConn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $dbExists = $tempConn->query("SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '$banco'")->fetchColumn();
        
        if (!$dbExists) {
            $tempConn->exec("CREATE DATABASE IF NOT EXISTS $banco CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            $tempConn->exec("USE $banco");
            
            foreach ($Routes as $file) {
                if (file_exists($file)) {
                    $sql = file_get_contents($file);
                    $tempConn->exec($sql);
                }
            }
        }
    }
}
