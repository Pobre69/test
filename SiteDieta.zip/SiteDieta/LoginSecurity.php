<?php
    if(!isset($_SESSION)) {
        session_set_cookie_params([
            'lifetime' => 60 * 60 * 24 * 7, // 7 dias
            'path' => '/',
            'domain' => $_SERVER['HTTP_HOST'],
            'secure' => isset($_SERVER['HTTPS']), // true se HTTPS
            'httponly' => true, // mais seguro
            'samesite' => 'Lax'
        ]); 
        session_start();
    }

    $isLogado = false;
    $ID_Usuario = 0;

    if(isset($_SESSION['id']) && $_SESSION['id'] > 0) {
        include_once 'BDconection.php';
        global $conn;
        $valor = $_SESSION['id'];
        $stmt = $conn->query("SELECT IFNULL(Usuario_ID,0) AS ID FROM Usuario_Show WHERE Usuario_ID = '{$valor}'");
        $id = $stmt->fetch(PDO::FETCH_ASSOC);
        $Verificar = $id['ID'];
        if($Verificar > 0){
            $ID_Usuario = $_SESSION['id'];
            $isLogado = true;
        } else{
            session_destroy();
            header("Location: index.html");
            exit;
        }
    }
?>