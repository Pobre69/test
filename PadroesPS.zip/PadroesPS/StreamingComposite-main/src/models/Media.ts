export abstract class Media {
  constructor(public id: string, public title: string, public year: number) {}

  abstract getType(): 'filme' | 'serie';
}
