import { Media } from './Media';

export class Filme extends Media {
  constructor(id: string, title: string, year: number, public director?: string) {
    super(id, title, year);
  }

  getType(): 'filme' | 'serie' {
    return 'filme';
  }
}
