import { Media } from './Media';

export class Serie extends Media {
  constructor(id: string, title: string, year: number, public seasons: number = 1) {
    super(id, title, year);
  }

  getType(): 'filme' | 'serie' {
    return 'serie';
  }
}
