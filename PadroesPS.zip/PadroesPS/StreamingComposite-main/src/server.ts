import express, { Request, Response } from 'express';
import { Search } from './search/Search';
import { SearchFilterAdapter } from './filters/SearchFilterAdapter';
import { FilterGeneroDecorator } from './filters/FilterGeneroDecorator';
import { FilterAnoDecorator } from './filters/FilterAnoDecorator';
import { IFilter } from './filters/IFilter';
import { Media } from './models/Media';

const app = express();
const port = process.env.PORT ? Number(process.env.PORT) : 3000;

// Serve static frontend
app.use(express.static('public'));

app.get('/search', async (req: Request, res: Response) => {
  const q = String(req.query.q || '').trim();
  const genero = (req.query.genero as string) as 'filme' | 'serie' | undefined;
  const minYear = req.query.minYear ? Number(req.query.minYear) : undefined;

  try {
    const base = new Search();
    // wrap Search as an IFilter so decorators can be composed
    let filter: IFilter = new SearchFilterAdapter(base);

    // apply genero filter if present
    if (genero === 'filme' || genero === 'serie') {
      filter = new FilterGeneroDecorator(filter, genero);
    }
    // apply year filter if present
    if (typeof minYear === 'number' && !isNaN(minYear)) {
      filter = new FilterAnoDecorator(filter, minYear);
    }

    const results = await filter.execute(q);
    res.json((results as Media[]).map((r: Media) => ({ id: r.id, title: r.title, year: r.year, type: r.getType() })));
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'internal_error' });
  }
});

app.listen(port, () => {
  console.log(`Server listening on http://localhost:${port}`);
});
