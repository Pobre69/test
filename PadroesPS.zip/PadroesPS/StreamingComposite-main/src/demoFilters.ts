import { Search } from './search/Search';
import { FilterGeneroDecorator } from './filters/FilterGeneroDecorator';
import { FilterAnoDecorator } from './filters/FilterAnoDecorator';
import { SearchFilterAdapter } from './filters/SearchFilterAdapter';

async function demo() {
  const baseSearch = new Search();
  const base = new SearchFilterAdapter(baseSearch);
  // apply decorator: first filter by genero 'filme', then by year >= 2000
  const filmesRecentes = new FilterAnoDecorator(new FilterGeneroDecorator(base, 'filme'), 2000);

  const results = await filmesRecentes.execute('batman');
  console.log(`Filtered results (filme, year >= 2000): ${results.length}`);
  for (const r of results) {
    console.log(`- [${r.getType()}] ${r.title} (${r.year})`);
  }
}

demo().catch((e) => {
  console.error(e);
  process.exit(1);
});
