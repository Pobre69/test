import { ISearch } from './ISearch';
import { Serie } from '../models/Serie';
import { Media } from '../models/Media';

const SERIES: Serie[] = [
  new Serie('s1', 'Stranger Things', 2016, 4),
  new Serie('s4', 'Batman: The Animated Series', 1992, 1),
  new Serie('s5', 'Gotham', 2014, 5),
  new Serie('s2', 'Breaking Bad', 2008, 5),
  new Serie('s3', 'The Crown', 2016, 5)
];

export class SearchSerie implements ISearch {
  async search(query: string): Promise<Media[]> {
    // Simulate async call
    await new Promise((r) => setTimeout(r, 200));
    const q = query.trim().toLowerCase();
    if (!q) return [];
    return SERIES.filter((s) => s.title.toLowerCase().includes(q));
  }
}
