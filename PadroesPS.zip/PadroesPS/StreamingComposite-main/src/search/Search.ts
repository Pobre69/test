import { ISearch } from './ISearch';
import { SearchMovie } from './SearchMovie';
import { SearchSerie } from './SearchSerie';
import { Media } from '../models/Media';

export class Search {
  private components: ISearch[] = [];

  constructor() {
    // composite contains both concrete searches
    this.components.push(new SearchMovie());
    this.components.push(new SearchSerie());
  }

  async search(query: string): Promise<Media[]> {
    // run all component searches in parallel and flatten results
    const promises = this.components.map((c) => c.search(query));
    const results = await Promise.all(promises);
    // flatten and return
    return results.flat();
  }
}
