import { ISearch } from './ISearch';
import { Filme } from '../models/Filme';
import { Media } from '../models/Media';

const MOVIES: Filme[] = [
  new Filme('m1', 'The Matrix', 1999, 'Wachowski'),
  new Filme('m4', 'Batman', 1989, 'Tim Burton'),
  new Filme('m5', 'Batman Begins', 2005, 'Christopher Nolan'),
  new Filme('m6', 'The Dark Knight', 2008, 'Christopher Nolan'),
  new Filme('m2', 'Inception', 2010, 'Christopher Nolan'),
  new Filme('m3', 'Interstellar', 2014, 'Christopher Nolan')
];

export class SearchMovie implements ISearch {
  async search(query: string): Promise<Media[]> {
    // Simulate async call
    await new Promise((r) => setTimeout(r, 150));
    const q = query.trim().toLowerCase();
    if (!q) return [];
    return MOVIES.filter((m) => m.title.toLowerCase().includes(q));
  }
}
