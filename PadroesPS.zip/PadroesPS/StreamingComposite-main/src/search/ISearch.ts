import { Media } from '../models/Media';

export interface ISearch {
  search(query: string): Promise<Media[]>;
}
