import { IFilter } from './IFilter';
import { ISearch } from '../search/ISearch';
import { Media } from '../models/Media';

export class SearchFilterAdapter implements IFilter {
  constructor(private searchImpl: ISearch) {}

  execute(query: string): Promise<Media[]> {
    return this.searchImpl.search(query);
  }
}
