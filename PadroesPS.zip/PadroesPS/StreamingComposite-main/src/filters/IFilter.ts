import { Media } from '../models/Media';

export interface IFilter {
  execute(query: string): Promise<Media[]>;
}
