import { FilterDecorator } from './FilterDecorator';
import { IFilter } from './IFilter';
import { Media } from '../models/Media';

export class FilterAnoDecorator extends FilterDecorator implements IFilter {
  constructor(inner: IFilter, private minYear: number) {
    super(inner);
  }

  async execute(query: string): Promise<Media[]> {
    const results = await this.inner.execute(query);
    return results.filter((r) => r.year >= this.minYear);
  }
}
