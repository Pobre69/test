import { ISearch } from '../search/ISearch';
import { Media } from '../models/Media';

// Marker interface for search decorators. It extends ISearch so decorators
// can be used anywhere an ISearch is expected.
export interface IFilterDecorator extends ISearch {
  // No extra members required — decorators just implement search(query)
}
