import { FilterDecorator } from './FilterDecorator';
import { IFilter } from './IFilter';
import { Media } from '../models/Media';

export class FilterGeneroDecorator extends FilterDecorator implements IFilter {
  constructor(inner: IFilter, private genero: 'filme' | 'serie') {
    super(inner);
  }

  async execute(query: string): Promise<Media[]> {
    const results = await this.inner.execute(query);
    return results.filter((r) => r.getType() === this.genero);
  }
}
