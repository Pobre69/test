import { IFilter } from './IFilter';
import { Media } from '../models/Media';

export abstract class FilterDecorator implements IFilter {
  constructor(protected inner: IFilter) {}

  abstract execute(query: string): Promise<Media[]>;
}
