import { Search } from './search/Search';

async function main() {
  const search = new Search();
  const query = process.argv.slice(2).join(' ') || 'inception';
  console.log(`Searching for: "${query}"`);
  const results = await search.search(query);
  console.log(`Found ${results.length} results:`);
  for (const r of results) {
    console.log(`- [${(r as any).getType()}] ${r.title} (${r.year})`);
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
