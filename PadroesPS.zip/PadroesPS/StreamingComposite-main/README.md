Streaming Composite
===================

Exemplo do padrão Composite/Decorator para streaming de Filmes e Séries. Projeto contém:

- Backend (TypeScript): buscas mock em `src/search` com composição (Composite) e filtros (Decorator).
- Frontend: SPA leve em `public/` que consome a API `/search`.

Como rodar

1. Instalar dependências:

```bash
npm install
```

2. Rodar em modo dev (recomendado):

```bash
npm run dev:server
```

3. Abrir no navegador:

```
http://localhost:3000
```

API

- GET /search?q=&genero=&minYear=

Exemplo:

```
http://localhost:3000/search?q=batman&genero=filme&minYear=2000
```

Scripts úteis

- `npm run start:server` — compila e executa o servidor Express (produção)
- `npm run dev:server` — roda o servidor em modo dev com restart automático
- `npm run serve:web` — serve os arquivos estáticos (caso precise)
