const express = require('express');
const http = require('http');
const path = require('path');
const cors = require('cors');
const { Server } = require('socket.io');

const WeatherStation = require('./src/weatherStation');
const ControlPanel = require('./src/observers/controlPanel');
const MobileNotifier = require('./src/observers/mobileNotifier');
const AlarmSystem = require('./src/observers/alarmSystem');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const server = http.createServer(app);
const io = new Server(server);

// create weather station and observers
const station = new WeatherStation();

// Observer instances
const controlPanel = new ControlPanel(io);
const mobileNotifier = new MobileNotifier(io);
const alarmSystem = new AlarmSystem(io, { tempThreshold: 30 });

station.addObserver(controlPanel);
station.addObserver(mobileNotifier);
station.addObserver(alarmSystem);

// endpoint to set values (simulates Arduino sending sensor readings)
app.post('/api/set-values', (req, res) => {
  const values = req.body;
  try {
    station.setValues(values);
    res.json({ ok: true });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

io.on('connection', (socket) => {
  console.log('client connected', socket.id);
  // send initial state if available
  // send entire history to the newly connected client
  if (station.history && station.history.length) {
    socket.emit('history', station.history);
  }
});

// endpoint to get all history
app.get('/api/history', (req, res) => {
  res.json({ history: station.history || [] });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
