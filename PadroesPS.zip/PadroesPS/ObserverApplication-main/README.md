# Observer Pattern Demo

Aplicação simples demonstrando o padrão Observer.

Estrutura:
- Backend: Node + Express + Socket.IO
- Frontend: uma página estática em `public/index.html`

Como funciona:
- Temos uma interface conceitual Observer (cada observador implementa `update(values)`).
- `WeatherStation` mantém uma lista de observers e possui `setValues(values)` que notifica todos os observers.
- Observers implementados: `ControlPanel`, `MobileNotifier`, `AlarmSystem`.

Rodar:

1. Instalar dependências:

```bash
npm install
```

2. Iniciar:

```bash
npm start
```

3. Abrir `http://localhost:3000` para ver o painel e simular valores.

API:
- POST /api/set-values { temperature, luminosity, humidity }

Requisitos mapeados:
- Interface Observer com método update(values): implementado por classes de observadores.
- WeatherStation com lista de observers, addObserver e setValues que chama update em cada: implementado em `src/weatherStation.js`.
- Alarm dispara quando temperatura > 30°C: padrão default de 30°C em `src/observers/alarmSystem.js`.
