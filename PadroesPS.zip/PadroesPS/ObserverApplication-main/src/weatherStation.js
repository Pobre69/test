class WeatherStation {
  constructor() {
    this.observers = [];
    this.latest = null;
    this.history = [];
  }

  addObserver(observer) {
    if (!observer || typeof observer.update !== 'function') {
      throw new Error('Observer must implement update(values)');
    }
    this.observers.push(observer);
  }

  setValues(values) {
    if (!values || typeof values !== 'object') {
      throw new Error('values must be an object');
    }
    // validate keys
    const { temperature, luminosity, humidity } = values;
    if (temperature === undefined || luminosity === undefined || humidity === undefined) {
      throw new Error('values must include temperature, luminosity and humidity');
    }
    const payload = { temperature, luminosity, humidity, timestamp: Date.now() };
    this.latest = payload;
    // store history (keeps all readings)
    this.history.push(payload);
    // notify observers
    for (const obs of this.observers) {
      try {
        obs.update(payload);
      } catch (err) {
        // log observer errors but continue
        console.error('observer update error', err);
      }
    }
  }
}

module.exports = WeatherStation;
