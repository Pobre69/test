class ControlPanel {
  constructor(io) {
    this.io = io;
  }

  update(values) {
    // emit to websocket channel for control panel UI
    if (this.io) this.io.emit('control:update', values);
    console.log('[ControlPanel] received update', values);
  }
}

module.exports = ControlPanel;
