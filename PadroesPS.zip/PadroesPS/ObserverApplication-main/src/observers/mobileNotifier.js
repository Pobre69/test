class MobileNotifier {
  constructor(io) {
    this.io = io;
  }

  update(values) {
    // in a real app we'd push to mobile via FCM/APNs; here we just emit and log
    if (this.io) this.io.emit('mobile:notification', {
      title: 'Sensor update',
      body: `Temp: ${values.temperature}°C, Lum: ${values.luminosity}, Hum: ${values.humidity}`,
      values,
    });
    console.log('[MobileNotifier] notify mobile', values);
  }
}

module.exports = MobileNotifier;
