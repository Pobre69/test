class AlarmSystem {
  constructor(io, opts = {}) {
    this.io = io;
    this.tempThreshold = opts.tempThreshold ?? 30;
    this.armed = true;
  }

  update(values) {
    if (!this.armed) return;
    if (values.temperature > this.tempThreshold) {
      const alert = {
        level: 'high',
        message: `Temperature exceeded threshold: ${values.temperature}°C > ${this.tempThreshold}°C`,
        values,
      };
      if (this.io) this.io.emit('alarm:trigger', alert);
      console.log('[AlarmSystem] ALERT', alert.message);
    } else {
      // emit clear
      if (this.io) this.io.emit('alarm:clear', { values });
    }
  }
}

module.exports = AlarmSystem;
