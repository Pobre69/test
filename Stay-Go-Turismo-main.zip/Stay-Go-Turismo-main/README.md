<h1 text-align: center>Stay Go Turismo</h1>
<ul text-align: center>
  <li>Arthur Lopes – 22301437</li>
  <li>Arthur Victor – 22400311</li>
  <li>Davi Marques – 22400044</li>
  <li>Enzo –  22403060</li>
  <li>Kayque Matheus – 22402730</li>
  <li>Pedro Barbosa – 22302700</li>
</ul>
<h2 text-align: center>3C2</h2>

- [ ] RF01 --- O sistema vai possuir uma seção para adicionar cidades que os usuários pedirem, na sessão de feedback. --- Média  <br>
- [ ] RF02 --- O sistema deve ter ferramentas para dar zoom em determinadas seções, como, por exemplo, o pequeno quadro com o ponto turístico. --- Alta <b> --- PRIORIDADE </b><br>
- [ ] RF03 --- O usuário deve poder personalizar as configurações da interface como claro e escuro. --- Média<b> --- PRIORIDADE </b><br>
- [ ] RF04 --- O sistema deve ter um sistema de busca eficiente por categorias tais como esportes, museus,  pontos naturais e edifícios históricos. --- Alta  <b> --- PRIORIDADE </b><br>
- [ ] RF05 --- O sistema deverá possuir pelo menos, os 10 pontos turísticos mais visitados de Belo Horizonte. Esses pontos terão como base a pesquisa em diversas IAs, onde os pontos que mais se repetirem, serão colocados em destaque. --- Alta <b> --- PRIORIDADE </b><br>
- [ ] RF06 --- O sistema deve possuir uma seção de Feedback para a equipe de desenvolvimento. --- Média <br>
- [ ] RF07 --- O sistema de busca deverá ter filtros de horário de abertura, preço, entre outros. --- Baixa<br>
- [ ] RF08 --- Cada ponto turístico terá uma página no sistema, com informações. --- Alta <b> --- PRIORIDADE </b><br>
- [ ] RF09 --- Serão criadas seções onde pontos turísticos com o mesmo tema (como, por exemplo, tema futebol: Mineirão, Arena Independência, Arena MRV…) serão catalogados juntos. --- Média<b> --- PRIORIDADE </b><br>
- [ ] RF10 --- Serão criadas seções por cidades, quando (e se) o projeto expandir para outras cidades. --- Baixa  <br>
- [ ] RF11 --- Serão criados pacotes com percursos, mostrando pontos turísticos próximos entre si e com o mesmo tema. Serão pacotes padrões e todos os usuários terão acesso a eles. --- Média<br>
- [ ] RF12 --- Será implementado, além de pontos turísticos locais para refeição que possuam um certo destaque com o auxílio do Google Maps. --- Baixa <br>
- [ ] RF13 --- Também será implementado hotéis que possuam um bom destaque com o auxílio do Google Maps. --- Baixa  <br>
- [ ] RF14 --- O sistema terá pontos turísticos variados, além dos 10 que foram citados acima com o auxílio da API do Google Maps. --- Alta  <b> --- PRIORIDADE </b><br>
- [ ] RF15 --- O sistema vai possuir uma seção de citações de pessoas mais famosas para dar credibilidade ( se, por exemplo, o Gleison indicar o site, terá uma parte escrita “indicado por Gleison, professor do colégio Cotemig…”) --- Alta <b> --- PRIORIDADE </b><br>
- [ ] RF16 --- O sistema deve ter uma página de referências, para que a sua credibilidade aumente. --- Alta <b> --- PRIORIDADE </b><br>
- [ ] RF17 --- O sistema poderá mostrar também, patrimônios históricos importantes, mesmo que eles não sejam pontos turísticos. --- Baixa
<br>
- [ ] RF18 --- O sistema poderá mostrar pontos turísticos naturais, além dos artificiais. --- Média <b> --- PRIORIDADE </b><br>
- [ ] RF19 --- O sistema falará a média do tempo de percurso de um local para outro (mas sem ser exata, será algo como: “Do Mineirão ao Mineirinho são 5 minutos a pé EM MÉDIA”) --- Baixa<br>
- [ ] RF20 --- Na seção de FeedBack, as pessoas poderão dar sugestões de pacotes de percursos. --- Média <br>

