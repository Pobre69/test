<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stay Go Turismo</title>
    <link rel="stylesheet" href="../../Web/css/index.css">
    <link rel="stylesheet" href="../../Web/css/Texts.css">
    <link rel="stylesheet" href="../../Web/css/contato.css">
    <?php if($DarkMode ?? false == true): ?>
        <link rel="stylesheet" href="../../Web/css/DarkMode.css">
    <?php else: ?>
        <link rel="stylesheet" href="../../Web/css/LightMode.css">
    <?php endif ?>
</head>
<body>
    <?php 
        include_once(__DIR__ . '../../Components/Menu.php');
        include_once(__DIR__ . '../../Components/Header.php');
        include_once(__DIR__ . '../../Components/Black_BackGround.html');
    ?>
    
    <main class="container">
        
        <form method="GET" action="<?= $First_url ?>/getPonto" class="section quadro">
            <h3>Encontrar ponto turístico</h3>
            <input type="text" name="nome" placeholder="Nome do ponto">
            <select name="tema">
                <option value="">Categoria...</option>
                <option value="Patrimonios Historicos">Patrimonios Historicos</option>
                <option value="Monumentos e Arquitetura">Monumentos e Arquitetura</option>
                <option value="Cidades Coloniais">Cidades Coloniais</option>
                <option value="Museus e Galerias">Museus e Galerias</option>
                <option value="Ruinas e Arqueologia">Ruinas e Arqueologia</option>
                <option value="Cultura Popular">Cultura Popular</option>
                <option value="Gastronomia Local">Gastronomia Local</option>
                <option value="Ecoturismo e Natureza">Ecoturismo e Natureza</option>
                <option value="Montanhas e Trilhas">Montanhas e Trilhas</option>
                <option value="Praias Paradisiacas">Praias Paradisiacas</option>
                <option value="Rios e Cachoeiras">Rios e Cachoeiras</option>
                <option value="Turismo de Aventura">Turismo de Aventura</option>
                <option value="Turismo Rural">Turismo Rural</option>
                <option value="Turismo Religioso">Turismo Religioso</option>
                <option value="Festas Tradicionais">Festas Tradicionais</option>
                <option value="Turismo Urbano">Turismo Urbano</option>
                <option value="Vida Noturna">Vida Noturna</option>
                <option value="Turismo Fotografico">Turismo Fotografico</option>
                <option value="Turismo Sustentavel">Turismo Sustentavel</option>
                <option value="Centros Historicos">Centros Historicos</option>
            </select>
            <input type="time" name="horarioAbertura" placeholder="Abertura">
            <input type="time" name="horarioFechamento" placeholder="Fechamento">
            <input type="number" step="0.1" name="avaliacao_min" placeholder="Avaliação mín">
            <input type="number" step="0.1" name="avaliacao_max" placeholder="Avaliação máx">
            <input type="number" name="visitantes" placeholder="Visitantes">
            <input type="number" name="preco_min" placeholder="Preço mín">
            <input type="number" name="preco_max" placeholder="Preço máx">
            <select name="Ponto_Turistico_Natural">
                <option value="">Tema...</option>
                <option value="false">Não Natural</option>
                <option value="true">Natural</option>
            </select>
            <input type="text" name="cidade" placeholder="Cidade">
            <input type="text" name="estado" placeholder="Estado">
            <button type="submit">Buscar</button>
        </form>

        <section>
            <h2>📍 Resultados da Busca</h2>
            <?php if (isset($busca) && !empty($busca)): ?>
                <div class="grid">
                    <?php foreach ($busca as $ponto): ?>
                        <div>
                            <a href="ponto.php?id=<?= $ponto['pt_id'] ?>">
                                <img src="<?= $ponto['pt_imagem'] ?? '/../../Web/Imagens/logoSugestao.jpg'?>" style="width:100px"><br>
                                <b><?= $ponto['pt_nome'] ?></b>
                            </a><br>
                            Total de Visitantes: <?= $ponto['pt_views'] ?? '-' ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <p>Nenhum resultado encontrado para sua busca.</p>
                </div>
            <?php endif; ?>
        </section>

        <section>
            <h2>⭐ 10 Maiores Destaques</h2>
            <?php if (isset($destaques) && is_array($destaques)): ?>
                <div class="grid">
                    <?php foreach ($destaques as $ponto): ?>
                        <div>
                            <a href="ponto.php?id=<?= $ponto['pt_id'] ?>">
                                <img src="<?= $ponto['pt_imagem'] ?? '/../../Web/Imagens/logoSugestao.jpg'?>" style="width:100px"><br>
                                <b><?= $ponto['pt_nome'] ?></b>
                            </a><br>
                            Total de Visitantes: <?= $ponto['pt_views'] ?? '-' ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <p>Nenhum resultado encontrado para sua busca.</p>
                </div>
            <?php endif; ?>
        </section>

        <section>
            <h2>👁️ Pontos Mais Visitados</h2>
            <?php if (isset($pontosMaisVisitados) && is_array($pontosMaisVisitados)): ?>
                <div class="grid">
                    <?php foreach ($pontosMaisVisitados as $ponto): ?>
                        <div>
                            <a href="ponto.php?id=<?= $ponto['pt_id'] ?>">
                                <img src="<?= $ponto['pt_imagem'] ?? '/../../Web/Imagens/logoSugestao.jpg'?>" style="width:100px"><br>
                                <b><?= $ponto['pt_nome'] ?></b>
                            </a><br>
                            Total de Visitantes: <?= $ponto['pt_views'] ?? '-' ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <p>Nenhum resultado encontrado para sua busca.</p>
                </div>
            <?php endif; ?>
        </section>

        <section>
            <h2>🏆 Melhores Avaliados</h2>
            <?php if (isset($avaliados) && is_array($avaliados)): ?>
                <div class="grid">
                    <?php foreach ($avaliados as $ponto): ?>
                        <div>
                            <a href="ponto.php?id=<?= $ponto['pt_id'] ?>">
                                <img src="<?= $ponto['pt_imagem'] ?? '/../../Web/Imagens/logoSugestao.jpg'?>" style="width:100px"><br>
                                <b><?= $ponto['pt_nome'] ?></b>
                            </a><br>
                            Total de Visitantes: <?= $ponto['pt_views'] ?? '-' ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <p>Nenhum resultado encontrado para sua busca.</p>
                </div>
            <?php endif; ?>
        </section>

        <section>
            <h2>🏛️ Patrimônios Históricos</h2>
            <?php if (isset($patrimonios) && is_array($patrimonios)): ?>
                <div class="grid">
                    <?php foreach ($patrimonios as $ponto): ?>
                        <div>
                            <a href="ponto.php?id=<?= $ponto['pt_id'] ?>">
                                <img src="<?= $ponto['pt_imagem'] ?? '/../../Web/Imagens/logoSugestao.jpg'?>" style="width:100px"><br>
                                <b><?= $ponto['pt_nome'] ?></b>
                            </a><br>
                            Total de Visitantes: <?= $ponto['pt_views'] ?? '-' ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <p>Nenhum resultado encontrado para sua busca.</p>
                </div>
            <?php endif; ?>
        </section>

        <section>
            <h2>🌿 Pontos Naturais</h2>
            <?php if (isset($pontosNaturais) && is_array($avaliapontosNaturaisdos)): ?>
                <div class="grid">
                    <?php foreach ($pontosNaturais as $ponto): ?>
                        <div>
                            <a href="ponto.php?id=<?= $ponto['pt_id'] ?>">
                                <img src="<?= $ponto['pt_imagem'] ?? '/../../Web/Imagens/logoSugestao.jpg'?>" style="width:100px"><br>
                                <b><?= $ponto['pt_nome'] ?></b>
                            </a><br>
                            Total de Visitantes: <?= $ponto['pt_views'] ?? '-' ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <p>Nenhum resultado encontrado para sua busca.</p>
                </div>
            <?php endif; ?>
        </section>
    </main>

    <?php
        include_once(__DIR__ . '../../Components/Footer.html');
    ?>

    <script src="../../Web/JavaScript/index.js"></script>
    <script src="../../Web/JavaScript/Global.js"></script>
</body>
</html>
