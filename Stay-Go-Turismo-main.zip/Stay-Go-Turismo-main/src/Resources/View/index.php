<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stay Go Turismo</title>
    <link rel="stylesheet" href="../../Web/css/index.css">
    <link rel="stylesheet" href="../../Web/css/Texts.css">
    <link rel="stylesheet" href="../../Web/css/home.css">
    <link rel="stylesheet" href="../../Web/css/forms.css">
    <?php if($DarkMode ?? false == true): ?>
        <link rel="stylesheet" href="../../Web/css/DarkMode.css">
    <?php else: ?>
        <link rel="stylesheet" href="../../Web/css/LightMode.css">
    <?php endif ?>
</head>
<body>
    <?php 
        include_once(__DIR__ . '../../Components/Menu.php');
        include_once(__DIR__ . '../../Components/Header.php');
        include_once(__DIR__ . '../../Components/Black_BackGround.html');
    ?>
    
    <main class="container">
        <form method="GET" action="<?= $First_url ?>/getPonto" class="FormEdit">
            <h3>🔍 Encontrar ponto turístico</h3>
            
            <div class="form-grid">
                <div class="form-group">
                    <label for="nome">Nome do local</label>
                    <input type="text" id="nome" name="nome" placeholder="Ex: Parque Nacional">
                </div>

                <div class="form-group">
                    <label for="tema">Categoria</label>
                    <select id="tema" name="tema">
                        <option value="">Todas as categorias</option>
                        <option value="Patrimonios Historicos">Patrimônios Históricos</option>
                        <option value="Monumentos e Arquitetura">Monumentos e Arquitetura</option>
                        <option value="Cidades Coloniais">Cidades Coloniais</option>
                        <option value="Museus e Galerias">Museus e Galerias</option>
                        <option value="Ruinas e Arqueologia">Ruínas e Arqueologia</option>
                        <option value="Cultura Popular">Cultura Popular</option>
                        <option value="Gastronomia Local">Gastronomia Local</option>
                        <option value="Ecoturismo e Natureza">Ecoturismo e Natureza</option>
                        <option value="Montanhas e Trilhas">Montanhas e Trilhas</option>
                        <option value="Praias Paradisiacas">Praias Paradisíacas</option>
                        <option value="Rios e Cachoeiras">Rios e Cachoeiras</option>
                        <option value="Turismo de Aventura">Turismo de Aventura</option>
                        <option value="Turismo Rural">Turismo Rural</option>
                        <option value="Turismo Religioso">Turismo Religioso</option>
                        <option value="Festas Tradicionais">Festas Tradicionais</option>
                        <option value="Turismo Urbano">Turismo Urbano</option>
                        <option value="Vida Noturna">Vida Noturna</option>
                        <option value="Turismo Fotografico">Turismo Fotográfico</option>
                        <option value="Turismo Sustentavel">Turismo Sustentável</option>
                        <option value="Centros Historicos">Centros Históricos</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Horário de funcionamento</label>
                    <div class="time-group">
                        <input type="time" name="horarioAbertura" title="Horário de abertura">
                        <input type="time" name="horarioFechamento" title="Horário de fechamento">
                    </div>
                </div>

                <div class="form-group">
                    <label>Avaliação</label>
                    <div class="time-group">
                        <input type="number" step="0.1" min="0" max="5" name="avaliacao_min" placeholder="Mín" title="Avaliação mínima">
                        <input type="number" step="0.1" min="0" max="5" name="avaliacao_max" placeholder="Máx" title="Avaliação máxima">
                    </div>
                </div>

                <div class="form-group">
                    <label for="visitantes">Mínimo de visitantes</label>
                    <input type="number" id="visitantes" name="visitantes" min="0" placeholder="Ex: 1000">
                </div>

                <div class="form-group">
                    <label>Faixa de preço</label>
                    <div class="time-group">
                        <input type="number" step="0.01" min="0" name="preco_min" placeholder="R$ Mín">
                        <input type="number" step="0.01" min="0" name="preco_max" placeholder="R$ Máx">
                    </div>
                </div>

                <div class="form-group">
                    <label for="tipo">Tipo do local</label>
                    <select id="tipo" name="Ponto_Turistico_Natural">
                        <option value="">Todos os tipos</option>
                        <option value="true">Natural</option>
                        <option value="false">Não Natural</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="cidade">Cidade</label>
                    <input type="text" id="cidade" name="cidade" placeholder="Ex: São Paulo">
                </div>

                <div class="form-group">
                    <label for="estado">Estado</label>
                    <input type="text" id="estado" name="estado" placeholder="Ex: SP">
                </div>
            </div>

            <button type="submit">🔍 Buscar</button>
        </form>

        <section>
            <h2>📍 Resultados da Busca</h2>
            <?php if (isset($busca) && !empty($busca)): ?>
                <div class="card">
                    <?php foreach ($busca as $ponto): ?>
                        <div class="cardInfo">
                            <a href="ponto.php?id=<?= $ponto['pt_id'] ?>">
                                <img src="<?= $ponto['pt_imagem'] ?? '/../../Web/Imagens/logoSugestao.jpg'?>" style="width:100px"><br>
                                <b><?= $ponto['pt_nome'] ?></b>
                            </a><br>
                            Total de Visitantes: <?= $ponto['pt_views'] ?? '-' ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <p>Nenhum resultado encontrado para sua busca.</p>
                </div>
            <?php endif; ?>
        </section>

        <section>
            <h2>⭐ 10 Maiores Destaques</h2>
            <?php if (isset($destaques) && is_array($destaques)): ?>
                <div class="card">
                    <?php foreach ($destaques as $ponto): ?>
                        <div class="cardInfo">
                            <a href="ponto.php?id=<?= $ponto['pt_id'] ?>">
                                <img src="<?= $ponto['pt_imagem'] ?? '/../../Web/Imagens/logoSugestao.jpg'?>" style="width:100px"><br>
                                <b><?= $ponto['pt_nome'] ?></b>
                            </a><br>
                            Total de Visitantes: <?= $ponto['pt_views'] ?? '-' ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <p>Nenhum resultado encontrado para sua busca.</p>
                </div>
            <?php endif; ?>
        </section>

        <section>
            <h2>👁️ Pontos Mais Visitados</h2>
            <?php if (isset($pontosMaisVisitados) && is_array($pontosMaisVisitados)): ?>
                <div class="card">
                    <?php foreach ($pontosMaisVisitados as $ponto): ?>
                        <div class="cardInfo">
                            <a href="ponto.php?id=<?= $ponto['pt_id'] ?>">
                                <img src="<?= $ponto['pt_imagem'] ?? '/../../Web/Imagens/logoSugestao.jpg'?>" style="width:100px"><br>
                                <b><?= $ponto['pt_nome'] ?></b>
                            </a><br>
                            Total de Visitantes: <?= $ponto['pt_views'] ?? '-' ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <p>Nenhum resultado encontrado para sua busca.</p>
                </div>
            <?php endif; ?>
        </section>

        <section>
            <h2>🏆 Melhores Avaliados</h2>
            <?php if (isset($avaliados) && is_array($avaliados)): ?>
                <div class="card">
                    <?php foreach ($avaliados as $ponto): ?>
                        <div class="cardInfo">
                            <a href="ponto.php?id=<?= $ponto['pt_id'] ?>">
                                <img src="<?= $ponto['pt_imagem'] ?? '/../../Web/Imagens/logoSugestao.jpg'?>" style="width:100px"><br>
                                <b><?= $ponto['pt_nome'] ?></b>
                            </a><br>
                            Total de Visitantes: <?= $ponto['pt_views'] ?? '-' ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <p>Nenhum resultado encontrado para sua busca.</p>
                </div>
            <?php endif; ?>
        </section>

        <section>
            <h2>🏛️ Patrimônios Históricos</h2>
            <?php if (isset($patrimonios) && is_array($patrimonios)): ?>
                <div class="card">
                    <?php foreach ($patrimonios as $ponto): ?>
                        <div class="cardInfo">
                            <a href="ponto.php?id=<?= $ponto['pt_id'] ?>">
                                <img src="<?= $ponto['pt_imagem'] ?? '/../../Web/Imagens/logoSugestao.jpg'?>" style="width:100px"><br>
                                <b><?= $ponto['pt_nome'] ?></b>
                            </a><br>
                            Total de Visitantes: <?= $ponto['pt_views'] ?? '-' ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <p>Nenhum resultado encontrado para sua busca.</p>
                </div>
            <?php endif; ?>
        </section>

        <section>
            <h2>🌿 Pontos Naturais</h2>
            <?php if (isset($pontosNaturais) && is_array($avaliapontosNaturaisdos)): ?>
                <div class="card">
                    <?php foreach ($pontosNaturais as $ponto): ?>
                        <div class="cardInfo">
                            <a href="ponto.php?id=<?= $ponto['pt_id'] ?>">
                                <img src="<?= $ponto['pt_imagem'] ?? '/../../Web/Imagens/logoSugestao.jpg'?>" style="width:100px"><br>
                                <b><?= $ponto['pt_nome'] ?></b>
                            </a><br>
                            Total de Visitantes: <?= $ponto['pt_views'] ?? '-' ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <p>Nenhum resultado encontrado para sua busca.</p>
                </div>
            <?php endif; ?>
        </section>
    </main>

    <?php
        include_once(__DIR__ . '../../Components/Footer.html');
    ?>

    <script>
        window.pontosList = <?= json_encode(array_merge(
            $busca ?? [], 
            $destaques ?? [], 
            $pontosMaisVisitados ?? [], 
            $avaliados ?? [],
            $patrimonios ?? [],
            $pontosNaturais ?? []
        )) ?>;
    </script>
    
    <!-- Filter scripts -->
    <script src="../../Web/JavaScript/FilterBase.js"></script>
    <script src="../../Web/JavaScript/Filters.js"></script>
    <script src="../../Web/JavaScript/FilterApply.js"></script>
    <script src="../../Web/JavaScript/Global.js"></script>
</body>
</html>
