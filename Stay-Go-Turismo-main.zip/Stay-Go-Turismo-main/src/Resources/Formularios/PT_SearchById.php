<input type="hidden" name="_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">

<input type="hidden" id="PT_id" name="PT_id">