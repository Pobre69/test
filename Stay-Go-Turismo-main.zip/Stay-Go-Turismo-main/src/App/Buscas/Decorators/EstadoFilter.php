<?php

namespace Estado\Decorator;

use Search\Interface\BaseSearchDecorator;
use Search\Interface\ISearchDecoratorService;

class EstadoFilter extends BaseSearchDecorator {
    private string $estadoSelected;

    public function __construct(ISearchDecoratorService $search, string $estadoSelected) {
        parent::__construct($search);
        $this->estadoSelected = $estadoSelected;
    }

    public function execute_search(string $query): array {
        $results = $this->search->execute_search($query);
        
        $filteredResults = array_filter($results, function($ponto) {
            return isset($ponto["estado"]) && 
                stripos($ponto["estado"], $this->cidadeSelected) !== false;
        });

        return array_values($filteredResults);
    }
}