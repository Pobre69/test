<?php

namespace Avaliacao\Decorator;

use Search\Interface\BaseSearchDecorator;
use Search\Interface\ISearchDecoratorService;

class AvaliacaoFilter extends BaseSearchDecorator {
    private float $minRating;
    private float $maxRating;

    public function __construct(ISearchDecoratorService $search, float $minRating, float $maxRating) {
        parent::__construct($search);
        $this->minRating = $minRating;
        $this->maxRating = $maxRating;
    }

    public function execute_search(string $query): array {
        // CORRIGI: adicionei o parâmetro $query na chamada
        $results = $this->search->execute_search($query);
        
        $filteredResults = array_filter($results, function($ponto) {
            if (!isset($ponto["avaliacao"])) {
                return false;
            }
            
            $avaliacao = (float)$ponto["avaliacao"];
            return $avaliacao >= $this->minRating && $avaliacao <= $this->maxRating;
        });

        return array_values($filteredResults);
    }
}
