<?php

namespace Cidades\Decorator;

use Search\Interface\BaseSearchDecorator;
use Search\Interface\ISearchDecoratorService;

class CidadeFilter extends BaseSearchDecorator {
    private string $cidadeSelected;

    public function __construct(ISearchDecoratorService $search, string $cidadeSelected) {
        parent::__construct($search);
        $this->cidadeSelected = $cidadeSelected;
    }

    public function execute_search(string $query): array {
        $results = $this->search->execute_search($query);
        
        $filteredResults = array_filter($results, function($ponto) {
            return isset($ponto["cidade"]) && 
                stripos($ponto["cidade"], $this->cidadeSelected) !== false;
        });

        return array_values($filteredResults);
    }
}