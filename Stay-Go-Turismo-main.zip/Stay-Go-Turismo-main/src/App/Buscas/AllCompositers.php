<?php

namespace All\Compositers;

use Search\Interface\ISearchCompositeService;

class AllCompositers
{
    private array $children = [];

    public function add(ISearchCompositeService $component): void
    {
        $this->children[] = $component;
    }

    public function remove(ISearchCompositeService $component): void
    {
        $this->children = array_filter($this->children, function ($child) use ($component) {
            return $child !== $component;
        });
    }

    public function execute_search(string $query): array
    {
        $allResults = [];
        
        foreach ($this->children as $component) {
            $results = $component->execute_search($query);
            $allResults = array_merge($allResults, $results);
        }

        return $allResults;
    }
}