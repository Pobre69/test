<?php

namespace All\Decorators;

use Search\Interface\ISearchDecoratorService;
use Avaliacao\Decorator\AvaliacaoFilter; // ← Corrigido namespace
use Cidades\Decorator\CidadeFilter;
use Estado\Decorator\EstadoFilter;
use Estacionamento\Decorator\EstacionamentoFilter;
use Horario\Decorator\HorarioFilter;
use Natural\Decorator\NaturalFilter;
use TemaFilter\Decorator\TemaFilter;
use Visitantes\Decorator\VisitantesFilter;

class AllDecorators implements ISearchDecoratorService
{
    private array $search;
    
    public function __construct(array $values = [])
    {
        $this->search = $values;
    }

    public function filtrar(): array
    {
        $searchService = $this;
        
        // Converter para float e validar
        $avaliacaoMin = isset($_GET["avaliacao_min"]) && $_GET["avaliacao_min"] !== '' 
            ? (float)$_GET["avaliacao_min"] 
            : null;
        $avaliacaoMax = isset($_GET["avaliacao_max"]) && $_GET["avaliacao_max"] !== '' 
            ? (float)$_GET["avaliacao_max"] 
            : null;

        if ($avaliacaoMin !== null && $avaliacaoMax !== null) {
            $searchService = new AvaliacaoFilter(
                $searchService, 
                $avaliacaoMin, 
                $avaliacaoMax
            );
        }

        if (isset($_GET["cidade"]) && $_GET["cidade"] !== '') {
            $searchService = new CidadeFilter($searchService, $_GET["cidade"]);
        }

        if (isset($_GET["estado"]) && $_GET["estado"] !== '') {
            $searchService = new EstadoFilter($searchService, $_GET["estado"]);
        }

        $horarioAbertura = isset($_GET["horarioAbertura"]) && $_GET["horarioAbertura"] !== '' 
            ? $_GET["horarioAbertura"] 
            : null;
        $horarioFechamento = isset($_GET["horarioFechamento"]) && $_GET["horarioFechamento"] !== '' 
            ? $_GET["horarioFechamento"] 
            : null;
        
        if ($horarioAbertura !== null && $horarioFechamento !== null) {
            $searchService = new HorarioFilter(
                $searchService, 
                $horarioAbertura, 
                $horarioFechamento
            );
        }

        if (isset($_GET["Ponto_Turistico_Natural"]) && $_GET["Ponto_Turistico_Natural"] !== '') {
            if ($_GET["Ponto_Turistico_Natural"] == 'false'){
                $_GET["Ponto_Turistico_Natural"] = false;
            }else{
                $_GET["Ponto_Turistico_Natural"] = true;
            }
            $searchService = new NaturalFilter($searchService, $_GET["Ponto_Turistico_Natural"]);
        }

        $visitantesMin = isset($_GET["visitantes_min"]) && $_GET["visitantes_min"] !== '' 
            ? (int)$_GET["visitantes_min"] 
            : null;
        $visitantesMax = isset($_GET["visitantes_max"]) && $_GET["visitantes_max"] !== '' 
            ? (int)$_GET["visitantes_max"] 
            : null;
        
        if ($visitantesMin !== null && $visitantesMax !== null) {
            $searchService = new VisitantesFilter(
                $searchService, 
                $visitantesMin, 
                $visitantesMax
            );
        }

        if (isset($_GET["tema"]) && $_GET["tema"] !== '') {
            $searchService = new TemaFilter($searchService, $_GET["tema"]);
        }

        return $searchService->execute_search($_GET["nome"] ?? "");
    }
    
    public function execute_search(string $query): array
    {
        return $this->search;
    }
}
