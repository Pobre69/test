<?php

namespace All\Decorators;



use PontoTuristico\Models\PontoTuristico;
use Tema\Models\Tema;
use Ponto_Tema\Models\Ponto_Tema;

use Avaliacao\Decorators\AvaliacaoFilter;
use Cidades\Decorators\CidadeFilter;
use Estado\Decorators\EstadoFilter;
use Estacionamento\Decorators\EstacionamentoFilter;
use Horario\Decorators\HorarioFilter;
use Natural\Decorators\NaturalFilter;
use TemaFilter\Decorator\TemaFilter;
use Visitantes\Decorators\VisitantesFilter;

class AllDecorators
{
    public static function filtrar(array $input): array
    {
        $search = new PontoTuristico();
        $searchTema = new Tema();
        $searchPonto_Tema = new Ponto_Tema();

        if (isset($input["avaliacaoMin"]) || isset($input["avaliacaoMax"])) {
            $search = new AvaliacaoFilter($search, $input["avaliacaoMin"] ?? null, $input["avaliacaoMax"] ?? null);
        }

        if (isset($input["cidade"])) {
            $search = new CidadeFilter($search, $input["cidade"]);
        }

        if (isset($input["estado"])) {
            $search = new EstadoFilter($search, $input["estado"]);
        }

        if (isset($input["estacionamento"])) {
            $search = new EstacionamentoFilter($search, $input["estacionamento"]);
        }

        if (isset($input["horarioAberturaMin"]) || isset($input["horarioFechamentoMax"])) {
            $search = new HorarioFilter($search, $input["horarioAberturaMin"] ?? null, $input["horarioFechamentoMax"] ?? null);
        }

        if (isset($input["natural"])) {
            $search = new NaturalFilter($searchPonto_Tema, $input["natural"]);
        }

        if (isset($input["patrimonio"])) {
            $search = new PatrimonioFilter($search, $input["patrimonio"]);
        }

        if (isset($input["visitantesMin"]) || isset($input["visitantesMax"])) {
            $search = new VisitantesFilter($search, $input["visitantesMin"] ?? null, $input["visitantesMax"] ?? null);
        }

        if (isset($input["visitantesMin"]) || isset($input["visitantesMax"])) {
            $search = new TemaFilter($searchTema, $input["tema"]);
        }

        return $search->execute_search($input["nome"] ?? "");
    }
}