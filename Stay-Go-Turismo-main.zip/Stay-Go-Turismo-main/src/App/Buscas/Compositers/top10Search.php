<?php

namespace top10\Composite;

use DataBase\DB_Global_Conection\DB_Conection;
use Search\Interface\ISearchCompositeService;
use PDO;

class top10Search implements ISearchCompositeService 
{
    private PDO $conn;
    private array $searchServices = [];

    public function __construct() {
        $this->conn = DB_Conection::getConnection();
    }

    public function execute_search(string $query = null): array {
        if ($query != null){
            $sql = "SELECT * FROM Show_All WHERE pt_nome LIKE :query ORDER BY pt_views ASC LIMIT 10";
            $stmt = $this->conn->prepare($sql);
            $stmt->bindValue(':query', '%' . $query . '%');
        }else{
            $sql = "SELECT * FROM Show_All ORDER BY pt_views ASC LIMIT 10";
            $stmt = $this->conn->prepare($sql);
        }
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}