<?php

namespace Avaliados\Composite;

use DataBase\DB_Global_Conection\DB_Conection;
use Search\Interface\ISearchCompositeService;
use PDO;

class AvaliadosSearch implements ISearchCompositeService 
{
    private PDO $conn;

    public function __construct() {
        $this->conn = DB_Conection::getConnection();
    }

    public function execute_search(string $query = null): array {
        if ($query != null){
            $sql = "SELECT * FROM FullPonto WHERE pt_nome  = :query ORDER BY pt_c17 DESC";
            $stmt = $this->conn->prepare($sql);
            $stmt->bindValue(':query', '%' . $query . '%');
        }else{
            $sql = "SELECT * FROM FullPonto ORDER BY pt_c17 DESC";
            $stmt = $this->conn->prepare($sql);
        }
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}