<?php

namespace top10Destaque\Composite;

use DataBase\DB_Global_Conection\DB_Conection;
use Search\Interface\ISearchCompositeService;
use PDO;

class top10DestaqueSearch implements ISearchCompositeService 
{
    private PDO $conn;

    public function __construct() {
        $this->conn = DB_Conection::getConnection();
    }

    public function execute_search(string $query = null): array {
        if ($query != null){
            $sql = "SELECT * FROM Show_Top10 WHERE pt_nome LIKE :query LIMIT 10";
            $stmt = $this->conn->prepare($sql);
            $stmt->bindValue(':query', '%' . $query . '%');
        }else{
            $sql = "SELECT * FROM Show_Top10 LIMIT 10";
            $stmt = $this->conn->prepare($sql);
        }
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}