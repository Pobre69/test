<?php

namespace PontoNatural\Composite;

use DataBase\DB_Global_Conection\DB_Conection;
use Search\Interface\ISearchCompositeService;
use PDO;

class PontoNaturalSearch implements ISearchCompositeService 
{
    private PDO $conn;

    public function __construct() {
        $this->conn = DB_Conection::getConnection();
    }

    public function execute_search(string $query = null): array {
        if ($query != null){
            $sql = "SELECT * FROM Show_All WHERE pt_natural = 1";
            $stmt = $this->conn->prepare($sql);
        }else{
            $sql = "SELECT * FROM Show_All";
            $stmt = $this->conn->prepare($sql);
        }
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}