<?php

namespace View\Controller;

use DarkMode\Models\DarkMode;
use FeedBacks\Controller\FeedBacksController;
use csrf\token\csrf_Token;
use top10\Composite\top10Search;

class ViewController
{
    public static function render(string $viewName)
    {
        $csrf = new csrf_Token();
        $csrf->generateToken();
        $DarkMode = new DarkMode();
        $DarkMode = $DarkMode->getMode();
        $First_url = '/Sites/Stay-Go-Turismo-main/src/Routes/Web.php';
        $viewPath = __DIR__ . "/../../Resources/View/" . $viewName . ".php";
        if (file_exists($viewPath)) {
            include_once($viewPath);
        } else {
            header("HTTP/1.0 404 Not Found");
            echo "View not found.";
        }
    }
    public static function indexRender()
    {
        $top10 = new top10Search();
        $destaques = $top10->execute_search();

        $csrf = new csrf_Token();
        $csrf->generateToken();
        $DarkMode = new DarkMode();
        $DarkMode = $DarkMode->getMode();
        $First_url = '/Sites/Stay-Go-Turismo-main/src/Routes/Web.php';
        $viewPath = __DIR__ . "/../../Resources/View/index.php";
        if (file_exists($viewPath)) {
            include_once($viewPath);
        } else {
            header("HTTP/1.0 404 Not Found");
            echo "View not found.";
        }
    }
}