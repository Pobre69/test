<?php

namespace View\Controller;

use DarkMode\Models\DarkMode;
use PontoTuristico\Models\PontoTuristico;
use csrf\token\csrf_Token;
use All\Compositers\AllCompositers;
use top10\Composite\top10Search;
use Tema\Composite\TemaSearch;
use Ponto\Composite\PontoSearch;
use top10Destaque\Composite\top10DestaqueSearch;
use Avaliados\Composite\AvaliadosSearch;
use Patrimonios\Composite\PatrimoniosSearch;
use PontoNatural\Composite\PontoNaturalSearch;

class ViewController
{
    public static function render(string $viewName)
    {
        $csrf = new csrf_Token();
        $csrf->generateToken();
        $DarkMode = new DarkMode();
        $DarkMode = $DarkMode->getMode();
        $First_url = '/Sites/Stay-Go-Turismo-main/src/Routes/Web.php';
        $viewPath = __DIR__ . "/../../Resources/View/" . $viewName . ".php";
        if (file_exists($viewPath)) {
            include_once($viewPath);
        } else {
            header("HTTP/1.0 404 Not Found");
            echo "View not found.";
        }
    }
    public static function indexRender()
    {
        $compositers = new AllCompositers();
        $top10 = new top10Search();
        $temaSearch = new TemaSearch();
        $pontoSearch = new PontoSearch();
        $pontoDestaqueSearch = new top10DestaqueSearch();
        $avaliadosSearch = new AvaliadosSearch();
        $pontoNaturalSearch = new PontoNaturalSearch();
        
        $compositers->add($top10);
        $compositers->add($pontoDestaqueSearch);
        $compositers->add($avaliadosSearch);
        $compositers->add($temaSearch);
        $compositers->add($pontoNaturalSearch);

        $results =  $compositers->execute_search('');
        
        $destaques = $results['top10Destaque\Composite\top10DestaqueSearch'];
        $pontosMaisVisitados = $results['top10\Composite\top10Search'];
        $avaliados = $results['Avaliados\Composite\AvaliadosSearch'];
        $patrimonios = $results['Tema\Composite\TemaSearch'];
        $pontosNaturais = $results['PontoNatural\Composite\PontoNaturalSearch'];

        $csrf = new csrf_Token();
        $csrf->generateToken();
        $DarkMode = new DarkMode();
        $DarkMode = $DarkMode->getMode();
        $First_url = '/Sites/Stay-Go-Turismo-main/src/Routes/Web.php';
        $viewPath = __DIR__ . "/../../Resources/View/index.php";
        if (file_exists($viewPath)) {
            include_once($viewPath);
        } else {
            header("HTTP/1.0 404 Not Found");
            echo "View not found.";
        }
    }
    public static function indexGetPontoRender()
    {
        $compositers = new AllCompositers();
        $top10 = new top10Search();
        $temaSearch = new TemaSearch();
        $pontoSearch = new PontoSearch();
        $pontoDestaqueSearch = new top10DestaqueSearch();
        $avaliadosSearch = new AvaliadosSearch();
        $pontoNaturalSearch = new PontoNaturalSearch();
        
        $compositers->add($top10);
        $compositers->add($pontoDestaqueSearch);
        $compositers->add($avaliadosSearch);
        $compositers->add($temaSearch);
        $compositers->add($pontoNaturalSearch);
        $compositers->add($pontoSearch);

        $results =  $compositers->execute_search($_GET['nome']);
        
        $destaques = $results['top10Destaque\Composite\top10DestaqueSearch'];
        $pontosMaisVisitados = $results['top10\Composite\top10Search'];
        $avaliados = $results['Avaliados\Composite\AvaliadosSearch'];
        $patrimonios = $results['Tema\Composite\TemaSearch'];
        $pontosNaturais = $results['PontoNatural\Composite\PontoNaturalSearch'];
        $busca = $results['Ponto\Composite\PontoSearch'];

        $csrf = new csrf_Token();
        $csrf->generateToken();
        $DarkMode = new DarkMode();
        $DarkMode = $DarkMode->getMode();
        $First_url = '/Sites/Stay-Go-Turismo-main/src/Routes/Web.php';
        $viewPath = __DIR__ . "/../../Resources/View/index.php";
        if (file_exists($viewPath)) {
            include_once($viewPath);
        } else {
            header("HTTP/1.0 404 Not Found");
            echo "View not found.";
        }
    }
}