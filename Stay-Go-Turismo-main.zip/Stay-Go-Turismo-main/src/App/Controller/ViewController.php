<?php

namespace View\Controller;

use DarkMode\Models\DarkMode;
use csrf\token\csrf_Token;
use All\Compositers\AllCompositers;
use All\Decorators\AllDecorators;
use top10\Composite\top10Search;
use Tema\Composite\TemaSearch;
use Ponto\Composite\PontoSearch;

class ViewController
{
    public static function render(string $viewName)
    {
        $csrf = new csrf_Token();
        $csrf->generateToken();
        $DarkMode = new DarkMode();
        $DarkMode = $DarkMode->getMode();
        $First_url = '/Sites/Stay-Go-Turismo-main/src/Routes/Web.php';
        $viewPath = __DIR__ . "/../../Resources/View/" . $viewName . ".php";
        if (file_exists($viewPath)) {
            include_once($viewPath);
        } else {
            header("HTTP/1.0 404 Not Found");
            echo "View not found.";
        }
    }
    public static function indexRender()
    {
        $compositers = new AllCompositers();
        $top10 = new top10Search();
        $temaSearch = new TemaSearch();
        $pontoSearch = new TemaSearch();
        
        $compositers->add($top10);

        $results =  $compositers->execute_search('');

        $csrf = new csrf_Token();
        $csrf->generateToken();
        $DarkMode = new DarkMode();
        $DarkMode = $DarkMode->getMode();
        $First_url = '/Sites/Stay-Go-Turismo-main/src/Routes/Web.php';
        $viewPath = __DIR__ . "/../../Resources/View/index.php";
        if (file_exists($viewPath)) {
            include_once($viewPath);
        } else {
            header("HTTP/1.0 404 Not Found");
            echo "View not found.";
        }
    }
}