class BaseSearchDecorator {
    constructor(search) {
        this.search = search;
    }

    execute(query) {
        return this.search.execute(query);
    }
}