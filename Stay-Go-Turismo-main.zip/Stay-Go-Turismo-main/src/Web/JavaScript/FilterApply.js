/**
 * Apply search filters on page results in index.php
 * Use decorators pattern to filter results by multiple criteria 
 */

class ResultsSearch {
    constructor(results) {
        this.results = results;
    }
    
    execute() {
        return this.results;
    }
}

// Parse values from form fields 
function getFilterValues() {
    return {
        name: document.querySelector('input[name="nome"]').value,
        tema: document.querySelector('select[name="tema"]').value,
        horarioAbertura: document.querySelector('input[name="horarioAbertura"]').value,
        horarioFechamento: document.querySelector('input[name="horarioFechamento"]').value,
        avaliacaoMin: parseFloat(document.querySelector('input[name="avaliacao_min"]').value) || 0,
        avaliacaoMax: parseFloat(document.querySelector('input[name="avaliacao_max"]').value) || 5,
        visitantes: parseInt(document.querySelector('input[name="visitantes"]').value) || 0,
        natural: document.querySelector('select[name="Ponto_Turistico_Natural"]').value,
        cidade: document.querySelector('input[name="cidade"]').value,
        estado: document.querySelector('input[name="estado"]').value
    };
}

// Apply all filters based on form values
function applyFilters(results) {
    const values = getFilterValues();
    let search = new ResultsSearch(results);

    // Apply each filter if value provided
    if (values.avaliacaoMin || values.avaliacaoMax) {
        search = new AvaliacaoFilter(search, values.avaliacaoMin, values.avaliacaoMax); 
    }

    if (values.horarioAbertura && values.horarioFechamento) {
        search = new HorarioFilter(search, values.horarioAbertura, values.horarioFechamento);
    }

    if (values.natural !== '') {
        search = new NaturalFilter(search, values.natural === 'true');
    }

    if (values.estado) {
        search = new EstadoFilter(search, values.estado);
    }

    if (values.cidade) {
        search = new CidadeFilter(search, values.cidade);
    }

    if (values.tema) {
        search = new TemaFilter(search, values.tema);
    }

    if (values.visitantes) {
        search = new VisitantesFilter(search, values.visitantes);
    }

    return search.execute('');
}

// Update results section with filtered data
function updateResults(results) {
    const resultSection = document.querySelector('.results');
    if (!resultSection) return;

    if (!results.length) {
        resultSection.innerHTML = `
            <div class="empty-state">
                <p>Nenhum resultado encontrado para sua busca.</p>
            </div>`;
        return;
    }

    const html = results.map(ponto => `
        <div class="cardInfo">
            <a href="ponto.php?id=${ponto.pt_id}">
                <img src="${ponto.pt_imagem || '/../../Web/Imagens/logoSugestao.jpg'}" style="width:100px"><br>
                <b>${ponto.pt_nome}</b>
            </a><br>
            Total de Visitantes: ${ponto.pt_views || '-'}
        </div>
    `).join('');

    resultSection.innerHTML = `<div class="card">${html}</div>`;
}

// Initialize filters
document.addEventListener('DOMContentLoaded', () => {
    // Add event listeners for form inputs
    const formInputs = document.querySelectorAll('.FormEdit input, .FormEdit select');
    formInputs.forEach(input => {
        input.addEventListener('change', () => {
            const pontos = window.pontosList || [];
            const filteredResults = applyFilters(pontos);
            updateResults(filteredResults);
        });
    });

    // Initial filter application
    const pontos = window.pontosList || [];
    const filteredResults = applyFilters(pontos);
    updateResults(filteredResults);
});