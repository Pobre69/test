class AvaliacaoFilter extends BaseSearchDecorator {
    constructor(search, minRating, maxRating) {
        super(search);
        this.minRating = minRating;
        this.maxRating = maxRating;
    }

    execute(query) {
        const results = this.search.execute(query);
            return results.filter(ponto => {
            if (!('avaliacao' in ponto)) return false;
            const avaliacao = parseFloat(ponto.avaliacao);
            return avaliacao >= this.minRating && avaliacao <= this.maxRating;
        });
    }
}

class HorarioFilter extends BaseSearchDecorator {
    constructor(search, openTime, closeTime) {
        super(search);
        this.openTime = openTime;
        this.closeTime = closeTime;
    }

    execute(query) {
            const results = this.search.execute(query);
            return results.filter(ponto =>
            ponto.horarioAbertura === this.openTime &&
            ponto.horarioFechamento === this.closeTime
        );
    }
}

class NaturalFilter extends BaseSearchDecorator {
    constructor(search, isNatural) {
        super(search);
        this.isNatural = isNatural;
    }

    execute(query) {
        const results = this.search.execute(query);
            return results.filter(ponto =>
            ponto.tema && ponto.tema.PontoTuristicoNatural === this.isNatural
        );
    }
}

class EstadoFilter extends BaseSearchDecorator {
    constructor(search, estadoSelected) {
        super(search);
        this.estadoSelected = estadoSelected;
    }

    execute(query) {
        const results = this.search.execute(query);
            return results.filter(ponto =>
            ponto.estado && ponto.estado.includes(this.estadoSelected)
        );
    }
}

class CidadeFilter extends BaseSearchDecorator {
    constructor(search, cidadeSelected) {
        super(search);
        this.cidadeSelected = cidadeSelected;
    }

    execute(query) {
        const results = this.search.execute(query);
            return results.filter(ponto =>
            ponto.cidade && ponto.cidade.includes(this.cidadeSelected)
        );
    }
}

class TemaFilter extends BaseSearchDecorator {
    constructor(search, tema) {
        super(search);
        this.tema = tema;
    }

    execute(query) {
        const results = this.search.execute(query);
            return results.filter(ponto =>
            ponto.tema === this.tema
        );
    }
}

class PatrimonioFilter extends BaseSearchDecorator {
    constructor(search) {
        super(search);
        this.tema = "patrimonio historico";
    }

    execute(query) {
        const results = this.search.execute(query);
            return results.filter(ponto =>
            ponto.tema && ponto.tema.toLowerCase() === this.tema
        );
    }
}

class VisitantesFilter extends BaseSearchDecorator {
    constructor(search, minVisitantes) {
        super(search);
        this.minVisitantes = minVisitantes;
    }

    execute(query) {
        const results = this.search.execute(query);
            return results.filter(ponto =>
            ponto.visitantes && ponto.visitantes >= this.minVisitantes
        );
    }
}

class EstacionamentoFilter extends BaseSearchDecorator {
    constructor(search, estacionamento) {
        super(search);
        this.estacionamento = estacionamento;
    }

    execute(query) {
        const results = this.search.execute(query);
            return results.filter(ponto =>
            ponto.estacionamento === this.estacionamento
        );
    }
}