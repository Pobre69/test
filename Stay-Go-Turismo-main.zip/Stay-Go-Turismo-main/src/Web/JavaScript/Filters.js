class AvaliacaoFilter extends BaseSearchDecorator {
    constructor(search, minRating, maxRating) {
        super(search);
        this.minRating = minRating;
        this.maxRating = maxRating;
    }

    execute(query) {
        const results = this.search.execute(query);
        return results.filter(ponto => {
            if (!('pt_c17' in ponto)) return false;
            const avaliacao = parseFloat(ponto.pt_c17);
            return avaliacao >= this.minRating && avaliacao <= this.maxRating;
        });
    }
}

class HorarioFilter extends BaseSearchDecorator {
    constructor(search, openTime, closeTime) {
        super(search);
        this.openTime = openTime;
        this.closeTime = closeTime;
    }

    execute(query) {
        const results = this.search.execute(query);
        return results.filter(ponto =>
            ponto.pt_c7 <= this.openTime &&
            ponto.pt_c9 >= this.closeTime
        );
    }
}

class NaturalFilter extends BaseSearchDecorator {
    constructor(search, isNatural) {
        super(search);
        this.isNatural = isNatural;
    }

    execute(query) {
        const results = this.search.execute(query);
        return results.filter(ponto =>
            ponto.pt_natural === this.isNatural
        );
    }
}

class EstadoFilter extends BaseSearchDecorator {
    constructor(search, estadoSelected) {
        super(search);
        this.estadoSelected = estadoSelected;
    }

    execute(query) {
        const results = this.search.execute(query);
        return results.filter(ponto =>
            ponto.pt_c2 && ponto.pt_c2.toLowerCase().includes(this.estadoSelected.toLowerCase())
        );
    }
}

class CidadeFilter extends BaseSearchDecorator {
    constructor(search, cidadeSelected) {
        super(search);
        this.cidadeSelected = cidadeSelected;
    }

    execute(query) {
        const results = this.search.execute(query);
        return results.filter(ponto =>
            ponto.pt_c3 && ponto.pt_c3.toLowerCase().includes(this.cidadeSelected.toLowerCase())
        );
    }
}

class TemaFilter extends BaseSearchDecorator {
    constructor(search, tema) {
        super(search);
        this.tema = tema;
    }

    execute(query) {
        const results = this.search.execute(query);
        return results.filter(ponto =>
            ponto.t_tema === this.tema
        );
    }
}

class PatrimonioFilter extends BaseSearchDecorator {
    constructor(search) {
        super(search);
        this.tema = "Patrimonios Historicos";
    }

    execute(query) {
        const results = this.search.execute(query);
        return results.filter(ponto =>
            ponto.t_tema && ponto.t_tema === this.tema
        );
    }
}

class VisitantesFilter extends BaseSearchDecorator {
    constructor(search, minVisitantes) {
        super(search);
        this.minVisitantes = minVisitantes;
    }

    execute(query) {
        const results = this.search.execute(query);
        return results.filter(ponto =>
            ponto.pt_views && ponto.pt_views >= this.minVisitantes
        );
    }
}

class EstacionamentoFilter extends BaseSearchDecorator {
    constructor(search, estacionamento) {
        super(search);
        this.estacionamento = estacionamento === 'true';
    }

    execute(query) {
        const results = this.search.execute(query);
        return results.filter(ponto =>
            ponto.pt_c15 === this.estacionamento
        );
    }
}